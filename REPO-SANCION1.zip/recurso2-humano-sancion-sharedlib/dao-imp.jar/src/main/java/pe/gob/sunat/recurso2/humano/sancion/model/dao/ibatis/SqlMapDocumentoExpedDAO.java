package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoExped;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoExpedExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DocumentoExpedDAO;

public class SqlMapDocumentoExpedDAO extends SqlMapClientDaoSupport implements DocumentoExpedDAO {

    public SqlMapDocumentoExpedDAO() {
        super();
    }

    public int countByExample(DocumentoExpedExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("txxxx3documexped.countByExample", example);
        return count;
    }

    public int deleteByExample(DocumentoExpedExample example) {
        int rows = getSqlMapClientTemplate().delete("txxxx3documexped.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer numIdDocexp) {
        DocumentoExped key = new DocumentoExped();
        key.setNumIdDocexp(numIdDocexp);
        int rows = getSqlMapClientTemplate().delete("txxxx3documexped.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(DocumentoExped record) {
        getSqlMapClientTemplate().insert("txxxx3documexped.insert", record);
    }

    public void insertSelective(DocumentoExped record) {
        getSqlMapClientTemplate().insert("txxxx3documexped.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<DocumentoExped> selectByExample(DocumentoExpedExample example) {
        List<DocumentoExped> list = getSqlMapClientTemplate().queryForList("txxxx3documexped.selectByExample", example);
        return list;
    }

    public DocumentoExped selectByPrimaryKey(Integer numIdDocexp) {
        DocumentoExped key = new DocumentoExped();
        key.setNumIdDocexp(numIdDocexp);
        DocumentoExped record = (DocumentoExped) getSqlMapClientTemplate().queryForObject("txxxx3documexped.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(DocumentoExped record, DocumentoExpedExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx3documexped.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(DocumentoExped record, DocumentoExpedExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx3documexped.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(DocumentoExped record) {
        int rows = getSqlMapClientTemplate().update("txxxx3documexped.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(DocumentoExped record) {
        int rows = getSqlMapClientTemplate().update("txxxx3documexped.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends DocumentoExpedExample {
        private Object record;

        public UpdateByExampleParms(Object record, DocumentoExpedExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}