package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.T01paramDAO;

@SuppressWarnings("deprecation")
public class SqlMapT01paramDAO extends SqlMapDAOBase implements T01paramDAO{

	@Override
	public Parametro selectByPrimaryKey(
			String codParametro, String codDataParametro) {
		Parametro paramSearch = new Parametro();
		paramSearch.setCodParametro(codParametro);
		paramSearch.setCodDataParametro(codDataParametro);
		return (Parametro)getSqlMapClientTemplate().queryForObject("T01param.selectByPrimaryKey", paramSearch);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Parametro> listarPorParametros(Parametro params){
		return (List<Parametro>)getSqlMapClientTemplate().queryForList("T01param.selectByParams", params);
	}
	
	@SuppressWarnings("unchecked")
	public Parametro obtenerByCodigo(String codParametro, String codDataParametro){
		Parametro parametro = null;
		Parametro params = new Parametro();
		params.setCodParametro(codParametro);
		params.setCodDataParametro(codDataParametro);
		List<Parametro> lista = (List<Parametro>)getSqlMapClientTemplate().queryForList("T01param.selectByParams", params);
		if(!lista.isEmpty()){
			parametro = lista.get(0);
		}
		return parametro;
	}

}
