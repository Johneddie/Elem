package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.model.ParamSecund;
import pe.gob.sunat.recurso2.humano.sancion.model.ParamSecundExample;
import pe.gob.sunat.recurso2.humano.sancion.model.ParamSecundKey;
import pe.gob.sunat.recurso2.humano.sancion.model.ParamSecundWithBLOBs;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ParamSecundDAO;

@SuppressWarnings("deprecation")
public class SqlMapParamSecundDAO extends SqlMapDAOBase implements ParamSecundDAO {

    public SqlMapParamSecundDAO() {
        super();
    }

    public int countByExample(ParamSecundExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t5864parametro.countByExample", example);
    }

    public int deleteByExample(ParamSecundExample example) {
    	return getSqlMapClientTemplate().delete("t5864parametro.deleteByExample", example);
    }

    public int deleteByPrimaryKey(ParamSecundKey key) {
    	return getSqlMapClientTemplate().delete("t5864parametro.deleteByPrimaryKey", key);
    }

    public void insert(ParamSecundWithBLOBs record) {
        getSqlMapClientTemplate().insert("t5864parametro.insert", record);
    }

    public void insertSelective(ParamSecundWithBLOBs record) {
        getSqlMapClientTemplate().insert("t5864parametro.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<ParamSecundWithBLOBs> selectByExampleWithBLOBs(ParamSecundExample example) {
    	return getSqlMapClientTemplate().queryForList("t5864parametro.selectByExampleWithBLOBs", example);
    }

    @SuppressWarnings("unchecked")
    public List<ParamSecund> selectByExampleWithoutBLOBs(ParamSecundExample example) {
    	return getSqlMapClientTemplate().queryForList("t5864parametro.selectByExample", example);
    }

    public ParamSecundWithBLOBs selectByPrimaryKey(ParamSecundKey key) {
    	return (ParamSecundWithBLOBs) getSqlMapClientTemplate().queryForObject("t5864parametro.selectByPrimaryKey", key);
    }

    public int updateByExampleSelective(ParamSecundWithBLOBs record, ParamSecundExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t5864parametro.updateByExampleSelective", parms);
    }

    public int updateByExample(ParamSecundWithBLOBs record, ParamSecundExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t5864parametro.updateByExampleWithBLOBs", parms);
    }

    public int updateByExample(ParamSecund record, ParamSecundExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t5864parametro.updateByExample", parms);
    }

    public int updateByPrimaryKeySelective(ParamSecundWithBLOBs record) {
    	return getSqlMapClientTemplate().update("t5864parametro.updateByPrimaryKeySelective", record);
    }

    public int updateByPrimaryKey(ParamSecundWithBLOBs record) {
    	return getSqlMapClientTemplate().update("t5864parametro.updateByPrimaryKeyWithBLOBs", record);
    }

    public int updateByPrimaryKey(ParamSecund record) {
    	return getSqlMapClientTemplate().update("t5864parametro.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends ParamSecundExample {
        private Object record;

        public UpdateByExampleParms(Object record, ParamSecundExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
    
    //personalizado
    
	@Override
	public String obtenerDescripcion(String codTabla, String codParametro){
		String desParametro = null;
		ParamSecundKey psk = new ParamSecundKey();
		psk.setCodTab(codTabla);
		psk.setCodTipDesc("D");
		psk.setNumCodigo(codParametro);
		Parametro parametro = (Parametro)getSqlMapClientTemplate().queryForObject("t5864parametro.selectByPrimaryKeyBasic", psk);
		if(parametro!=null)
			desParametro = parametro.getDesParametro();
		return desParametro;
	}
	
}