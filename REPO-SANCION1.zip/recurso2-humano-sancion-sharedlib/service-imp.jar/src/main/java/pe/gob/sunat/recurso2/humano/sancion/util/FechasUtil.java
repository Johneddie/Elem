package pe.gob.sunat.recurso2.humano.sancion.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FechasUtil {
	
	private static final Log log = LogFactory.getLog("pe.gob.sunat.recurso2.humano.docencia.util.FechasUtil");
	
	
	public static Date getDateFromStringDDMMYY(String fechaString){
		Date fechaSalida = null;
		if(!esVacioNulo(fechaString)){
			try{
				 SimpleDateFormat formateadorDDMMYYYY = new SimpleDateFormat("dd/MM/yyyy");
				 fechaSalida = formateadorDDMMYYYY.parse(fechaString);
			}catch(Exception e){
				log.debug("error",e);
			}
		}
		return fechaSalida; 
	}
	
	
	public static String getStringDDMMYY(Date fechaDate){
		String fechaSalida = null;
		try{
			 SimpleDateFormat formateadorDDMMYYYY = new SimpleDateFormat("dd/MM/yyyy");
			 fechaSalida = formateadorDDMMYYYY.format(fechaDate);
		}catch(Exception e){
			log.debug("error",e);
		}
		return fechaSalida; 
	}
	
	public static Date obtenerFinalDia(Date fecha){
		if(fecha!=null){
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(fecha);
			calendar.set(Calendar.HOUR, 23);
		    calendar.set(Calendar.MINUTE, 59);
		    calendar.set(Calendar.SECOND, 59);
		    return calendar.getTime();
		}
		return fecha;
	}
	
	public static boolean esVacioNulo(String dato){
		return dato==null || "".equals(dato.trim());
	}
	
	public static String getStringFromDateDDMMYYHHmmss(Date fechaDate){
		String fechaSalida = null;
		try{
			if(fechaDate!=null){
				SimpleDateFormat formateadorDDMMYYYY = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				fechaSalida = formateadorDDMMYYYY.format(fechaDate);
			}
		}catch(Exception e){
			log.debug("error",e);
		}
		return fechaSalida; 
	}

}

