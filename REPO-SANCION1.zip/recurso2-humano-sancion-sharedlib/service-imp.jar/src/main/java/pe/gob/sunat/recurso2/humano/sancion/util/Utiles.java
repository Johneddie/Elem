package pe.gob.sunat.recurso2.humano.sancion.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class Utiles{
	
	private Utiles(){
		
	}
	public static Map<String, String> obtenerMapFromParameterMap(Map<String, String[]> arrayMap){
		  Map<String, String> r = new HashMap<>();
		  for (Map.Entry<String, String[]> entry: arrayMap.entrySet()){
		    String[] value = entry.getValue();
		    if (value !=null && value .length>0) 
		    	r.put(entry.getKey(), value[0]);
		  }
		  return r;
	}
	
	
	public static String obtenerTrazaError(Exception e){
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		String sStackTrace = sw.toString(); 
		return sStackTrace;
	}
	
	
	public static Map<String, Object> configurarMensajeError(Map<String, Object> mapRpta, String nomError, String desError){
		mapRpta.put("indError", "1");
    	mapRpta.put("nomError", nomError);
    	mapRpta.put("desError", desError);
    	return mapRpta;
	}
	
	public static Map<String, Object> configurarMensajeError(Map<String, Object> mapRpta, String nomError){
		mapRpta.put("indError", "1");
    	mapRpta.put("nomError", nomError);
    	mapRpta.put("desError", nomError);
    	return mapRpta;
	}
	
	public static String obtenerCodigo(Integer numAnio, Integer numCorrel){
		return "SOL"+ numAnio +String.format("%05d", numCorrel);
	}

}
