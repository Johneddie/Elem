package pe.gob.sunat.recurso2.humano.sancion.util;


public class Constantes {
	
	private Constantes(){
	}
	
	public static final String INDI_ELIMINAD = "1";
	public static final String INDI_NOELIMIN = "0";
	
	public static final String INDI_GENE_ACTI = "1";
	public static final String INDI_GENE_INAC = "0";
	
	public static final String TIPO_CODI_CABE = "C";
	public static final String TIPO_CODI_DESC = "D";
	
	public static final String DIRE_TEMP = "/data0/recurso2/humano/sancion/upload/";
	
	public static final String CODI_ACCI_DECL_REGI = "01";
	public static final String CODI_ACCI_DECL_APRO = "02";
	public static final String CODI_ACCI_DECL_RECH = "03";
	
	public static final String CODI_ESTA_SOLI_INIC = "01";
	public static final String CODI_ESTA_SOLI_SEGU = "02";
	public static final String CODI_ESTA_SOLI_CONC = "03";
	
	//codigos
	public static final String CODI_TABL_TIPO_SANC = "691";
	public static final String CODI_TABL_TIPO_EXPE = "693";
	public static final String CODI_TABL_FASE_EXPE = "696";
	public static final String CODI_TABL_ACCI_EXPE = "697";
	public static final String CODI_TABL_FUEN_PROC = "694";
	public static final String CODI_TABL_TDOC_EXPE = "692";
	public static final String CODI_TABL_TDOC_TRAB = "594";
	public static final String CODI_TABL_PARA_GENE = "699";
	public static final String CODI_TABL_EQUI_TIPO_DOCU = "594";
	public static final String PARA_TABL_UBIG_SIRH = "700";
	
	public static final String CODI_DELE_SANC = "B";
	public static final String CODI_GENE_DIRE_DGCD = "01";
	
	public static final int NUME_CARA_MINI_BUSQ = 3;
	
	/*
	//c�digos
	public static final String CODI_TABL_TIPO_SOLI = "605";
	public static final String CODI_TABL_TIPO_EVEN = "606";
	public static final String CODI_TABL_TEMA_DOCE = "607";
	public static final String CODI_TABL_CATE_PERS = "608";
	public static final String CODI_TABL_DIAS_EVEN = "609";
	public static final String CODI_TABL_NIVE_DOCE = "670";
	public static final String CODI_TABL_TIPO_ACTO = "671";
	public static final String CODI_TABL_ACCI_SOLI = "672";
	public static final String CODI_TABL_ESTA_SOLI = "673";
	public static final String CODI_TABL_PARA_GENE = "674";
	public static final String CODI_SECU_CLAU_DECL = "027";
	
	public static final String CODI_TABL_CATE = "001";
	
	public static final String CODI_GENE_DIRE_DIAP = "01";
	public static final String CODI_GENE_ANNA_DIAP = "02";
	public static final String CODI_GENE_DIAS_DIFE = "03";
	
	//jefe
	public static final String CODI_DELE_DDJJ = "A";
	
	//c�digo tipo actor
	public static final String CODI_TIPO_ACTO_SOLI = "01";
	public static final String CODI_TIPO_ACTO_DIRE = "02";
	public static final String CODI_TIPO_ACTO_ORGA = "03";
	public static final String CODI_TIPO_ACTO_DIAP = "04";
	
	//cla�sulas declaraci�n
	public static final String CODI_CLAU_DEC1 = "01";
	public static final String CODI_CLAU_DEC2 = "02";
	public static final String CODI_CLAU_DEC3 = "03";
	public static final String CODI_CLAU_ENCA = "99";
	
	//ruc
	public static final String URL_SERV_CONT_RUC = "http://api.sunat.peru/v1/contribuyente/registro/e/contribuyentes/{numRuc}?f=DATOS_PRINCIPALES";
	public static final String CODI_ERRO_EXCEPCI = "9000";
	public static final String CODI_ERRO_NOTCODE_200 = "9001";
	public static final String CODI_ERRO_NOTPROC = "9002";
	public static final String CODI_EXIT_CONTRIB = "0000";
	public static final String CODI_EXIT_SUNAT = "1111";
	
	public static final String NOMB_SEQU_ARCH = "SET8152";
	
	public static final String DIRE_LOGO_SUNAT = "/data0/generador/jasper/images/sunat_logo.jpg";
	public static final String DIRE_JASP_DECLA = "/data0/generador/jasper/plantillas/PLANTILLA200039.jasper";
	
	public static final String DESC_DECL_PAR1 = "Respecto del evento denominado <nomEvento>, organizado por <nomCentro>, no tengo vinculaci�n de cuarto grado de consanguinidad y segundo de afinidad con el organizador de este evento.";
	public static final String DESC_DECL_PAR2 = "Para la realizaci�n de las actividades antes se�aladas no utilizar� recursos de la SUNAT, ni informaci�n interna, as� como no dedicar� durante mi jornada de trabajo a la elaboraci�n de material relacionado a la docencia, conferencias, charlas, publicaciones, evento y al dictado o exposici�n de las mismas(*).";
	public static final String DESC_DECL_PAR3 = "He comunicado al centro de estudios/Instituci�n correspondiente que no autorizo la difusi�n de mi condici�n de trabajador de la SUNAT.";
	*/
}
