package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.Date;

public class DocumentoExped {
    private Integer numIdDocexp;

    private Integer numIdExped;

    private Integer numIdDocum;

    private String indDel;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;

    public Integer getNumIdDocexp() {
        return numIdDocexp;
    }

    public void setNumIdDocexp(Integer numIdDocexp) {
        this.numIdDocexp = numIdDocexp;
    }

    public Integer getNumIdExped() {
        return numIdExped;
    }

    public void setNumIdExped(Integer numIdExped) {
        this.numIdExped = numIdExped;
    }

    public Integer getNumIdDocum() {
        return numIdDocum;
    }

    public void setNumIdDocum(Integer numIdDocum) {
        this.numIdDocum = numIdDocum;
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }
}