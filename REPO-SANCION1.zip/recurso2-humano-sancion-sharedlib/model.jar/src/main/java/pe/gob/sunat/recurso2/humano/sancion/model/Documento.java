package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.Date;

public class Documento {
    private String t07codPers;

    private String t07correl;

    private String t07codDcto;

    private String t07nroDcto;

    private Date t07fGraba;

    private String t07codUser;

    public String getT07codPers() {
        return t07codPers;
    }

    public void setT07codPers(String t07codPers) {
        this.t07codPers = t07codPers == null ? null : t07codPers.trim();
    }

    public String getT07correl() {
        return t07correl;
    }

    public void setT07correl(String t07correl) {
        this.t07correl = t07correl == null ? null : t07correl.trim();
    }

    public String getT07codDcto() {
        return t07codDcto;
    }

    public void setT07codDcto(String t07codDcto) {
        this.t07codDcto = t07codDcto == null ? null : t07codDcto.trim();
    }

    public String getT07nroDcto() {
        return t07nroDcto;
    }

    public void setT07nroDcto(String t07nroDcto) {
        this.t07nroDcto = t07nroDcto == null ? null : t07nroDcto.trim();
    }

    public Date getT07fGraba() {
        return t07fGraba;
    }

    public void setT07fGraba(Date t07fGraba) {
        this.t07fGraba = t07fGraba;
    }

    public String getT07codUser() {
        return t07codUser;
    }

    public void setT07codUser(String t07codUser) {
        this.t07codUser = t07codUser == null ? null : t07codUser.trim();
    }
}