package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ExpedienteSanciExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ExpedienteSanciExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected ExpedienteSanciExample(ExpedienteSanciExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andNumIdExpedIsNull() {
            addCriterion("num_id_exped is null");
            return this;
        }

        public Criteria andNumIdExpedIsNotNull() {
            addCriterion("num_id_exped is not null");
            return this;
        }

        public Criteria andNumIdExpedEqualTo(Integer value) {
            addCriterion("num_id_exped =", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotEqualTo(Integer value) {
            addCriterion("num_id_exped <>", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedGreaterThan(Integer value) {
            addCriterion("num_id_exped >", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_id_exped >=", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedLessThan(Integer value) {
            addCriterion("num_id_exped <", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedLessThanOrEqualTo(Integer value) {
            addCriterion("num_id_exped <=", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedIn(List<Integer> values) {
            addCriterion("num_id_exped in", values, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotIn(List<Integer> values) {
            addCriterion("num_id_exped not in", values, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedBetween(Integer value1, Integer value2) {
            addCriterion("num_id_exped between", value1, value2, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotBetween(Integer value1, Integer value2) {
            addCriterion("num_id_exped not between", value1, value2, "numIdExped");
            return this;
        }

        public Criteria andNumAnioIsNull() {
            addCriterion("num_anio is null");
            return this;
        }

        public Criteria andNumAnioIsNotNull() {
            addCriterion("num_anio is not null");
            return this;
        }

        public Criteria andNumAnioEqualTo(Integer value) {
            addCriterion("num_anio =", value, "numAnio");
            return this;
        }

        public Criteria andNumAnioNotEqualTo(Integer value) {
            addCriterion("num_anio <>", value, "numAnio");
            return this;
        }

        public Criteria andNumAnioGreaterThan(Integer value) {
            addCriterion("num_anio >", value, "numAnio");
            return this;
        }

        public Criteria andNumAnioGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_anio >=", value, "numAnio");
            return this;
        }

        public Criteria andNumAnioLessThan(Integer value) {
            addCriterion("num_anio <", value, "numAnio");
            return this;
        }

        public Criteria andNumAnioLessThanOrEqualTo(Integer value) {
            addCriterion("num_anio <=", value, "numAnio");
            return this;
        }

        public Criteria andNumAnioIn(List<Integer> values) {
            addCriterion("num_anio in", values, "numAnio");
            return this;
        }

        public Criteria andNumAnioNotIn(List<Integer> values) {
            addCriterion("num_anio not in", values, "numAnio");
            return this;
        }

        public Criteria andNumAnioBetween(Integer value1, Integer value2) {
            addCriterion("num_anio between", value1, value2, "numAnio");
            return this;
        }

        public Criteria andNumAnioNotBetween(Integer value1, Integer value2) {
            addCriterion("num_anio not between", value1, value2, "numAnio");
            return this;
        }

        public Criteria andNumCorrelIsNull() {
            addCriterion("num_correl is null");
            return this;
        }

        public Criteria andNumCorrelIsNotNull() {
            addCriterion("num_correl is not null");
            return this;
        }

        public Criteria andNumCorrelEqualTo(Integer value) {
            addCriterion("num_correl =", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotEqualTo(Integer value) {
            addCriterion("num_correl <>", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelGreaterThan(Integer value) {
            addCriterion("num_correl >", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_correl >=", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelLessThan(Integer value) {
            addCriterion("num_correl <", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelLessThanOrEqualTo(Integer value) {
            addCriterion("num_correl <=", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelIn(List<Integer> values) {
            addCriterion("num_correl in", values, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotIn(List<Integer> values) {
            addCriterion("num_correl not in", values, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelBetween(Integer value1, Integer value2) {
            addCriterion("num_correl between", value1, value2, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotBetween(Integer value1, Integer value2) {
            addCriterion("num_correl not between", value1, value2, "numCorrel");
            return this;
        }

        public Criteria andCodPersDenunIsNull() {
            addCriterion("cod_pers_denun is null");
            return this;
        }

        public Criteria andCodPersDenunIsNotNull() {
            addCriterion("cod_pers_denun is not null");
            return this;
        }

        public Criteria andCodPersDenunEqualTo(String value) {
            addCriterion("cod_pers_denun =", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunNotEqualTo(String value) {
            addCriterion("cod_pers_denun <>", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunGreaterThan(String value) {
            addCriterion("cod_pers_denun >", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pers_denun >=", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunLessThan(String value) {
            addCriterion("cod_pers_denun <", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunLessThanOrEqualTo(String value) {
            addCriterion("cod_pers_denun <=", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunLike(String value) {
            addCriterion("cod_pers_denun like", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunNotLike(String value) {
            addCriterion("cod_pers_denun not like", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunIn(List<String> values) {
            addCriterion("cod_pers_denun in", values, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunNotIn(List<String> values) {
            addCriterion("cod_pers_denun not in", values, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunBetween(String value1, String value2) {
            addCriterion("cod_pers_denun between", value1, value2, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunNotBetween(String value1, String value2) {
            addCriterion("cod_pers_denun not between", value1, value2, "codPersDenun");
            return this;
        }

        public Criteria andCodUnidUltimIsNull() {
            addCriterion("cod_unid_ultim is null");
            return this;
        }

        public Criteria andCodUnidUltimIsNotNull() {
            addCriterion("cod_unid_ultim is not null");
            return this;
        }

        public Criteria andCodUnidUltimEqualTo(String value) {
            addCriterion("cod_unid_ultim =", value, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimNotEqualTo(String value) {
            addCriterion("cod_unid_ultim <>", value, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimGreaterThan(String value) {
            addCriterion("cod_unid_ultim >", value, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimGreaterThanOrEqualTo(String value) {
            addCriterion("cod_unid_ultim >=", value, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimLessThan(String value) {
            addCriterion("cod_unid_ultim <", value, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimLessThanOrEqualTo(String value) {
            addCriterion("cod_unid_ultim <=", value, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimLike(String value) {
            addCriterion("cod_unid_ultim like", value, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimNotLike(String value) {
            addCriterion("cod_unid_ultim not like", value, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimIn(List<String> values) {
            addCriterion("cod_unid_ultim in", values, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimNotIn(List<String> values) {
            addCriterion("cod_unid_ultim not in", values, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimBetween(String value1, String value2) {
            addCriterion("cod_unid_ultim between", value1, value2, "codUnidUltim");
            return this;
        }

        public Criteria andCodUnidUltimNotBetween(String value1, String value2) {
            addCriterion("cod_unid_ultim not between", value1, value2, "codUnidUltim");
            return this;
        }

        public Criteria andCodTipExpedIsNull() {
            addCriterion("cod_tip_exped is null");
            return this;
        }

        public Criteria andCodTipExpedIsNotNull() {
            addCriterion("cod_tip_exped is not null");
            return this;
        }

        public Criteria andCodTipExpedEqualTo(String value) {
            addCriterion("cod_tip_exped =", value, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedNotEqualTo(String value) {
            addCriterion("cod_tip_exped <>", value, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedGreaterThan(String value) {
            addCriterion("cod_tip_exped >", value, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tip_exped >=", value, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedLessThan(String value) {
            addCriterion("cod_tip_exped <", value, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedLessThanOrEqualTo(String value) {
            addCriterion("cod_tip_exped <=", value, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedLike(String value) {
            addCriterion("cod_tip_exped like", value, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedNotLike(String value) {
            addCriterion("cod_tip_exped not like", value, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedIn(List<String> values) {
            addCriterion("cod_tip_exped in", values, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedNotIn(List<String> values) {
            addCriterion("cod_tip_exped not in", values, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedBetween(String value1, String value2) {
            addCriterion("cod_tip_exped between", value1, value2, "codTipExped");
            return this;
        }

        public Criteria andCodTipExpedNotBetween(String value1, String value2) {
            addCriterion("cod_tip_exped not between", value1, value2, "codTipExped");
            return this;
        }

        public Criteria andFecOcurrenIsNull() {
            addCriterion("fec_ocurren is null");
            return this;
        }

        public Criteria andFecOcurrenIsNotNull() {
            addCriterion("fec_ocurren is not null");
            return this;
        }

        public Criteria andFecOcurrenEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ocurren =", value, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ocurren <>", value, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_ocurren >", value, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ocurren >=", value, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenLessThan(Date value) {
            addCriterionForJDBCDate("fec_ocurren <", value, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ocurren <=", value, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenIn(List<Date> values) {
            addCriterionForJDBCDate("fec_ocurren in", values, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_ocurren not in", values, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_ocurren between", value1, value2, "fecOcurren");
            return this;
        }

        public Criteria andFecOcurrenNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_ocurren not between", value1, value2, "fecOcurren");
            return this;
        }

        public Criteria andCodUnidInstruIsNull() {
            addCriterion("cod_unid_instru is null");
            return this;
        }

        public Criteria andCodUnidInstruIsNotNull() {
            addCriterion("cod_unid_instru is not null");
            return this;
        }

        public Criteria andCodUnidInstruEqualTo(String value) {
            addCriterion("cod_unid_instru =", value, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruNotEqualTo(String value) {
            addCriterion("cod_unid_instru <>", value, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruGreaterThan(String value) {
            addCriterion("cod_unid_instru >", value, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruGreaterThanOrEqualTo(String value) {
            addCriterion("cod_unid_instru >=", value, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruLessThan(String value) {
            addCriterion("cod_unid_instru <", value, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruLessThanOrEqualTo(String value) {
            addCriterion("cod_unid_instru <=", value, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruLike(String value) {
            addCriterion("cod_unid_instru like", value, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruNotLike(String value) {
            addCriterion("cod_unid_instru not like", value, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruIn(List<String> values) {
            addCriterion("cod_unid_instru in", values, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruNotIn(List<String> values) {
            addCriterion("cod_unid_instru not in", values, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruBetween(String value1, String value2) {
            addCriterion("cod_unid_instru between", value1, value2, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidInstruNotBetween(String value1, String value2) {
            addCriterion("cod_unid_instru not between", value1, value2, "codUnidInstru");
            return this;
        }

        public Criteria andCodUnidSanciIsNull() {
            addCriterion("cod_unid_sanci is null");
            return this;
        }

        public Criteria andCodUnidSanciIsNotNull() {
            addCriterion("cod_unid_sanci is not null");
            return this;
        }

        public Criteria andCodUnidSanciEqualTo(String value) {
            addCriterion("cod_unid_sanci =", value, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciNotEqualTo(String value) {
            addCriterion("cod_unid_sanci <>", value, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciGreaterThan(String value) {
            addCriterion("cod_unid_sanci >", value, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciGreaterThanOrEqualTo(String value) {
            addCriterion("cod_unid_sanci >=", value, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciLessThan(String value) {
            addCriterion("cod_unid_sanci <", value, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciLessThanOrEqualTo(String value) {
            addCriterion("cod_unid_sanci <=", value, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciLike(String value) {
            addCriterion("cod_unid_sanci like", value, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciNotLike(String value) {
            addCriterion("cod_unid_sanci not like", value, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciIn(List<String> values) {
            addCriterion("cod_unid_sanci in", values, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciNotIn(List<String> values) {
            addCriterion("cod_unid_sanci not in", values, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciBetween(String value1, String value2) {
            addCriterion("cod_unid_sanci between", value1, value2, "codUnidSanci");
            return this;
        }

        public Criteria andCodUnidSanciNotBetween(String value1, String value2) {
            addCriterion("cod_unid_sanci not between", value1, value2, "codUnidSanci");
            return this;
        }

        public Criteria andCodPersEspecIsNull() {
            addCriterion("cod_pers_espec is null");
            return this;
        }

        public Criteria andCodPersEspecIsNotNull() {
            addCriterion("cod_pers_espec is not null");
            return this;
        }

        public Criteria andCodPersEspecEqualTo(String value) {
            addCriterion("cod_pers_espec =", value, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecNotEqualTo(String value) {
            addCriterion("cod_pers_espec <>", value, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecGreaterThan(String value) {
            addCriterion("cod_pers_espec >", value, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pers_espec >=", value, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecLessThan(String value) {
            addCriterion("cod_pers_espec <", value, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecLessThanOrEqualTo(String value) {
            addCriterion("cod_pers_espec <=", value, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecLike(String value) {
            addCriterion("cod_pers_espec like", value, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecNotLike(String value) {
            addCriterion("cod_pers_espec not like", value, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecIn(List<String> values) {
            addCriterion("cod_pers_espec in", values, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecNotIn(List<String> values) {
            addCriterion("cod_pers_espec not in", values, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecBetween(String value1, String value2) {
            addCriterion("cod_pers_espec between", value1, value2, "codPersEspec");
            return this;
        }

        public Criteria andCodPersEspecNotBetween(String value1, String value2) {
            addCriterion("cod_pers_espec not between", value1, value2, "codPersEspec");
            return this;
        }

        public Criteria andCodFaseActIsNull() {
            addCriterion("cod_fase_act is null");
            return this;
        }

        public Criteria andCodFaseActIsNotNull() {
            addCriterion("cod_fase_act is not null");
            return this;
        }

        public Criteria andCodFaseActEqualTo(String value) {
            addCriterion("cod_fase_act =", value, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActNotEqualTo(String value) {
            addCriterion("cod_fase_act <>", value, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActGreaterThan(String value) {
            addCriterion("cod_fase_act >", value, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActGreaterThanOrEqualTo(String value) {
            addCriterion("cod_fase_act >=", value, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActLessThan(String value) {
            addCriterion("cod_fase_act <", value, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActLessThanOrEqualTo(String value) {
            addCriterion("cod_fase_act <=", value, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActLike(String value) {
            addCriterion("cod_fase_act like", value, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActNotLike(String value) {
            addCriterion("cod_fase_act not like", value, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActIn(List<String> values) {
            addCriterion("cod_fase_act in", values, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActNotIn(List<String> values) {
            addCriterion("cod_fase_act not in", values, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActBetween(String value1, String value2) {
            addCriterion("cod_fase_act between", value1, value2, "codFaseAct");
            return this;
        }

        public Criteria andCodFaseActNotBetween(String value1, String value2) {
            addCriterion("cod_fase_act not between", value1, value2, "codFaseAct");
            return this;
        }

        public Criteria andCodAccionIsNull() {
            addCriterion("cod_accion is null");
            return this;
        }

        public Criteria andCodAccionIsNotNull() {
            addCriterion("cod_accion is not null");
            return this;
        }

        public Criteria andCodAccionEqualTo(String value) {
            addCriterion("cod_accion =", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionNotEqualTo(String value) {
            addCriterion("cod_accion <>", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionGreaterThan(String value) {
            addCriterion("cod_accion >", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionGreaterThanOrEqualTo(String value) {
            addCriterion("cod_accion >=", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionLessThan(String value) {
            addCriterion("cod_accion <", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionLessThanOrEqualTo(String value) {
            addCriterion("cod_accion <=", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionLike(String value) {
            addCriterion("cod_accion like", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionNotLike(String value) {
            addCriterion("cod_accion not like", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionIn(List<String> values) {
            addCriterion("cod_accion in", values, "codAccion");
            return this;
        }

        public Criteria andCodAccionNotIn(List<String> values) {
            addCriterion("cod_accion not in", values, "codAccion");
            return this;
        }

        public Criteria andCodAccionBetween(String value1, String value2) {
            addCriterion("cod_accion between", value1, value2, "codAccion");
            return this;
        }

        public Criteria andCodAccionNotBetween(String value1, String value2) {
            addCriterion("cod_accion not between", value1, value2, "codAccion");
            return this;
        }

        public Criteria andCodEstadoIsNull() {
            addCriterion("cod_estado is null");
            return this;
        }

        public Criteria andCodEstadoIsNotNull() {
            addCriterion("cod_estado is not null");
            return this;
        }

        public Criteria andCodEstadoEqualTo(String value) {
            addCriterion("cod_estado =", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotEqualTo(String value) {
            addCriterion("cod_estado <>", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThan(String value) {
            addCriterion("cod_estado >", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estado >=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThan(String value) {
            addCriterion("cod_estado <", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThanOrEqualTo(String value) {
            addCriterion("cod_estado <=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLike(String value) {
            addCriterion("cod_estado like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotLike(String value) {
            addCriterion("cod_estado not like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoIn(List<String> values) {
            addCriterion("cod_estado in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotIn(List<String> values) {
            addCriterion("cod_estado not in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoBetween(String value1, String value2) {
            addCriterion("cod_estado between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotBetween(String value1, String value2) {
            addCriterion("cod_estado not between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodSancPrecaIsNull() {
            addCriterion("cod_sanc_preca is null");
            return this;
        }

        public Criteria andCodSancPrecaIsNotNull() {
            addCriterion("cod_sanc_preca is not null");
            return this;
        }

        public Criteria andCodSancPrecaEqualTo(String value) {
            addCriterion("cod_sanc_preca =", value, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaNotEqualTo(String value) {
            addCriterion("cod_sanc_preca <>", value, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaGreaterThan(String value) {
            addCriterion("cod_sanc_preca >", value, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_sanc_preca >=", value, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaLessThan(String value) {
            addCriterion("cod_sanc_preca <", value, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaLessThanOrEqualTo(String value) {
            addCriterion("cod_sanc_preca <=", value, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaLike(String value) {
            addCriterion("cod_sanc_preca like", value, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaNotLike(String value) {
            addCriterion("cod_sanc_preca not like", value, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaIn(List<String> values) {
            addCriterion("cod_sanc_preca in", values, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaNotIn(List<String> values) {
            addCriterion("cod_sanc_preca not in", values, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaBetween(String value1, String value2) {
            addCriterion("cod_sanc_preca between", value1, value2, "codSancPreca");
            return this;
        }

        public Criteria andCodSancPrecaNotBetween(String value1, String value2) {
            addCriterion("cod_sanc_preca not between", value1, value2, "codSancPreca");
            return this;
        }

        public Criteria andCodSancInstruIsNull() {
            addCriterion("cod_sanc_instru is null");
            return this;
        }

        public Criteria andCodSancInstruIsNotNull() {
            addCriterion("cod_sanc_instru is not null");
            return this;
        }

        public Criteria andCodSancInstruEqualTo(String value) {
            addCriterion("cod_sanc_instru =", value, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruNotEqualTo(String value) {
            addCriterion("cod_sanc_instru <>", value, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruGreaterThan(String value) {
            addCriterion("cod_sanc_instru >", value, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruGreaterThanOrEqualTo(String value) {
            addCriterion("cod_sanc_instru >=", value, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruLessThan(String value) {
            addCriterion("cod_sanc_instru <", value, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruLessThanOrEqualTo(String value) {
            addCriterion("cod_sanc_instru <=", value, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruLike(String value) {
            addCriterion("cod_sanc_instru like", value, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruNotLike(String value) {
            addCriterion("cod_sanc_instru not like", value, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruIn(List<String> values) {
            addCriterion("cod_sanc_instru in", values, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruNotIn(List<String> values) {
            addCriterion("cod_sanc_instru not in", values, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruBetween(String value1, String value2) {
            addCriterion("cod_sanc_instru between", value1, value2, "codSancInstru");
            return this;
        }

        public Criteria andCodSancInstruNotBetween(String value1, String value2) {
            addCriterion("cod_sanc_instru not between", value1, value2, "codSancInstru");
            return this;
        }

        public Criteria andCodFuenProceIsNull() {
            addCriterion("cod_fuen_proce is null");
            return this;
        }

        public Criteria andCodFuenProceIsNotNull() {
            addCriterion("cod_fuen_proce is not null");
            return this;
        }

        public Criteria andCodFuenProceEqualTo(String value) {
            addCriterion("cod_fuen_proce =", value, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceNotEqualTo(String value) {
            addCriterion("cod_fuen_proce <>", value, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceGreaterThan(String value) {
            addCriterion("cod_fuen_proce >", value, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceGreaterThanOrEqualTo(String value) {
            addCriterion("cod_fuen_proce >=", value, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceLessThan(String value) {
            addCriterion("cod_fuen_proce <", value, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceLessThanOrEqualTo(String value) {
            addCriterion("cod_fuen_proce <=", value, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceLike(String value) {
            addCriterion("cod_fuen_proce like", value, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceNotLike(String value) {
            addCriterion("cod_fuen_proce not like", value, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceIn(List<String> values) {
            addCriterion("cod_fuen_proce in", values, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceNotIn(List<String> values) {
            addCriterion("cod_fuen_proce not in", values, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceBetween(String value1, String value2) {
            addCriterion("cod_fuen_proce between", value1, value2, "codFuenProce");
            return this;
        }

        public Criteria andCodFuenProceNotBetween(String value1, String value2) {
            addCriterion("cod_fuen_proce not between", value1, value2, "codFuenProce");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }

        public Criteria andCodUsuregisIsNull() {
            addCriterion("cod_usuregis is null");
            return this;
        }

        public Criteria andCodUsuregisIsNotNull() {
            addCriterion("cod_usuregis is not null");
            return this;
        }

        public Criteria andCodUsuregisEqualTo(String value) {
            addCriterion("cod_usuregis =", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotEqualTo(String value) {
            addCriterion("cod_usuregis <>", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThan(String value) {
            addCriterion("cod_usuregis >", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuregis >=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThan(String value) {
            addCriterion("cod_usuregis <", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThanOrEqualTo(String value) {
            addCriterion("cod_usuregis <=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLike(String value) {
            addCriterion("cod_usuregis like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotLike(String value) {
            addCriterion("cod_usuregis not like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisIn(List<String> values) {
            addCriterion("cod_usuregis in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotIn(List<String> values) {
            addCriterion("cod_usuregis not in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisBetween(String value1, String value2) {
            addCriterion("cod_usuregis between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotBetween(String value1, String value2) {
            addCriterion("cod_usuregis not between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andFecRegisIsNull() {
            addCriterion("fec_regis is null");
            return this;
        }

        public Criteria andFecRegisIsNotNull() {
            addCriterion("fec_regis is not null");
            return this;
        }

        public Criteria andFecRegisEqualTo(Date value) {
            addCriterion("fec_regis =", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotEqualTo(Date value) {
            addCriterion("fec_regis <>", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThan(Date value) {
            addCriterion("fec_regis >", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_regis >=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThan(Date value) {
            addCriterion("fec_regis <", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThanOrEqualTo(Date value) {
            addCriterion("fec_regis <=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisIn(List<Date> values) {
            addCriterion("fec_regis in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotIn(List<Date> values) {
            addCriterion("fec_regis not in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisBetween(Date value1, Date value2) {
            addCriterion("fec_regis between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotBetween(Date value1, Date value2) {
            addCriterion("fec_regis not between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }
    }
}