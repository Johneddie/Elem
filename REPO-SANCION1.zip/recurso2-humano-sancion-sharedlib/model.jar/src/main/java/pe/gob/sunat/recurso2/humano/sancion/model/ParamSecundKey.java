package pe.gob.sunat.recurso2.humano.sancion.model;

public class ParamSecundKey {
    private String codTab;

    private String codTipDesc;

    private String numCodigo;

    public ParamSecundKey(){
    	
    }
    		
    public ParamSecundKey(String codTab, String codTipDesc, String numCodigo){
    	this.codTab = codTab;
    	this.codTipDesc = codTipDesc;
    	this.numCodigo = numCodigo;
    }
    
    public String getCodTab() {
        return codTab;
    }

    public void setCodTab(String codTab) {
        this.codTab = codTab == null ? null : codTab.trim();
    }

    public String getCodTipDesc() {
        return codTipDesc;
    }

    public void setCodTipDesc(String codTipDesc) {
        this.codTipDesc = codTipDesc == null ? null : codTipDesc.trim();
    }

    public String getNumCodigo() {
        return numCodigo;
    }

    public void setNumCodigo(String numCodigo) {
        this.numCodigo = numCodigo == null ? null : numCodigo.trim();
    }
}