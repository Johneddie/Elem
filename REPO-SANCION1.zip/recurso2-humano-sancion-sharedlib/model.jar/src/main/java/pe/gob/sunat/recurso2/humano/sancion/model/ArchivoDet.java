package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.Date;

public class ArchivoDet extends ArchivoDetKey {
    private Integer numSeqdoc;

    private Date fecCarga;

    private String codTiparc;

    private String nomArchivo;

    private String desArchivo;

    private String codUsucrea;

    private Date fecCreacion;

    private String codUsumodif;

    private Date fecModif;

    private String indDel;

    private byte[] arcAdjunto;

    public Integer getNumSeqdoc() {
        return numSeqdoc;
    }

    public void setNumSeqdoc(Integer numSeqdoc) {
        this.numSeqdoc = numSeqdoc;
    }

    public Date getFecCarga() {
        return fecCarga;
    }

    public void setFecCarga(Date fecCarga) {
        this.fecCarga = fecCarga;
    }

    public String getCodTiparc() {
        return codTiparc;
    }

    public void setCodTiparc(String codTiparc) {
        this.codTiparc = codTiparc == null ? null : codTiparc.trim();
    }

    public String getNomArchivo() {
        return nomArchivo;
    }

    public void setNomArchivo(String nomArchivo) {
        this.nomArchivo = nomArchivo == null ? null : nomArchivo.trim();
    }

    public String getDesArchivo() {
        return desArchivo;
    }

    public void setDesArchivo(String desArchivo) {
        this.desArchivo = desArchivo == null ? null : desArchivo.trim();
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public byte[] getArcAdjunto() {
        return arcAdjunto;
    }

    public void setArcAdjunto(byte[] arcAdjunto) {
        this.arcAdjunto = arcAdjunto;
    }
}