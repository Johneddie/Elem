package pe.gob.sunat.recurso2.humano.sancion.model;

public class ArchivoDetKey {
    private Integer numArcdet;

    private Integer numArchivo;

    public Integer getNumArcdet() {
        return numArcdet;
    }

    public void setNumArcdet(Integer numArcdet) {
        this.numArcdet = numArcdet;
    }

    public Integer getNumArchivo() {
        return numArchivo;
    }

    public void setNumArchivo(Integer numArchivo) {
        this.numArchivo = numArchivo;
    }
}