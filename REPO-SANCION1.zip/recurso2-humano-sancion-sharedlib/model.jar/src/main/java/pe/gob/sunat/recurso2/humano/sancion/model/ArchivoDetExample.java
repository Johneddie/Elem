package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArchivoDetExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ArchivoDetExample() {
        oredCriteria = new ArrayList<>();
    }

    protected ArchivoDetExample(ArchivoDetExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andNumArcdetIsNull() {
            addCriterion("num_arcdet is null");
            return this;
        }

        public Criteria andNumArcdetIsNotNull() {
            addCriterion("num_arcdet is not null");
            return this;
        }

        public Criteria andNumArcdetEqualTo(Integer value) {
            addCriterion("num_arcdet =", value, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetNotEqualTo(Integer value) {
            addCriterion("num_arcdet <>", value, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetGreaterThan(Integer value) {
            addCriterion("num_arcdet >", value, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_arcdet >=", value, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetLessThan(Integer value) {
            addCriterion("num_arcdet <", value, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetLessThanOrEqualTo(Integer value) {
            addCriterion("num_arcdet <=", value, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetIn(List<Integer> values) {
            addCriterion("num_arcdet in", values, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetNotIn(List<Integer> values) {
            addCriterion("num_arcdet not in", values, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetBetween(Integer value1, Integer value2) {
            addCriterion("num_arcdet between", value1, value2, "numArcdet");
            return this;
        }

        public Criteria andNumArcdetNotBetween(Integer value1, Integer value2) {
            addCriterion("num_arcdet not between", value1, value2, "numArcdet");
            return this;
        }

        public Criteria andNumArchivoIsNull() {
            addCriterion("num_archivo is null");
            return this;
        }

        public Criteria andNumArchivoIsNotNull() {
            addCriterion("num_archivo is not null");
            return this;
        }

        public Criteria andNumArchivoEqualTo(Integer value) {
            addCriterion("num_archivo =", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotEqualTo(Integer value) {
            addCriterion("num_archivo <>", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoGreaterThan(Integer value) {
            addCriterion("num_archivo >", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_archivo >=", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoLessThan(Integer value) {
            addCriterion("num_archivo <", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoLessThanOrEqualTo(Integer value) {
            addCriterion("num_archivo <=", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoIn(List<Integer> values) {
            addCriterion("num_archivo in", values, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotIn(List<Integer> values) {
            addCriterion("num_archivo not in", values, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoBetween(Integer value1, Integer value2) {
            addCriterion("num_archivo between", value1, value2, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotBetween(Integer value1, Integer value2) {
            addCriterion("num_archivo not between", value1, value2, "numArchivo");
            return this;
        }

        public Criteria andNumSeqdocIsNull() {
            addCriterion("num_seqdoc is null");
            return this;
        }

        public Criteria andNumSeqdocIsNotNull() {
            addCriterion("num_seqdoc is not null");
            return this;
        }

        public Criteria andNumSeqdocEqualTo(Integer value) {
            addCriterion("num_seqdoc =", value, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocNotEqualTo(Integer value) {
            addCriterion("num_seqdoc <>", value, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocGreaterThan(Integer value) {
            addCriterion("num_seqdoc >", value, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_seqdoc >=", value, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocLessThan(Integer value) {
            addCriterion("num_seqdoc <", value, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocLessThanOrEqualTo(Integer value) {
            addCriterion("num_seqdoc <=", value, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocIn(List<Integer> values) {
            addCriterion("num_seqdoc in", values, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocNotIn(List<Integer> values) {
            addCriterion("num_seqdoc not in", values, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocBetween(Integer value1, Integer value2) {
            addCriterion("num_seqdoc between", value1, value2, "numSeqdoc");
            return this;
        }

        public Criteria andNumSeqdocNotBetween(Integer value1, Integer value2) {
            addCriterion("num_seqdoc not between", value1, value2, "numSeqdoc");
            return this;
        }

        public Criteria andFecCargaIsNull() {
            addCriterion("fec_carga is null");
            return this;
        }

        public Criteria andFecCargaIsNotNull() {
            addCriterion("fec_carga is not null");
            return this;
        }

        public Criteria andFecCargaEqualTo(Date value) {
            addCriterion("fec_carga =", value, "fecCarga");
            return this;
        }

        public Criteria andFecCargaNotEqualTo(Date value) {
            addCriterion("fec_carga <>", value, "fecCarga");
            return this;
        }

        public Criteria andFecCargaGreaterThan(Date value) {
            addCriterion("fec_carga >", value, "fecCarga");
            return this;
        }

        public Criteria andFecCargaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_carga >=", value, "fecCarga");
            return this;
        }

        public Criteria andFecCargaLessThan(Date value) {
            addCriterion("fec_carga <", value, "fecCarga");
            return this;
        }

        public Criteria andFecCargaLessThanOrEqualTo(Date value) {
            addCriterion("fec_carga <=", value, "fecCarga");
            return this;
        }

        public Criteria andFecCargaIn(List<Date> values) {
            addCriterion("fec_carga in", values, "fecCarga");
            return this;
        }

        public Criteria andFecCargaNotIn(List<Date> values) {
            addCriterion("fec_carga not in", values, "fecCarga");
            return this;
        }

        public Criteria andFecCargaBetween(Date value1, Date value2) {
            addCriterion("fec_carga between", value1, value2, "fecCarga");
            return this;
        }

        public Criteria andFecCargaNotBetween(Date value1, Date value2) {
            addCriterion("fec_carga not between", value1, value2, "fecCarga");
            return this;
        }

        public Criteria andCodTiparcIsNull() {
            addCriterion("cod_tiparc is null");
            return this;
        }

        public Criteria andCodTiparcIsNotNull() {
            addCriterion("cod_tiparc is not null");
            return this;
        }

        public Criteria andCodTiparcEqualTo(String value) {
            addCriterion("cod_tiparc =", value, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcNotEqualTo(String value) {
            addCriterion("cod_tiparc <>", value, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcGreaterThan(String value) {
            addCriterion("cod_tiparc >", value, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tiparc >=", value, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcLessThan(String value) {
            addCriterion("cod_tiparc <", value, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcLessThanOrEqualTo(String value) {
            addCriterion("cod_tiparc <=", value, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcLike(String value) {
            addCriterion("cod_tiparc like", value, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcNotLike(String value) {
            addCriterion("cod_tiparc not like", value, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcIn(List<String> values) {
            addCriterion("cod_tiparc in", values, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcNotIn(List<String> values) {
            addCriterion("cod_tiparc not in", values, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcBetween(String value1, String value2) {
            addCriterion("cod_tiparc between", value1, value2, "codTiparc");
            return this;
        }

        public Criteria andCodTiparcNotBetween(String value1, String value2) {
            addCriterion("cod_tiparc not between", value1, value2, "codTiparc");
            return this;
        }

        public Criteria andNomArchivoIsNull() {
            addCriterion("nom_archivo is null");
            return this;
        }

        public Criteria andNomArchivoIsNotNull() {
            addCriterion("nom_archivo is not null");
            return this;
        }

        public Criteria andNomArchivoEqualTo(String value) {
            addCriterion("nom_archivo =", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoNotEqualTo(String value) {
            addCriterion("nom_archivo <>", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoGreaterThan(String value) {
            addCriterion("nom_archivo >", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoGreaterThanOrEqualTo(String value) {
            addCriterion("nom_archivo >=", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoLessThan(String value) {
            addCriterion("nom_archivo <", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoLessThanOrEqualTo(String value) {
            addCriterion("nom_archivo <=", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoLike(String value) {
            addCriterion("nom_archivo like", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoNotLike(String value) {
            addCriterion("nom_archivo not like", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoIn(List<String> values) {
            addCriterion("nom_archivo in", values, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoNotIn(List<String> values) {
            addCriterion("nom_archivo not in", values, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoBetween(String value1, String value2) {
            addCriterion("nom_archivo between", value1, value2, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoNotBetween(String value1, String value2) {
            addCriterion("nom_archivo not between", value1, value2, "nomArchivo");
            return this;
        }

        public Criteria andDesArchivoIsNull() {
            addCriterion("des_archivo is null");
            return this;
        }

        public Criteria andDesArchivoIsNotNull() {
            addCriterion("des_archivo is not null");
            return this;
        }

        public Criteria andDesArchivoEqualTo(String value) {
            addCriterion("des_archivo =", value, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoNotEqualTo(String value) {
            addCriterion("des_archivo <>", value, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoGreaterThan(String value) {
            addCriterion("des_archivo >", value, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoGreaterThanOrEqualTo(String value) {
            addCriterion("des_archivo >=", value, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoLessThan(String value) {
            addCriterion("des_archivo <", value, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoLessThanOrEqualTo(String value) {
            addCriterion("des_archivo <=", value, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoLike(String value) {
            addCriterion("des_archivo like", value, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoNotLike(String value) {
            addCriterion("des_archivo not like", value, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoIn(List<String> values) {
            addCriterion("des_archivo in", values, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoNotIn(List<String> values) {
            addCriterion("des_archivo not in", values, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoBetween(String value1, String value2) {
            addCriterion("des_archivo between", value1, value2, "desArchivo");
            return this;
        }

        public Criteria andDesArchivoNotBetween(String value1, String value2) {
            addCriterion("des_archivo not between", value1, value2, "desArchivo");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }
    }
}