package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.Date;

public class ExpedienteSanci {
    private Integer numIdExped;

    private Integer numAnio;

    private Integer numCorrel;

    private String codPersDenun;

    private String codUnidUltim;

    private String codTipExped;

    private Date fecOcurren;

    private String codUnidInstru;

    private String codUnidSanci;

    private String codPersEspec;

    private String codFaseAct;

    private String codAccion;

    private String codEstado;

    private String codSancPreca;

    private String codSancInstru;

    private String codSancSanci;

    private String codFuenProce;

    private Integer numDiasDesca;

    private String indDel;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;

    private String desOcurren;
    
    
    private String desTipExped;
    
    private String nomPersDenun;
    
    private String desFaseAct;

    private String desEstado;

    public Integer getNumIdExped() {
        return numIdExped;
    }

    public void setNumIdExped(Integer numIdExped) {
        this.numIdExped = numIdExped;
    }

    public Integer getNumAnio() {
        return numAnio;
    }

    public void setNumAnio(Integer numAnio) {
        this.numAnio = numAnio;
    }

    public Integer getNumCorrel() {
        return numCorrel;
    }

    public void setNumCorrel(Integer numCorrel) {
        this.numCorrel = numCorrel;
    }

    public String getCodPersDenun() {
        return codPersDenun;
    }

    public void setCodPersDenun(String codPersDenun) {
        this.codPersDenun = codPersDenun == null ? null : codPersDenun.trim();
    }

    public String getCodUnidUltim() {
        return codUnidUltim;
    }

    public void setCodUnidUltim(String codUnidUltim) {
        this.codUnidUltim = codUnidUltim == null ? null : codUnidUltim.trim();
    }

    public String getCodTipExped() {
        return codTipExped;
    }

    public void setCodTipExped(String codTipExped) {
        this.codTipExped = codTipExped == null ? null : codTipExped.trim();
    }

    public Date getFecOcurren() {
        return fecOcurren;
    }

    public void setFecOcurren(Date fecOcurren) {
        this.fecOcurren = fecOcurren;
    }

    public String getCodUnidInstru() {
        return codUnidInstru;
    }

    public void setCodUnidInstru(String codUnidInstru) {
        this.codUnidInstru = codUnidInstru == null ? null : codUnidInstru.trim();
    }

    public String getCodUnidSanci() {
        return codUnidSanci;
    }

    public void setCodUnidSanci(String codUnidSanci) {
        this.codUnidSanci = codUnidSanci == null ? null : codUnidSanci.trim();
    }

    public String getCodPersEspec() {
        return codPersEspec;
    }

    public void setCodPersEspec(String codPersEspec) {
        this.codPersEspec = codPersEspec == null ? null : codPersEspec.trim();
    }

    public String getCodFaseAct() {
        return codFaseAct;
    }

    public void setCodFaseAct(String codFaseAct) {
        this.codFaseAct = codFaseAct == null ? null : codFaseAct.trim();
    }

    public String getCodAccion() {
        return codAccion;
    }

    public void setCodAccion(String codAccion) {
        this.codAccion = codAccion == null ? null : codAccion.trim();
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public String getCodSancPreca() {
        return codSancPreca;
    }

    public void setCodSancPreca(String codSancPreca) {
        this.codSancPreca = codSancPreca == null ? null : codSancPreca.trim();
    }

    public String getCodSancInstru() {
        return codSancInstru;
    }

    public void setCodSancInstru(String codSancInstru) {
        this.codSancInstru = codSancInstru == null ? null : codSancInstru.trim();
    }

    public String getCodSancSanci() {
        return codSancSanci;
    }

    public void setCodSancSanci(String codSancSanci) {
        this.codSancSanci = codSancSanci == null ? null : codSancSanci.trim();
    }

    public String getCodFuenProce() {
        return codFuenProce;
    }

    public void setCodFuenProce(String codFuenProce) {
        this.codFuenProce = codFuenProce == null ? null : codFuenProce.trim();
    }

    public Integer getNumDiasDesca() {
        return numDiasDesca;
    }

    public void setNumDiasDesca(Integer numDiasDesca) {
        this.numDiasDesca = numDiasDesca;
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getDesOcurren() {
        return desOcurren;
    }

    public void setDesOcurren(String desOcurren) {
        this.desOcurren = desOcurren == null ? null : desOcurren.trim();
    }

	public String getDesTipExped() {
		return desTipExped;
	}

	public void setDesTipExped(String desTipExped) {
		this.desTipExped = desTipExped;
	}

	public String getNomPersDenun() {
		return nomPersDenun;
	}

	public void setNomPersDenun(String nomPersDenun) {
		this.nomPersDenun = nomPersDenun;
	}

	public String getDesFaseAct() {
		return desFaseAct;
	}

	public void setDesFaseAct(String desFaseAct) {
		this.desFaseAct = desFaseAct;
	}

	public String getDesEstado() {
		return desEstado;
	}

	public void setDesEstado(String desEstado) {
		this.desEstado = desEstado;
	}
    
    
}