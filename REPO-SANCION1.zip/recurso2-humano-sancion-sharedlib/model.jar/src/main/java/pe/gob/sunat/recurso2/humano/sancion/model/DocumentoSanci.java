package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.Date;

public class DocumentoSanci {
    private Integer numIdDocum;

    private Integer numIdExped;

    private String codPersDenun;

    private String codTipDocum;

    private String numDocum;

    private String numInform;

    private Date fecEmision;

    private Date fecRecepcion;

    private Date fecNotifica;

    private Integer nomArchDocum;

    private String desObserva;

    private String codUnidEmis;

    private String codFaseDocum;

    private String indDocInicio;

    private Integer numDiasAmplia;

    private String indDel;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;

    public Integer getNumIdDocum() {
        return numIdDocum;
    }

    public void setNumIdDocum(Integer numIdDocum) {
        this.numIdDocum = numIdDocum;
    }

    public Integer getNumIdExped() {
        return numIdExped;
    }

    public void setNumIdExped(Integer numIdExped) {
        this.numIdExped = numIdExped;
    }

    public String getCodPersDenun() {
        return codPersDenun;
    }

    public void setCodPersDenun(String codPersDenun) {
        this.codPersDenun = codPersDenun == null ? null : codPersDenun.trim();
    }

    public String getCodTipDocum() {
        return codTipDocum;
    }

    public void setCodTipDocum(String codTipDocum) {
        this.codTipDocum = codTipDocum == null ? null : codTipDocum.trim();
    }

    public String getNumDocum() {
        return numDocum;
    }

    public void setNumDocum(String numDocum) {
        this.numDocum = numDocum == null ? null : numDocum.trim();
    }

    public String getNumInform() {
        return numInform;
    }

    public void setNumInform(String numInform) {
        this.numInform = numInform == null ? null : numInform.trim();
    }

    public Date getFecEmision() {
        return fecEmision;
    }

    public void setFecEmision(Date fecEmision) {
        this.fecEmision = fecEmision;
    }

    public Date getFecRecepcion() {
        return fecRecepcion;
    }

    public void setFecRecepcion(Date fecRecepcion) {
        this.fecRecepcion = fecRecepcion;
    }

    public Date getFecNotifica() {
        return fecNotifica;
    }

    public void setFecNotifica(Date fecNotifica) {
        this.fecNotifica = fecNotifica;
    }

    public Integer getNomArchDocum() {
        return nomArchDocum;
    }

    public void setNomArchDocum(Integer nomArchDocum) {
        this.nomArchDocum = nomArchDocum;
    }

    public String getDesObserva() {
        return desObserva;
    }

    public void setDesObserva(String desObserva) {
        this.desObserva = desObserva == null ? null : desObserva.trim();
    }

    public String getCodUnidEmis() {
        return codUnidEmis;
    }

    public void setCodUnidEmis(String codUnidEmis) {
        this.codUnidEmis = codUnidEmis == null ? null : codUnidEmis.trim();
    }

    public String getCodFaseDocum() {
        return codFaseDocum;
    }

    public void setCodFaseDocum(String codFaseDocum) {
        this.codFaseDocum = codFaseDocum == null ? null : codFaseDocum.trim();
    }

    public String getIndDocInicio() {
        return indDocInicio;
    }

    public void setIndDocInicio(String indDocInicio) {
        this.indDocInicio = indDocInicio == null ? null : indDocInicio.trim();
    }

    public Integer getNumDiasAmplia() {
        return numDiasAmplia;
    }

    public void setNumDiasAmplia(Integer numDiasAmplia) {
        this.numDiasAmplia = numDiasAmplia;
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }
}