package pe.gob.sunat.recurso2.humano.sancion.model;

public class ParamSecundWithBLOBs extends ParamSecund {
    private String desLarga;

    private String desGlosa;

    public String getDesLarga() {
        return desLarga;
    }

    public void setDesLarga(String desLarga) {
        this.desLarga = desLarga == null ? null : desLarga.trim();
    }

    public String getDesGlosa() {
        return desGlosa;
    }

    public void setDesGlosa(String desGlosa) {
        this.desGlosa = desGlosa == null ? null : desGlosa.trim();
    }
}