package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoExped;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoExpedExample;

public interface DocumentoExpedDAO {
    int countByExample(DocumentoExpedExample example);

    int deleteByExample(DocumentoExpedExample example);

    int deleteByPrimaryKey(Integer numIdDocexp);

    void insert(DocumentoExped record);

    void insertSelective(DocumentoExped record);

    List<DocumentoExped> selectByExample(DocumentoExpedExample example);

    DocumentoExped selectByPrimaryKey(Integer numIdDocexp);

    int updateByExampleSelective(DocumentoExped record, DocumentoExpedExample example);

    int updateByExample(DocumentoExped record, DocumentoExpedExample example);

    int updateByPrimaryKeySelective(DocumentoExped record);

    int updateByPrimaryKey(DocumentoExped record);
}