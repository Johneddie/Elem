package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDet;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDetExample;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDetKey;

public interface ArchivoDetDAO {
    int countByExample(ArchivoDetExample example);

    int deleteByExample(ArchivoDetExample example);

    int deleteByPrimaryKey(ArchivoDetKey key);

    void insert(ArchivoDet record);

    void insertSelective(ArchivoDet record);

    List<ArchivoDet> selectByExampleWithBLOBs(ArchivoDetExample example);

    List<ArchivoDet> selectByExampleWithoutBLOBs(ArchivoDetExample example);

    ArchivoDet selectByPrimaryKey(ArchivoDetKey key);

    int updateByExampleSelective(ArchivoDet record, ArchivoDetExample example);

    int updateByExampleWithBLOBs(ArchivoDet record, ArchivoDetExample example);

    int updateByExampleWithoutBLOBs(ArchivoDet record, ArchivoDetExample example);

    int updateByPrimaryKeySelective(ArchivoDet record);

    int updateByPrimaryKeyWithBLOBs(ArchivoDet record);

    int updateByPrimaryKeyWithoutBLOBs(ArchivoDet record);
}