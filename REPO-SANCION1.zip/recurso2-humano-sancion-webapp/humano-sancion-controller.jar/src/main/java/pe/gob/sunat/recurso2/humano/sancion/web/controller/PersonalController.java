package pe.gob.sunat.recurso2.humano.sancion.web.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.humano.sancion.model.Persona;
import pe.gob.sunat.recurso2.humano.sancion.model.UnidadOrg;
import pe.gob.sunat.recurso2.humano.sancion.service.PersonalService;
import pe.gob.sunat.recurso2.humano.sancion.util.Utiles;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;


@Controller
@RequestMapping(value="/personal")
@SuppressWarnings("unchecked")
public class PersonalController {
	
	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private PersonalService personalService;
	
	@RequestMapping(value = "/persona/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Persona> listarPersonal(HttpServletRequest request){
		if(log.isDebugEnabled()) log.debug("method listarPersonal");
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		return personalService.listarPersonal(mapParams);
	}
	
	@RequestMapping(value = "/unidad/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<UnidadOrg> listarUnidadOrganizacional(HttpServletRequest request){
		if(log.isDebugEnabled()) log.debug("method listarUnidadOrganizacional");
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		return personalService.listarUnidadOrg(mapParams);
	}
	
	@RequestMapping(value = "/persona/{codPersonal}", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Object obtenerDatosPersona(@PathVariable("codPersonal") String codPersonal, HttpServletRequest request)  {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		log.debug("method obtenerDatosPersona: " + usuarioBean.getNroRegistro());
		Persona persona = null;
		try{
			persona = personalService.obtenerDatosPersona(codPersonal);
		}catch(Exception e){
			log.error("Ha ocurrido un error en obtenerDatosPersona: " + e.getMessage(), e);
		}
		return persona;
	}

}
