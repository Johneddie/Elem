package pe.gob.sunat.recurso2.humano.sancion.web.controller;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Controller
@RequestMapping(value="/bandejaSolicitud")
public class BandejaController {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	/*
	@Autowired
	private BandejaSolicitService bandejaSolicitService;
	
	@Autowired
	private CatalogoService catalogoService;
	
	@Autowired
	private PersonalService personalService;
	
	@Autowired
	private ReporteBandejaService reporteBandejaService;
	
	@RequestMapping("/inicio")
	public ModelAndView iniciarBandejaLegajo(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method iniciarBandejaLegajo");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map<String,Object> parametros = new HashMap<>();
		//catalogos
		parametros.put("tiposSolicitud", catalogoService.listarParametros(Constantes.CODI_TABL_TIPO_SOLI));
		parametros.put("tiposEvento", catalogoService.listarParametros(Constantes.CODI_TABL_TIPO_EVEN));
		parametros.put("temasDocencia", catalogoService.listarParametros(Constantes.CODI_TABL_TEMA_DOCE));
		parametros.put("nivelesDocencia", catalogoService.listarParametros(Constantes.CODI_TABL_NIVE_DOCE));
		parametros.put("categoriasPersonal", catalogoService.listarParametros(Constantes.CODI_TABL_CATE_PERS));
		parametros.put("diasEvento", catalogoService.listarParametros(Constantes.CODI_TABL_DIAS_EVEN));
		parametros.put("declaracion", catalogoService.obtenerDescripDeclaracion());
		parametros.put("persona", personalService.obtenerDatosPersonal(usuarioBean.getNroRegistro()));
		
		return new ModelAndView("bandeja/BandejaPendientes", parametros);
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/pendientes/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<SolicitAutoriza> listarDeclaracionesPendientes(HttpServletRequest request, HttpServletResponse response) throws Exception {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method listarDeclaracionesPendientes: " + usuarioBean.getNroRegistro());
		
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		mapParams.put("codPersonal", usuarioBean.getNroRegistro());
		return bandejaSolicitService.listarSolicitudesPendientes(mapParams);
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/solicitud/registrarAccion", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String, Object> registrarAccionSolicitud(HttpServletRequest request, HttpServletResponse response) throws Exception {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method registrarAccionSolicitud: " + usuarioBean.getNroRegistro());
		
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		mapParams.put("codPersonal", usuarioBean.getNroRegistro());
		
		Map<String,Object> mapRpta = new HashMap<>();
		try{
			bandejaSolicitService.registrarAccionSolicitud(mapParams, usuarioBean.getNroRegistro());
			mapRpta.put("indError", false);
		}catch(Exception e){
			Utiles.configurarMensajeError(mapRpta, e.getMessage(), Utiles.obtenerTrazaError(e));
		}
		return mapRpta;
	}
	
	@RequestMapping(value = "/pendientes/exportar", method=RequestMethod.POST)
	public @ResponseBody ResponseEntity<String> exportarDatosPuesto(HttpServletRequest request, HttpServletResponse response) {
		if(log.isDebugEnabled()) log.debug("method exportarDatosPuesto");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String,Object> mapRpta = new HashMap<>();
		
		try{
			String sFileName =  "SOLIPEND_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".xls";
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-disposition","attachment; filename="+sFileName);
			
			Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
			mapParams.put("codPersonal", usuarioBean.getNroRegistro());
			List<SolicitAutoriza> pendientes = bandejaSolicitService.listarSolicitudesPendientes(mapParams);
			
		    OutputStream output = response.getOutputStream();
		    output.write(reporteBandejaService.generarExcelPendientes(pendientes));
		    output.close();
		}catch(Exception e){
			Utiles.configurarMensajeError(mapRpta, e.getMessage(), Utiles.obtenerTrazaError(e));
		}
		return null;
	}
	*/
}
