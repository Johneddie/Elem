package pe.gob.sunat.recurso2.humano.sancion.web.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExped;
import pe.gob.sunat.recurso2.humano.sancion.util.Constantes;
import pe.gob.sunat.recurso2.humano.sancion.util.Utiles;
import pe.gob.sunat.recurso2.humano.sancion.service.CatalogoService;
import pe.gob.sunat.recurso2.humano.sancion.service.PersonalService;
import pe.gob.sunat.recurso2.humano.sancion.service.RegistroExpedienteService;
import pe.gob.sunat.recurso2.humano.sancion.service.ReporteExpedienteService;
import pe.gob.sunat.recurso2.humano.sancion.service.SeguimientoExpedService;
import pe.gob.sunat.tecnologia.menu.bean.MenuCliente;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Controller
@RequestMapping(value="/expedienteSancion")
public class ExpedienteController {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private RegistroExpedienteService registroExpedienteService;
	
	@Autowired
	private ReporteExpedienteService reporteExpedienteService;
	
	@Autowired
	private SeguimientoExpedService seguimientoExpedService;
	
	@Autowired
	private CatalogoService catalogoService;
	
	@Autowired
	private PersonalService personalService;
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/inicio")
	public ModelAndView iniciarSolicitudAutoriza(HttpServletRequest request, HttpServletResponse response){
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method iniciarSolicitudAutoriza: " + usuarioBean.getNroRegistro());
		Map<String,Object> parametros = new HashMap<>();
		
		Map<String, String> roles = (Map<String, String>)MenuCliente.getRoles(usuarioBean);
		boolean esSecretaria = roles.get("SIRH-SECRET SANC") != null;
		
		if(esSecretaria){
			//catalogos
			parametros.put("tiposExpediente", catalogoService.listarParametros(Constantes.CODI_TABL_TIPO_EXPE));
			parametros.put("fasesExpediente", catalogoService.listarParametros(Constantes.CODI_TABL_FASE_EXPE));
			parametros.put("accionesExpediente", catalogoService.listarParametros(Constantes.CODI_TABL_ACCI_EXPE));
			parametros.put("tiposSancion", catalogoService.listarParametros(Constantes.CODI_TABL_TIPO_SANC));
			parametros.put("fuentesProceso", catalogoService.listarParametros(Constantes.CODI_TABL_FUEN_PROC));
			parametros.put("tiposDocumTraba", catalogoService.listarParametros(Constantes.CODI_TABL_TDOC_TRAB));
			parametros.put("analistasSancion", personalService.listarAnalistasSancion());

			return new ModelAndView("expediente/ExpedienteSancion", parametros);
		}else{
			//catalogos
			parametros.put("mensaje", Constantes.MENS_ERRO_PERM_DESC);
			parametros.put("solucion", Constantes.MENS_ERRO_PERM_SOLU);
			return new ModelAndView("util/pagMensaje", parametros);
		}
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/iniciados/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<ExpedienteSanci> listarExpedientesIniciados(HttpServletRequest request, HttpServletResponse response) throws Exception {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method listarExpedientesIniciados: " + usuarioBean.getNroRegistro());
		
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		mapParams.put("codPersonal", usuarioBean.getNroRegistro());
		List<ExpedienteSanci> lstExpedientes = null;
		try{
			lstExpedientes = registroExpedienteService.listarExpedientesIniciados(mapParams);
		}catch(Exception e){
			log.error("Ha ocurrido un error en obtenerSolicitud: " + e.getMessage(), e);
		}
		return lstExpedientes;
	}
	
	@RequestMapping(value = "/documento/tipos", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarTiposDocumento(@RequestParam("codGruTipDocum") String codGruTipDocum)  {
		if(log.isDebugEnabled()) log.debug("method listarTiposDocumento");
		return catalogoService.listarTiposDocumento(codGruTipDocum);
	}
	
	@RequestMapping(value = "/registrar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> registrarSolicitud(@RequestBody ExpedienteSanci expediente, HttpServletRequest request)  {
		if(log.isDebugEnabled()) log.debug("method registrarSolicitud");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String,Object> mapRpta = new HashMap<>();
		
		try{
			mapRpta = registroExpedienteService.registrarExpediente(expediente, usuarioBean.getNroRegistro(), usuarioBean.getTicket());
		}catch(Exception e){
			Utiles.configurarMensajeError(mapRpta, e.getMessage(), Utiles.obtenerTrazaError(e));
		}
		
		return mapRpta;
	}
	
	@RequestMapping(value = "/expediente/{numIdExped}", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Object obtenerExpediente(@PathVariable("numIdExped") Integer numIdExped, HttpServletRequest request)  {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		log.debug("method obtenerExpediente: " + usuarioBean.getNroRegistro());
		ExpedienteSanci solicitud = null;
		try{
			solicitud = registroExpedienteService.obtenerExpediente(numIdExped);
		}catch(Exception e){
			log.error("Ha ocurrido un error en obtenerSolicitud: " + e.getMessage(), e);
		}
		return solicitud;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/expedientes/exportar", method=RequestMethod.POST)
	public @ResponseBody List<ExpedienteSanci> exportarExpedientesIniciados(HttpServletRequest request, HttpServletResponse response) throws Exception {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method exportarExpedientesIniciados: " + usuarioBean.getNroRegistro());
		
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		List<ExpedienteSanci> lstExpedientes = registroExpedienteService.listarExpedientesIniciados(mapParams);
		Map<String, Object> hmReporte = reporteExpedienteService.exportarExpedientesIniciados(lstExpedientes);
		
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("Content-disposition","attachment; filename="+hmReporte.get("nomFile"));
		
		FileInputStream in = null;
		OutputStream out = null;
		try{
			File fFileExcel = new File((String)hmReporte.get("url"));
			out = response.getOutputStream();
			in = new FileInputStream(fFileExcel);
			byte[] buffer = new byte[4096];
			int length;
			while ((length = in.read(buffer)) > 0)
			   out.write(buffer, 0, length);
		}catch(Exception e){
			log.error("Ha ocurrido un error en exportarDatosPuesto" + e.getMessage(), e);
		}finally{
			if(in != null)
				in.close();
			if(out != null)
				out.flush();
		}
		return null;
	}
	
	// ===========
	// SEGUIMIENTO
	// ===========
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/seguimiento/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<SeguimientoExped> listarSeguimientos(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method listarSeguimientos: " + usuarioBean.getNroRegistro());
		
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		return seguimientoExpedService.listarSeguimientos(mapParams);
	}
	
}
