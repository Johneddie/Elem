package pe.gob.sunat.recurso2.humano.sancion.web.controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.web.view.JsonView;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDet;
import pe.gob.sunat.recurso2.humano.sancion.service.ArchivoService;
import pe.gob.sunat.recurso2.humano.sancion.util.Constantes;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Controller
@RequestMapping(value="/archivo")
public class ArchivoController{
	
	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private JsonView jsonView;
	
	@Autowired
	private ArchivoService archivoService;
	
	@RequestMapping(value = "/cargar", method=RequestMethod.POST)
	public ModelAndView cargarArchivo(HttpServletRequest request, HttpServletResponse response) {
		if (log.isDebugEnabled()) log.debug("method cargarArchivo");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		ModelAndView hmModelo = new ModelAndView(jsonView);
		MultipartHttpServletRequest multipartRequest = null;
		MultipartFile multipartFile = null;
		double tamanoPermitido = 0;
		
		//restricciones
		double tamanoPermitidoMegas = 2; 
		int longitudnombrearchivo = 50;
		String[] lstExtensiones = {".pdf"};

		try {
			multipartRequest = (MultipartHttpServletRequest) request;
			multipartFile = multipartRequest.getFile("docFisico");
			tamanoPermitido = tamanoPermitidoMegas * 1048576;
			
			String nomArchivo = multipartFile.getOriginalFilename();
			
			//tama�o de archivo
			long numTamano = multipartFile.getSize();
			boolean isTamanoSuperado = numTamano > tamanoPermitido;
			hmModelo.addObject("isTamanoSuperado", isTamanoSuperado);
			hmModelo.addObject("tamanoPermitido", tamanoPermitidoMegas);

			//nombre de archivo
			boolean isNombreSuperado = nomArchivo.length() > longitudnombrearchivo;
			hmModelo.addObject("isNombreSuperado", isNombreSuperado);

			//extensiones
			String nomArchivoOrigLower = nomArchivo.toLowerCase();
			boolean isOtraExtension = true;
			for(String e:lstExtensiones){
				if(nomArchivoOrigLower.endsWith(e)){
					isOtraExtension = false;
					break;
				}
			}
			hmModelo.addObject("isOtraExtension", isOtraExtension);
			
			if(!isTamanoSuperado && !isNombreSuperado && !isOtraExtension){
				
				FileOutputStream file = new FileOutputStream(Constantes.DIRE_TEMP + usuarioBean.getTicket() + nomArchivo);
    			
    			if (multipartFile.getBytes()!=null){
    				file.write(multipartFile.getBytes());
    			}
    			file.close();
    			
				//retorno
    			Map<String, Object> hmRegistro = new HashMap<>();
				hmRegistro.put("numTamano", numTamano);
				hmRegistro.put("nomArchivo", nomArchivo);
				hmModelo.addAllObjects(hmRegistro);
			}

		} catch (Exception ex) {
			log.error("Ha ocurrido un error en validarArchivo: " + ex.getMessage(), ex);

		} finally {
			if (log.isDebugEnabled()) log.debug("fin validarArchivo");
		}
		return hmModelo;
	}
	
	
	@RequestMapping(value = "/descargar", method=RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> descargarDocumentoBinario( HttpServletRequest request, HttpServletResponse response) throws Exception {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		log.debug("method descargarDocumentoBinario: " + usuarioBean.getNroRegistro());
    	try {
    		String nombre = "";
    		byte[] archivo = null;
    		Integer numArchivo = null;
    		Integer numArcdet = null;
    		String nomArchivo = request.getParameter("nomArchivo");
    		if(request.getParameter("numArchivo")!=null && !"".equals(request.getParameter("numArchivo"))){
    			numArchivo = new Integer(request.getParameter("numArchivo"));
        		numArcdet = new Integer(request.getParameter("numArcdet"));
        		ArchivoDet ad = archivoService.obtenerDocumento(numArchivo, numArcdet);
        		nombre = ad.getNomArchivo();
        		archivo = ad.getArcAdjunto();
    		}else{
    			InputStream is = (InputStream) new FileInputStream(Constantes.DIRE_TEMP + usuarioBean.getTicket() + nomArchivo);
    			nombre = nomArchivo;
        		archivo = IOUtils.toByteArray(is);
    		}
    		
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombre + "\"");
			response.setContentType("application/pdf");

			OutputStream out = response.getOutputStream();
			out.write(archivo);
			out.close();
			out.flush();
    		
		} catch (Exception e) {
			log.error("Ha ocurrido un error en descargarDocumentoBinario: " + e.getMessage(), e);
		}
    	return null;
	}
	
}
