// =================================================================
// bandeja 
// =================================================================

var inicializarDatosBandeja = function(){
	$("button[id^='btnAprobarSolic']").click(function(){
		var form = $(this).closest("form");
		var divModal = form.closest(".modal");
		$("#divModalAccion").val(divModal.attr("id"));	
			
		actualizarEstadoSolicitudConfirma(_acciones.APROBAR);
	});
	$("button[id^='btnRechazarSolic']").click(function(){
		var form = $(this).closest("form");
		var divModal = form.closest(".modal");
		$("#divModalAccion").val(divModal.attr("id"));
		
		actualizarEstadoSolicitudConfirma(_acciones.RECHAZAR);
	});
	
    $("#btnExportarPendientes").click(function(){
    	if($('#frmBuscarSolicitudes').valid()){
    		var params = "codTipEvenBusq"+$("#codTipEvenBusq").val()+
		    		"&fecRegisIniBusq"+$("#fecRegisIniBusq").val()+
		    		"&fecRegisFinBusq"+$("#fecRegisFinBusq").val();
    		document.forms.formSecundario.action = CONTEXT_APP+"/bandejaSolicitud/pendientes/exportar?" + params;
    		document.forms.formSecundario.method = "post";
    		document.forms.formSecundario.submit();
    	}
    });

};


var actualizarEstadoSolicitudConfirma = function(codAccion){
	
	var mensajeOpe = "";
	if(codAccion == _acciones.RECHAZAR)
		mensajeOpe = "¿Está seguro de rechazar la declaración jurada?";
	if(codAccion == _acciones.APROBAR)
		mensajeOpe = "¿Está seguro de aprobar la declaración jurada?";
	
	$("#codAccionAccion").val(codAccion);
	$("#desObserv").val("");
	
	$("#lblObservacionConfirma").html(mensajeOpe);
	$("#"+$("#divModalAccion").val()).modal("hide");
	$("#divModalObservacionPopup").modal("show");

};

var registrarAccionSolicitudAjax = function(){
	
	var data = {};
	data.numIdSolic = $("#numIdSolicAccion").val();
	data.codAccion = $("#codAccionAccion").val();
	data.desObserv = $("#desObserv").val().toUpperCase() ;
	
	var URL_RECARGA_DATOS = CONTEXT_APP+"/bandejaSolicitud/solicitud/registrarAccion";

    $.post(URL_RECARGA_DATOS,data,
        function(resultado){
    		if(!resultado.indError){
    			$("#divModalObservacionPopup").modal("hide");
    			var mensajeRpt = "La operación se ha realizado correctamente.";
    			mostrarMensajeOperacion(mensajeRpt, function(){
    				var data0 = {};
         		   recargarGrillaSolicitudes(convertirFormAObject(data0));
    			});
    			
    		}else{
    			mostrarMensajeError("Ha ocurrido un error en el sistema: " + resultado.nomError);
    		}
        }
    );
}

// =================================================================
// utilitarios
// =================================================================

var _msg = {
  		"EX01":"No se encontraron registros",
  		"MS01":"Se realizó con éxito la firma",
  		"CF01":"¿Está seguro de firmar declaración jurada {0}? " 
};

var _acciones = {
	"REGISTRAR":"01",
	"APROBAR":"02",
	"RECHAZAR":"03"
};
