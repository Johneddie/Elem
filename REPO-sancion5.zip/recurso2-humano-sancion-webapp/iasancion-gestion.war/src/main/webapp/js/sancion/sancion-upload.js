// =================================================================
// ARCHIVOS
// =================================================================
var inicializarComponentesArchivo = function(){
	$('#tblDataArchivos').DataTable({
    	columnDefs: [{"targets": [3,4,5,6], "visible": false,"searchable": false},{"className":"text-center", "targets": [2], "visible": true}],
        paging: false,
        ordering: false,
        searching: false,
        info:true,
        select: true,
        language: {
            url: "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        lengthMenu: [[5, 10], [5, 10]],
        select: true,
        retrieve: true 
    });
    
    //buttoms
	$("#btnModificarArchivo").click(function(){
		var desArchivo = $('#desArchivo').val(); 
		var nomArchivo = $('#nomArchivo').val(); 
		
		if(desArchivo == '')
			mostrarMensajeError("Ingrese descripción del archivo.");
		else{
			for(var i=0; i<lista.length; i++){
				var a = lista[i];
				if(a.nomArchivo == nomArchivo ){
					a.desArchivo = desArchivo;
					if(!esVacioNulo(a.numArcdet))
						a.codAccion = '2';
					break;
	    		}
			}
			regresarAdjuntarArchivo();
			renderizarGrillaArchivos(lista);
		}
	});
    
	$("#btnCancelarArchivo").click(function(){
		regresarAdjuntarArchivo();
	});
};


function onClickMostrarGestionarArchivos(){
	//datos de registro
	var indBloquear = $("#codAccion").val() == "02";
	bloquearDatosArchivos(indBloquear);
	
	//limpieza
	$("#frmRegistrarArchivo")[0].reset();			//fields
	limpiarMensajesError("#frmRegistrarArchivo");
	
	//renderización
	renderizarGrillaArchivos(lista);
	bloquearBotonAdjuntar(lista);
    $("#divGestionarArchivos").modal('show');
}

var renderizarGrillaArchivos = function(archivos) {
	var tblDataArchivos = $('#tblDataArchivos').DataTable();
	tblDataArchivos.clear().draw();
	var codAccion = $('#codAccion').val();
	
	$.each(archivos, function(idx, archivo){
		if(archivo.codAccion != '3'){//no eliminado
			var linkDel = '';
			if(codAccion!='02')
				linkDel = '<a href="javascript:onClickEnlaceEliminarArchivo(\''+ archivo.nomArchivo + '\')" data-toggle="tooltip" title="Eliminar" data-html="true" data-placement="left"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;&nbsp;';
			linkDel += '<a id="archivo_'+idx+'" href="javascript:onClickEnlaceDescargarArchivo(' + idx + ')" data-toggle="tooltip" title="Descargar" data-html="true" data-placement="left"><i class="fa fa-download"></i></a>&nbsp;&nbsp;&nbsp;';
			if(codAccion!='02')
				linkDel += '<a href="javascript:onClickEnlaceEditarArchivo(' + idx + ')" data-toggle="tooltip" title="Editar" data-html="true" data-placement="left"><i class="fa fa-edit"></i></a>';
			tblDataArchivos.row.add( [ 
				archivo.nomArchivo, 
				archivo.desArchivo, 
				linkDel, 
				reemplazaNulo(archivo.codAccion),
				reemplazaNulo(archivo.numIdDocum),
				reemplazaNulo(archivo.numArchivo),
				reemplazaNulo(archivo.numArcdet)
				]).draw( true );
		}
	});
};

var onClickEnlaceDescargarArchivo = function(indice){
	var tbl = $('#tblDataArchivos').DataTable();
	var archivo = tbl.row($('#archivo_'+indice).parents('tr')).data();
	
	var formURL = CONTEXT_APP + '/archivo/descargar?numArchivo='+archivo[5]+'&numArcdet='+archivo[6]+'&nomArchivo='+archivo[0];
	document.forms.frmExpedientesExportar.action = formURL;
	document.forms.frmExpedientesExportar.submit();
};


$("#frmArchivoCargar").submit(function(e){
	var formObj = $(this);
	var iframeId = 'unique' + (new Date().getTime());
	var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	iframe.hide();
	formObj.attr('target', iframeId);
	formObj.attr('action', CONTEXT_APP + '/archivo/cargar');
	formObj.attr("enctype", "multipart/form-data");
	formObj.attr("encoding", "multipart/form-data");
	iframe.appendTo('body');
	
	iframe.load(function(e){
		
		var doc = getDoc(iframe[0]);
		var docRoot = doc.body ? doc.body : doc.documentElement;
		var data = docRoot.innerHTML;
		var jsonDataString;
		var response;
		var indError;
		indError = false;
		var indErrorJson = false;
		if (data.toLowerCase().indexOf("error") >= 0 || data.toLowerCase().indexOf("SUNAT Operaciones en Línea") >= 0 ) {
			indError = true;
		}
				
		if(indError) {
			$("#docFisico").val(null);
			mostrarMensajeError("El tamaño de archivo máximo permitido es: 1 MB.");
		} else {		
			if (data.indexOf("<pre style") > -1) {
				jsonDataString = data.replace('<pre style="word-wrap: break-word; white-space: pre-wrap;">', '');
				jsonDataString = jsonDataString.replace('</pre>', '');
			} else {
				jsonDataString = data.replace('<PRE>', '').replace('</PRE>', '').replace('<pre>', '').replace('</pre>', '');
			}
			try{
				response = jQuery.parseJSON(jsonDataString);
			}catch(err) {
				$("#docFisico").val(null);
				mostrarMensajeError("El tamaño de archivo máximo permitido es: 1 MB.");
				indErrorJson = true;
			}
			
			if(!indErrorJson){
				if (response.isTamanoSuperado) {
					var control = $("#docFisico");
					control.replaceWith( control = control.clone( true ) );
					control.val(null);
					mostrarMensajeError("El tamaño de archivo máximo permitido es: " + response.tamanoPermitido + " MB.");
					
				} else if(response.isOtraExtension){
						var control = $("#docFisico");
						control.replaceWith( control = control.clone( true ) );
						control.val(null);
						mostrarMensajeError("Los archivos a adjuntar deben ser de tipo PDF.");
				} else if(response.isNombreSuperado){
						var control = $("#docFisico");
						control.replaceWith( control = control.clone( true ) );
						control.val(null);
						mostrarMensajeError("El nombre del archivo debe tener una longitud menor a 50 letras.");
				} else {
						var control = $("#docFisico");
						control.replaceWith( control = control.clone( true ) );
						control.val(null);
						
						var archivo = new Object();
						archivo.codAccion = '1'; //1 regis, 3 modif
						archivo.nomArchivo = response.nomArchivo;
						archivo.desArchivo = $('#desArchivo').val();
						archivo.numIdDocum = reemplazaNulo($("#numIdDocum").val());
						archivo.numArcdet = '';
						archivo.numArchivo = '';
						agregarArchivo(archivo);
						
						$("#desArchivo").val('');
				}
			}
		}
  });
	
});


var agregarArchivo = function (archivo){
	//existencia
	for(var i=0; i<lista.length; i++){
		var a = lista[i];
		if(a.codAccion!='3' && a.nomArchivo == archivo.nomArchivo){
			mostrarMensajeError("Ya existe un archivo con el mismo nombre.");
			return false;
		}
	}
	//añadir lista
	lista[lista.length] = archivo;
	renderizarGrillaArchivos(lista);
	bloquearBotonAdjuntar(lista);
};


var bloquearBotonAdjuntar = function (lista){
	var lenList = 0;
	for(var i=0; i<lista.length; i++){
		var a = lista[i];
		if(a.codAccion != '3') //3:eliminado
			lenList++;
	}
	if(lenList < 5)
		$('#btnAdjuntarArchivo').prop('disabled', false);
	else
		$('#btnAdjuntarArchivo').prop('disabled', true);
}

var onClickEnlaceEliminarArchivo = function(nomArchivo){
	var mensaje = "¿Está seguro de eliminar el archivo?";
	confirmarOperacion(mensaje, function() {
		for(var i=0; i<lista.length; i++){
			var a = lista[i];
			if(a.nomArchivo == nomArchivo){
				if(!esVacioNulo(a.numArcdet))
					a.codAccion = '3';
				else
					lista.splice(i,1);
				break;
    		}
		}
     	
		renderizarGrillaArchivos(lista);
		$('#btnAdjuntarArchivo').prop('disabled', false);
		

	});
};

var onClickEnlaceEditarArchivo = function(indice){
	var tbl = $('#tblDataArchivos').DataTable();
	var archivo = tbl.row($('#archivo_'+indice).parents('tr')).data();
	$("#desArchivo").val(archivo[1]);
	$("#nomArchivo").val(archivo[0]);
	$("#divArcDdjj").hide();
	
	$("#btnModificarArchivo").show();
	$("#btnCancelarArchivo").show();
	$("#btnAdjuntarArchivo").hide();
};

var regresarAdjuntarArchivo = function(){
	$("#desArchivo").val("");
	$("#divArcDdjj").show();
	
	$("#btnModificarArchivo").hide();
	$("#btnCancelarArchivo").hide();
	$("#btnAdjuntarArchivo").show();
}

function alCambiarArchivo() {
	$('#desArchivo').val('');
}


// =================================================================
// Validaciones
// =================================================================
	
$.validator.addMethod("valDocFisicoLen", function(value, element) {
	var nomDocFisico = $('#docFisico').val().replace(/\\/g, '/').replace(/.*\//, '');
	if (nomDocFisico.length <= 50) {
		return true;
	}
	return false;
}, "El nombre del archivo debe tener máximo 50 caracteres.");
	
$.validator.addMethod("valDocFisicoRegExp", function(value, element) {
	var nomDocFisico = $('#docFisico').val().replace(/\\/g, '/').replace(/.*\//, '');
	var reg = /^[a-zA-Z0-9áéíóúÁÉÍÓÚ\-\_\.\ \(\)]*$/;
	if (reg.test(nomDocFisico)) {
		return true;
	}
	return false;
}, "El nombre del archivo solo permite los siguientes caracteres:  letras, números, guión, subguión y punto.");

$("#frmRegistrarArchivo").validate({
	errorElement: 'span',
	errorClass: 'help-block',
	rules: {
		docFisico:{
			required: true,
			valDocFisicoLen: true,
			valDocFisicoRegExp: true
		},
		desArchivo:{
			required: true,
			maxlength: 50
		}
    },
    messages: {
		docFisico:{
			required: 'Debe seleccionar un archivo a adjuntar.'
		},
		desArchivo:{
			required: 'Ingrese descripción del archivo.',
			maxlength: "La descripción del archivo debe tener máximo 50 caracteres."
		}
	},
	highlight: function (e) {
		if($(e).is("input[tipo^='addon']")) {
			$(e).closest('.custom-form-group').addClass('has-error');
			$(e).addClass('has-error');		
		}else{
			$(e).parent().addClass('has-error');
		}
	},
	success: function (e) {
		$(e).parent().removeClass('has-error');
		$(e).closest('.input-group').removeClass('has-error');
		$(e).remove();
	},
	errorPlacement: function (error, element) {
		if(element.is("input[tipo^='addon']")) {
			error.insertAfter(element.parent());
		}else{
			error.insertAfter(element);	
		}
	},

	submitHandler: function (form) {
		$("#docFisico").appendTo($('#frmArchivoCargar'));
		$('#frmArchivoCargar').submit();
		$("#docFisico").appendTo($('#manejadorArchivo'));
		
	},
	invalidHandler: function (form) {
	}
});



