// =================================================================
// COMPONENTES
// =================================================================
var inicializarComponentesBusqueda = function(){

    $('#divFecRegisIniBusq').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent: false,
    	maxDate: new Date()
    }).on('dp.change', function (ev) {
        return true;
    });
    
    $('#divFecRegisFinBusq').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent: false,
    	maxDate: new Date()
    });
    
  //tables
    var tblDataPersonal = $('#tblDataPersonal').DataTable( {
        paging: true,
        ordering: true,
        searching:false,
        info:true,
        language: {
            url: "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        lengthMenu: [[5, 10], [5, 10]]
    });
	
    var tblDataUnidad = $('#tblDataUnidad').DataTable( {
    	columnDefs: [{targets: [0,2], className: 'text-center'},{className: 'custom-text-overflow', targets: [3]}],
        paging: true,
        ordering: true,
        searching:false,
        info:true,
        language: {
            url: "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        lengthMenu: [[5, 10], [5, 10]]
    });
    
    recargarGrillaExpedientes(convertirFormAObject($("#frmBuscarExpedientes").serializeArray()));
	
};

// =================================================================
// Validaciones 
// =================================================================

var setValidacionesGenericasBusqueda = function(){
	$.validator.addMethod("valFecRegisFinMay", function(value, element) {
		var fi = $('#divFecRegisIniBusq').data('DateTimePicker').date();
		if(fi == null) 
			return true;
		var ff = $('#divFecRegisFinBusq').data('DateTimePicker').date();
		return ff >= fi;
	}, "La fecha fin debe ser mayor o igual a la fecha de inicio.");
	
	$.validator.addMethod("valFecRegisFinMax", function(value, element) {
		var fi = $('#divFecRegisIniBusq').data('DateTimePicker').date();
		if(fi == null) 
			return true;
		var ff = $('#divFecRegisFinBusq').data('DateTimePicker').date();
		var days = Math.round((ff-fi)/(1000*60*60*24));
		return days <= 180;
	}, "En rango de fechas no debe ser mayor a 365 días.");
	
	$.validator.addMethod("valFecRegisFinReq", function(value, element) {
		var fi = $('#divFecRegisIniBusq').data('DateTimePicker').date();
		var ff = $('#divFecRegisFinBusq').data('DateTimePicker').date();
		if(fi != null && ff == null) 
			return false;
		return true;
	}, "Debe ingresar la fecha fin.");
	
	$.validator.addMethod("valFecRegisIniReq", function(value, element) {
		var fi = $('#divFecRegisIniBusq').data('DateTimePicker').date();
		var ff = $('#divFecRegisFinBusq').data('DateTimePicker').date();
		if(fi == null && ff != null) 
			return false;
		return true;
	}, "Debe ingresar la fecha inicio.");
};


var validarBusquedaExpedientes = function(){
	$("#frmBuscarExpedientes").validate({
		errorElement: 'span',
		errorClass: 'help-block',
		rules: {
			fecRegisIniBusq:{
				valFecRegisIniReq: true
			},
			fecRegisFinBusq:{
				valFecRegisFinReq: true,
				valFecRegisFinMay: true,
				valFecRegisFinMax: true
			}
	    },
	    messages: {
		},
		highlight: function (e) {
			if($(e).is("input[tipo^='addon']")) {
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');		
			}else{
				$(e).parent().addClass('has-error');
			}
		},
		success: function (e) {
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[tipo^='addon']")) {
				error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},
	
		submitHandler: function (form) {
	    	recargarGrillaExpedientes(convertirFormAObject($("#frmBuscarExpedientes").serializeArray()));
	    	
		},
		invalidHandler: function (form) {
			console.log("invalidHandler...");
		}
	});
};

// =================================================================
// Personal
// =================================================================

$("#formBuscarUnidad").validate({
	errorElement: 'span',
	errorClass: 'help-block',
	rules: {
		codUorga:{
			pattern:"^([a-zA-Z0-9]*)?$",
			minlength: 3
		},
		desUorga:{
			pattern:"^([a-zA-ZáéíóúÁÉÍÓÚ\' ]*)?$",
			minlength: 3
		}
    },
    messages: {
    	codUorga:{
			pattern:"Caracteres no válidos.",
			minlength:"Ingrese al menos tres caracteres."
		},
		desUorga:{
			pattern:"Caracteres no válidos.",
			minlength:"Ingrese al menos tres caracteres."
		}
	},
	highlight: function (e) {
		if($(e).is("input[id^='fec']")) {
			$(e).closest('.custom-form-group').addClass('has-error');
			$(e).addClass('has-error');		
		}else{
			$(e).parent().addClass('has-error');
		}
	},
	success: function (e) {
		$(e).parent().removeClass('has-error');
		$(e).closest('.input-group').removeClass('has-error');
		$(e).remove();
	},
	errorPlacement: function (error, element) {
		if(element.is("input[id^='fec']")) {
			error.insertAfter(element.parent());
		}else{
			error.insertAfter(element);	
		}
	},
	submitHandler: function (form) {
		//Buscar unidades
		var formulario = $("#formBuscarUnidad");
		var formArray = convertirFormAObject(formulario.serializeArray())
		
		var datosBusqueda = '';
		$.each( formArray, function( key, value ) {
			datosBusqueda += value;
		});
		if(datosBusqueda == ''){
			mostrarMensajeError("Debe ingresar o seleccionar un criterio de búsqueda.");
			return false;
		}
		
    	recargarGrillaUnidad(formArray);
	}
});


$("#formBuscarPersonal").validate({
	errorElement: 'span',
	errorClass: 'help-block',
	rules: {
		apPatePersona:{
			pattern:"^([a-zA-ZáéíóúñÁÉÍÓÚÑ\' ]*)?$",
			minlength: 3
		},
		apMatePersona:{
			pattern:"^([a-zA-ZáéíóúñÁÉÍÓÚÑ\' ]*)?$",
			minlength: 3
		},
		nombresPersona:{
			pattern:"^([a-zA-ZáéíóúñÁÉÍÓÚÑ\' ]*)?$",
			minlength: 3
		},
		codPersPersona:{
			pattern:"^([a-zA-Z0-9]*)?$",
			minlength: 3
		},
		numDocumPersona:{
			pattern:"^([0-9]*)?$",
			minlength: 3
		}
    },
    messages: {
		apPatePersona:{
			pattern:"Caracteres no válidos.",
			minlength:"Ingrese al menos tres caracteres."
		},
		apMatePersona:{
			pattern:"Caracteres no válidos.",
			minlength:"Ingrese al menos tres caracteres."
		},
		nombresPersona:{
			pattern:"Caracteres no válidos.",
			minlength:"Ingrese al menos tres caracteres."
		},
		codPersPersona:{
			pattern:"Caracteres no válidos.",
			minlength:"Ingrese al menos tres caracteres."
		},
		numDocumPersona:{
			pattern:"Caracteres no válidos.",
			minlength:"Ingrese al menos tres caracteres."
		}
	},
	highlight: function (e) {
		if($(e).is("input[id^='fec']")) {
			$(e).closest('.custom-form-group').addClass('has-error');
			$(e).addClass('has-error');		
		}else{
			$(e).parent().addClass('has-error');
		}
	},
	success: function (e) {
		$(e).parent().removeClass('has-error');
		$(e).closest('.input-group').removeClass('has-error');
		$(e).remove();
	},
	errorPlacement: function (error, element) {
		if(element.is("input[id^='fec']")) {
			error.insertAfter(element.parent());
		}else{
			error.insertAfter(element);	
		}
	},

	submitHandler: function (form) {
		//Buscar personal
		var formulario = $("#formBuscarPersonal");
		var formArray = convertirFormAObject(formulario.serializeArray())
		
		var datosBusqueda = '';
		$.each( formArray, function( key, value ) {
			datosBusqueda += value;
		});
		if(datosBusqueda == ''){
			mostrarMensajeError("Debe ingresar o seleccionar un criterio de búsqueda.");
			return false;
		}
		
    	recargarGrillaPersonal(formArray);
	}
});
