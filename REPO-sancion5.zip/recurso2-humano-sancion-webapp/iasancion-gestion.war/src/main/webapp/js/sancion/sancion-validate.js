
var validarDatosRegistro = function(){
	
	//Validaciones genericas:
	setValidacionesGenericas();
	validarExpediente();
	validarDocumento();

};



var setValidacionesGenericas = function(){
	$.validator.addMethod("valIndInfoIntern", function(value, element) {
		return $("#indInfoInternSi").is(':checked') || $("#indInfoInternNo").is(':checked')
	}, "Indique si contempla Información Interna.");
	
	$.validator.addMethod("valFecFinEvenMay", function(value, element) {
		var fi = $('#divFecIniEven').data('DateTimePicker').date();
		if(fi == null) 
			return true;
		var ff = $('#divFecFinEven').data('DateTimePicker').date();
		return ff >= fi;
	}, "La fecha fin debe ser mayor o igual a la fecha de inicio.");
	
	var numDiasDifFecIni = parseInt($('#numDiasDifFecIni').val());
	$.validator.addMethod("valFecIniEvenMax", function(value, element) {
		if(numDiasDifFecIni == null || numDiasDifFecIni == 0)
			numDiasDifFecIni = -9999;
		
		var fi = $('#divFecIniEven').data('DateTimePicker').date();
		if(fi == null) 
			return true;
		var fa = new Date();
		fa.setHours(0,0,0,0);
		var days = Math.round((fi-fa)/(1000*60*60*24));
		return days > numDiasDifFecIni;
	}, "La fecha de inicio debe ser mayor a "+numDiasDifFecIni+" días de la fecha actual.");
	
	
	$.validator.addMethod("valIndRemun", function(value, element) {
		return $("#indRemunSi").is(':checked') || $("#indRemunNo").is(':checked')
	}, "Indique si es Remunerado.");
	
	
	//archivos
	$.validator.addMethod("valDocFisicoReq", function(value, element) {
		var divGroup = $(element).closest(".custom-form-group");
		var divLnkArchivo = divGroup.children("div[id^='lnkArchivo']");
		if(divLnkArchivo.html() == "" && value == "")
			return false;
		return true;
	}, "Adjunte un documento de sustento.");
	
	$.validator.addMethod("valDocFisicoLen", function(value, element) {
		var nomDocFisico = value.replace(/\\/g, '/').replace(/.*\//, '');
		if (nomDocFisico.length <= 50) {
			return true;
		}
		return false;
	}, "El nombre del archivo debe tener máximo 50 caracteres.");
		
	$.validator.addMethod("valDocFisicoRegExp", function(value, element) {
		var nomDocFisico = value.replace(/\\/g, '/').replace(/.*\//, '');
		var reg = /^[a-zA-Z0-9áéíóúÁÉÍÓÚ\-\_\.\ \(\)]*$/;
		if (reg.test(nomDocFisico)) {
			return true;
		}
		return false;
	}, "El nombre del archivo solo permite los siguientes caracteres:  letras, números, guión, subguión y punto.");
	
	$.validator.addMethod("valDescripcionRegExp", function(value, element) {
		var reg = /^[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\-\:\;\.\,\ \(\)\"\n]*$/;
		if (reg.test(value)) {
			return true;
		}
		return false;
	}, "Se ha encontrado caracteres no válidos, solo se permite letras, números, paréntesis, punto y coma.");

};


var validarExpediente = function(){

	var validadorExpediente = $("#formDatosExpediente").validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden",
	  	rules: {
	  		codPersDenun: {
	      		required: true,
	      		pattern:"^([a-zA-Z0-9]{4})?$"
	    	},
	    	codFuenProce: {
	      		required: true
	    	},
	    	codTipExped: {
	      		required: true
	    	},
	    	fecOcurren: {
	      		required: true
	    	},
	    	desOcurren: {
	      		required: true,
	      		valDescripcionRegExp: true 
	    	},
	    	codUnidInstru: {
	      		required: true,
	      		pattern:"^([a-zA-Z0-9]{6})?$"
	    	},
	    	codPersEspec: {
	      		required: true
	    	},
	    	numDiasAtenc: {
	      		required: true,
	      		digits: true
	    	}
	   },
	   messages: {
	  		codPersDenun: {
	      		required: "Ingrese el Registro del Denunciado.",
	      		pattern: "Registro del Denunciado no válido."
	    	},
	    	codFuenProce: {
	      		required: "Seleccione la Fuente de Inicio PAD."
	    	},
	    	codTipExped: {
	      		required: "Seleccione el Tipo de Expediente."
	    	},
	    	fecOcurren: {
	      		required: "Ingrese la Fecha de Ocurrencia."
	    	},
	    	desOcurren: {
	      		required: "Ingrese la Descripción de la Ocurrencia."
	    	},
	    	codUnidInstru: {
	      		required: "Ingrese el Órgano Instructor.",
	      		pattern: "Código de Órgano Instructor no válido."
	    	},
	    	codPersEspec: {
	      		required: "Seleccione al Especialista Responsable."
	    	},
	    	numDiasAtenc: {
	      		required: "Ingrese el número.",
	      		digits: "Número no válido."
	    	}
		},
		highlight: function (e) {
			if($(e).is("input[tipo^='addon']")||$(e).is("select[tipo^='addon']")) {
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');		
			}else{
				$(e).parent().addClass('has-error');
			}
		},
		success: function (e) {
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[tipo^='addon']")||element.is("select[tipo^='addon']")) {
				if(element.attr("type") == 'radio')
					error.insertAfter(element.parent().parent());
				else
					error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},

		submitHandler: function (form) {
			//alert("ok");
			
			if(lstDocumentos.length == 0){
				mostrarMensajeError("Debe agregar un Documento al Expediente.");
				return false;
			}else{
				var formulario = $("#formDatosExpediente");
				var object = convertirFormAObject(formulario.serializeArray())
				object.documentos = lstDocumentos;
				
				delete object.tblDataDocumentos_length;
				registrarExpediente(object);
			}

		},
		invalidHandler: function (form) {
		}
	});
};

// ===========
// Seguimiento
// ===========

var validarActualizarEstado = function(){
	
	$.validator.addMethod("valDesObservReq", function(value, element) {
		var codAccion = $('#codAccionAccion').val();
		if(codAccion == _acciones.DEVOLVER || codAccion == _acciones.RECHAZAR){
			if(esVacioNulo(value))
				return false;
		}
		return true;
	}, "Debe ingresar una Observación.");
	
	$("#formObservacion").validate({
		errorElement: 'span',
		errorClass: 'help-block',
		rules: {
			desObserv:{
				valDesObservReq: true
			}
	    },
	    messages: {
		},
		highlight: function (e) {
			$(e).parent().addClass('has-error');
		},
		success: function (e) {
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			error.insertAfter(element);	
		},
	
		submitHandler: function (form) {
			registrarAccionSolicitudAjax();
		},
		invalidHandler: function (form) {
			console.log("invalidHandler...");
		}
	});
};

// =========
// Documento
// =========
 
var validarDocumento = function(){

	var validadorDocumento = $("#formDatosDocumento").validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden",
	  	rules: {
	  		codTipDocum: {
	      		required: true
	    	},
	  		numDocum: {
	      		required: true,
	      		pattern:"^([a-zA-Z0-9\-]*)?$"
	    	},
	  		numInform: {
	      		required: true,
	      		pattern:"^([a-zA-Z0-9\-]*)?$"
	    	},
	    	codUnidEmis: {
	      		required: true,
	      		pattern:"^([a-zA-Z0-9]{6})?$"
	    	},
	  		desObserva: {
	      		required: true,
	      		valDescripcionRegExp: true 
	    	},
	  		fecRecepcion: {
	      		required: true
	    	}
	   },
	   messages: {
	  		codTipDocum: {
	      		required: "Ingrese el Tipo de Documento."
	    	},
	  		numDocum: {
	      		required: "Ingrese el Número de Documento.",
	      		pattern: "Número de Documento no válido. Solo se permite letras, números."
	    	},
	  		numInform: {
	      		required: "Ingrese el Número de Informe.",
	      		pattern: "Número de Documento no válido. Solo se permite letras, números."
	    	},
	    	codUnidEmis: {
	      		required: "Ingrese la Unidad de Emisión.",
	      		pattern: "Código de Unidad de Emisión no válido."
	    	},
	  		desObserva: {
	      		required: "Ingrese la Observación"
	    	},
	  		fecRecepcion: {
	      		required: "Ingrese la Fecha de Recepción."
	    	}
		},
		highlight: function (e) {
			if($(e).is("input[tipo^='addon']")||$(e).is("select[tipo^='addon']")) {
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');		
			}else{
				$(e).parent().addClass('has-error');
			}
		},
		success: function (e) {
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[tipo^='addon']")||element.is("select[tipo^='addon']")) {
				if(element.attr("type") == 'radio')
					error.insertAfter(element.parent().parent());
				else
					error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},

		submitHandler: function (form) {
			var formulario = $("#formDatosDocumento");
			var object = convertirFormAObject(formulario.serializeArray())
			object.desTipDocum = $("#codTipDocum option:selected").text();
			
			object.archivos = lista;
			agregarDocumentoObj(object);
			$("#divModalDocumentoPopup").modal("hide");
			/*if(lstHorarios.length == 0){
				mostrarMensajeError("Debe agregar el Horario del Evento.");
				return false;
			}else{
				var formulario = $("#formDatosSolicitud");
				var object = convertirFormAObject(formulario.serializeArray())
				object.horarios = lstHorarios;
				object.nomCentro = $("#lblNomCentro").text();
				
				var indRemun = $("input[name=indRemun]:checked").val();
				if(indRemun == '0'){
					delete object.codCateg;
					delete object.mtoRemun;
				}
				registrarSolicitud(object);
			}*/

		},
		invalidHandler: function (form) {
		}
	});
};