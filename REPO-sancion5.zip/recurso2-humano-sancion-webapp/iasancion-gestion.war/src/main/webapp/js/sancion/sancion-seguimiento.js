		// =================================================================
		// Seguimientos 
		// =================================================================
		
		function onClickMostrarSeguimientos(indice){
			var tbl = $('#tblDataExpedientes').DataTable();
			var d = tbl.row(indice).data();
			var data = {};
			data.numIdExped = d.numIdExped;
			recargarGrillaSeguimientos(data);
			var divDesEstadoSeguim = "Número: <label style='margin-bottom: 0px;'>EXP"+d.numAnio+padCorrel(d.numCorrel)+"</label>&nbsp;&nbsp;"+
							     "Estado: <label style='margin-bottom: 0px;' >"+d.desEstado+"</label>"+
							     "<hr style='margin-top: 5px;margin-bottom: 15px;'>";
			$("#divDesEstadoSeguim").html(divDesEstadoSeguim);
			
			
		}
		
		var recargarGrillaSeguimientos = function(data){
			var URL_RECARGA_DATOS = CONTEXT_APP+"/expedienteSancion/seguimiento/listar";
		    $.post(URL_RECARGA_DATOS,data,
		        function(resultado){
					renderizarGrillaSeguimientos(resultado);
					$("#divDatosSeguimientos").modal('show');
		        }
		    );
		};
		
		var renderizarGrillaSeguimientos = function(data){
			var tblDataSeguimientos = $('#tblDataSeguimientos').DataTable( {
				"order": [[ 0, "desc" ]],
				paging: true,
				searching:false,
				info:true,
				language: {
					url: "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
				},
				lengthMenu: [[5, 10], [5, 10]],
				select: true,
				//scrollX: true,
				//responsive:true,
				destroy: true,
				data: data,
				columns: [
					{data: 'numSeguim', 'class':'text-center'},
        	        {data: 'fecRegis', 'class':'text-center'},
        	        {data: 'codPersOrig', 'class':'custom-text-overflow', render:function(d, t, r, m){
        	        	var nomPers = '';
        	        	if(r.codPersOrig!=null)
        	        		nomPers = r.codPersOrig + ' - ' + r.nomPersOrig;
        	        	return nomPers;
        	        }},
        	        {data: 'codPersDest', 'class':'custom-text-overflow', render:function(d, t, r, m){
        	        	var nomPers = '';
        	        	if(r.codPersDest!=null)
        	        		nomPers = r.codPersDest + ' - ' + r.nomPersDest;
        	        	return nomPers;
        	        }},
        	        {data: 'desFaseDest', 'class':'text-center', render:function(d, t, r, m){
        	        	return "<label class='font-weight-normal'>"+r.desFaseDest+"</label>";
        	        }},
        	        {data: 'desEstado', 'class':'text-center', render:function(d, t, r, m){
        	        	return "<label class='font-weight-normal'>"+r.desEstado+"</label>";
        	        }}
				],
				"drawCallback": function( settings ) {
					$('[data-toggle="tooltip"]').tooltip();
				}
			});
			
		};