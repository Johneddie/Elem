// =================================================================
// Inicializar componentes nuevo
// =================================================================

var inicializarComponentesExpediente = function(){
    $("#btnNuevoExpediente").click(function(){
    	iniciarRegistroDatosExpediente();
    });
	
	$("#codPersDenun").change(function(){
    	var codPersDenun = $.trim($(this).val()).toUpperCase();
    	if(codPersDenun.length == 4){
    		obtenerDatosPersona(codPersDenun);
    	}else{
			$("#nomPersDenun").val('');
			$("#codTipDocumDenun").val('');
			$("#numDocumDenun").val('');
			$("#desDirecDenun").val('');
			$("#desUbigDenun").val('');
    	}
    });
	
	$("#codUnidInstru").change(function(){
    	var codUnidInstru = $.trim($(this).val()).toUpperCase();
    	if(codUnidInstru.length == 6){
    		obtenerDatosUnidadOrg(codUnidInstru, "nomUnidInstru");
    	}else{
			$("#nomUnidInstru").val('');
    	}
    });
	
	$("#codUnidEmis").change(function(){
    	var codUnidEmis = $.trim($(this).val()).toUpperCase();
    	if(codUnidEmis.length == 6){
    		obtenerDatosUnidadOrg(codUnidEmis, "nomUnidEmis");
    	}else{
			$("#nomUnidEmis").val('');
    	}
    });
	
    $('#divFecOcurren').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent: false,
    	maxDate: new Date()
    }).on('dp.change', function (ev) {
        return true;
    });
    
    $('#divFecRecepcion').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent: false,
    	maxDate: new Date()
    }).on('dp.change', function (ev) {
        return true;
    });
    
    $("#btnNuevoDocumento").click(function(){
    	var numIdExped = $("#numIdExped").val();
    	if(esVacioNulo(numIdExped) && lstDocumentos.length == 1)
    		mostrarMensajeError("Solo puede agregar un Documento de Inicio.")
    	else
    		iniciarRegistroDatosDocumento();
    });
    
    $("#btnExportarExpedientes").click(function(){
    	if($("#frmBuscarExpedientes").valid()){
    		var obj = convertirFormAObject($("#frmBuscarExpedientes").serializeArray());
			var formURL = CONTEXT_APP + '/expedienteSancion/expedientes/exportar?codTipExpedBusq='+obj.codTipExpedBusq+'&fecRegisIniBusq='+obj.fecRegisIniBusq+'&fecRegisFinBusq='+obj.fecRegisFinBusq;
			document.forms.frmExpedientesExportar.action = formURL;
			document.forms.frmExpedientesExportar.submit();
    	}
    });
	
};



// =================================================================
// BÚSQUEDA DE PERSONA DNI
// =================================================================

function onClickBuscarContribuyente(numRuc){
	
	$("#lblNomCentro").text("");
	
	if(!esVacioNulo(numRuc) && numRuc.length == 11 && esTextoNumero(numRuc)){
		
		var URL_OBTENER = CONTEXT_APP+"/solicitudAutoriza/centroEstudio/"+numRuc;
	    $.ajax({type: "POST",url: URL_OBTENER, dataType: 'json', contentType: "application/json; charset=utf-8",
	        success: function(s){
	        	if(s.indError == '0' && s.contribuyente != null){
	        		$("#lblNomCentro").text(s.contribuyente.nomContrib);
	        	}else{
	        		$("#numRucCentro").val("");
	        		mostrarMensajeError("No se ha encontrado datos para el RUC ingresado.");
	        	}
	        }
	    });

	}
}

// ===============
// agregar horario
// ===============

var onClickAgregarHorario = function(){
	//validaciones
	var codDiaEven = $('#codDiaEvenDetalle').val();
	var desHorIni = $('#desHorIniDetalle').val();
	var desHorFin = $('#desHorFinDetalle').val();
	
	//validaciones
	if(codDiaEven == ''){
		mostrarMensajeError("Debe seleccionar el día del evento.");
		return false;
	}
	if(desHorIni == ''){
		mostrarMensajeError("Debe ingresar una hora de inicio válida.");
		return false;
	}
	if(desHorFin == ''){
		mostrarMensajeError("Debe ingresar una hora fin válida.");
		return false;
	}

	var hi = $('#divDesHorIniDetalle').data('DateTimePicker').date().toDate();
	var hf = $('#divDesHorFinDetalle').data('DateTimePicker').date().toDate();
	hi.setFullYear(2000, 0, 1);
	hf.setFullYear(2000, 0, 1);
	if(hi >= hf){
		mostrarMensajeError("La hora fin debe ser mayor a la hora de inicio.");
		return false;
	}
	
	//existencia
	for(var i=0;i<lstHorarios.length;i++){
		var e = lstHorarios[i];
		if(e.codDiaEven==codDiaEven && e.desHorIni==desHorIni && e.desHorFin==desHorFin){
			mostrarMensajeError("El rango de horas no debe repetirse.");
    		return false;
		}
	}
    	
	//horario
	var horario = {};
	horario.codDiaEven = codDiaEven;
	horario.desHorIni = desHorIni;
	horario.desHorFin = desHorFin;
	horario.nomDiaEven = $("#codDiaEvenDetalle option:selected").text();
	
	lstHorarios.push(horario);
	renderizarTableHorarios(lstHorarios,'1');
	$('#codDiaEvenDetalle,#desHorIniDetalle,#desHorFinDetalle').val('');
}

var onClickEliminarHorario = function(indiceEliminar){
	var indiceEncontrado;
	$.each(lstHorarios, function( i, puesto ){
		if(indiceEliminar == i){
			indiceEncontrado = i;
			return false;
		}
	});
	if(indiceEncontrado!=null){
		lstHorarios.splice(indiceEncontrado, 1);
		renderizarTableHorarios(lstHorarios,'1');
	}
}

/* accion
 * 01: registrar
 * 02: ver
 * 03: aprobar
 */


var configurarFooterPopupBotones = function(form, accion){
	$(form + " :input[id^='btn']").hide();
	
	if(accion == '01'){ //registrar
		$(form + " :input[id^='btnCerrar']").show();
		$(form + " :input[id^='btnRegistrar']").show();
		$(form + " :input[id^='btnAgregar']").show();
		
	}else if(accion == '02'){ //ver
		$(form + " :input[id^='btnCerrar']").show();
		
		
	}else if(accion == '03'){ //aprobar
		$(form + " :input[id^='btnCerrar']").show();
		$(form + " :input[id^='btnAprobar']").show();
		$(form + " :input[id^='btnRechazar']").show();
	}
};


// ===============================================================================================
// FORMACIÓN ACADÉMICA
// ===============================================================================================

var iniciarRegistroDatosExpediente = function(){
	limpiarMensajesError("#formDatosExpediente");
	$('#formDatosExpediente').trigger("reset");
	
	lstDocumentos = [];
	renderizarGrillaDocumentos(lstDocumentos);
	
	$("#numIdExped").val('');
	$("#codFaseAct").val(_fases.PRECALI);
	
	$("#divDesEstadoExpediente").html(lblCabeceraPopupNuevo);
	/*configurarFooterPopupBotones("#formDatosExpediente", '01');*/
	//configurarDesarrollo();//borrar!
	
	onClickIrExpediente();
};

var iniciarRegistroDatosDocumento = function(){
	limpiarMensajesError("#formDatosDocumento");
	$('#formDatosDocumento').trigger("reset");
	
	recargarTiposDocumento(_tiposDocum.REGISTR);

	$("#numIdDocum").val('');

	bloquearDatosDocumento(false);
	bloquearDatosArchivos(false);
	$("#codAccion").val("01");
	lista = [];
	
	$("#divModalDocumentoPopup").modal('show');
};


var configurarDesarrollo = function(){

}

var lblCabeceraPopupNuevo = "Número: <label style='margin-bottom: 0px;'>SIN NÚMERO</label>&nbsp;&nbsp;"+
"Estado: <label style='margin-bottom: 0px;'>NUEVO</label>"+
"<hr style='margin-top: 5px;margin-bottom: 15px;'>";


var configurarCabeceraPopup = function(r){
	return "Número: <label style='margin-bottom: 0px;'>EXP"+r.numAnio+padCorrel(r.numCorrel)+" </label>&nbsp;&nbsp;"+
		     "Estado: <label style='margin-bottom: 0px;' >"+r.desEstado+"</label>"+
		     "<hr style='margin-top: 5px;margin-bottom: 15px;'>";
}


var onClickEditarOpcionDatosExpediente = function(d, accion){
	limpiarMensajesError("#formDatosExpediente");
	$('#formDatosExpediente').trigger("reset");
	
	var URL_DOCUMENTO = CONTEXT_APP+"/expedienteSancion/expediente/"+d.numIdExped;
	$.getJSON(URL_DOCUMENTO, function(r) {
		
		$("#divDesEstadoExpediente").html(configurarCabeceraPopup(d));
		
		//datos
		$("#numIdExped").val(r.numIdExped);
		$("#codPersDenun").val(r.codPersDenun).change();
		$("#codFuenProce").val(r.codFuenProce);
		$("#codFaseAct").val(r.codFaseAct);
		$("#codTipExped").val(r.codTipExped);
		$("#fecOcurren").val(r.fecOcurren);
		$("#desOcurren").val(r.desOcurren);
		$("#codUnidInstru").val(r.codUnidInstru).change();
		$("#codSancPreca").val(r.codSancPreca).change();
		$("#codSancInstru").val(r.codSancInstru).change();
		$("#codSancSanci").val(r.codSancSanci);
		$("#codPersEspec").val(r.codPersEspec);
		$("#numDiasAtenc").val(r.numDiasAtenc);
		
		//detalle
		lstDocumentos = r.documentos;
		renderizarGrillaDocumentos(lstDocumentos/*, '0'*/);
		
		onClickIrExpediente();
		
	}).error(function(){mostrarMensajeError("Ha ocurrido un error en el sistema.");});
};


var onClickEditarOpcionDatosDocumento = function(d, accion){
	limpiarMensajesError("#formDatosDocumento");
	$('#formDatosDocumento').trigger("reset");
	
	//datos
	$("#numIdDocum").val(d.numIdDocum);
	recargarTiposDocumento("01",d.codTipDocum)
	
	$("#numDocum").val(d.numDocum);
	$("#numInform").val(d.numInform);
	$("#desObserva").val(d.desObserva);
	$("#codUnidEmis").val(d.codUnidEmis).change();
	$("#fecRecepcion").val(d.fecRecepcion);
	lista = d.archivos;
	
	$("#divModalDocumentoPopup").modal('show');
	
	if(accion == "02")
		bloquearDatosDocumento(true);
	else
		bloquearDatosDocumento(false);
};

var bloquearDatosDocumento = function(indBloqueo){
	$("#codTipDocum").prop("disabled",indBloqueo);
	$("#numDocum").prop("disabled",indBloqueo);
	$("#numInform").prop("disabled",indBloqueo);
	$("#desObserva").prop("disabled",indBloqueo);
	$("#codUnidEmis").prop("disabled",indBloqueo);
	$("#fecRecepcion").prop("disabled",indBloqueo);
	if(indBloqueo)
		$("#btnRegistrarDocum").hide();
	else
		$("#btnRegistrarDocum").show();
}

var bloquearDatosArchivos = function(indBloqueo){
	if(indBloqueo)
		$("#divRegistroArchivo").hide();
	else
		$("#divRegistroArchivo").show();
}

function registrarExpediente(object){
	
	var mensaje = "¿Está seguro de registrar y enviar el expediente al especialista?";
	confirmarOperacion(mensaje, function() {
		
		var data = $.toJSON(object);
		var url = CONTEXT_APP+"/expedienteSancion/registrar";
		$("#btnRegistrarExpediente").prop('disabled', true);
		
	    $.ajax({
	           type: "POST",
	           url: url,
	           dataType: 'json',	
	           data: data, 
	           contentType: "application/json; charset=utf-8",
	           success: function(resultado){
	        	   
	        	   $("#btnRegistrarExpediente").prop('disabled', false);
        		   if(resultado.indError == "0"){
        			   
	        		   mostrarMensajeExitoDeclaracion("El Expediente "+resultado.numIdExped+" ha sido registrado correctamente.");
	        		   onClickRegresarConsulta();
	        		   
	        		   var data = {};
	        		   recargarGrillaExpedientes(convertirFormAObject(data));
	        	   }else{	        		   
	        		   mostrarMensajeError("Ha ocurrido un error en el sistema: " + resultado.nomError);   
	        	   }   
	           }
	   });
	});
}

