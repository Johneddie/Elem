package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DocumentoSanciExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public DocumentoSanciExample() {
        oredCriteria = new ArrayList<>();
    }

    protected DocumentoSanciExample(DocumentoSanciExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andNumIdDocumIsNull() {
            addCriterion("num_id_docum is null");
            return this;
        }

        public Criteria andNumIdDocumIsNotNull() {
            addCriterion("num_id_docum is not null");
            return this;
        }

        public Criteria andNumIdDocumEqualTo(Integer value) {
            addCriterion("num_id_docum =", value, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumNotEqualTo(Integer value) {
            addCriterion("num_id_docum <>", value, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumGreaterThan(Integer value) {
            addCriterion("num_id_docum >", value, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_id_docum >=", value, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumLessThan(Integer value) {
            addCriterion("num_id_docum <", value, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumLessThanOrEqualTo(Integer value) {
            addCriterion("num_id_docum <=", value, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumIn(List<Integer> values) {
            addCriterion("num_id_docum in", values, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumNotIn(List<Integer> values) {
            addCriterion("num_id_docum not in", values, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumBetween(Integer value1, Integer value2) {
            addCriterion("num_id_docum between", value1, value2, "numIdDocum");
            return this;
        }

        public Criteria andNumIdDocumNotBetween(Integer value1, Integer value2) {
            addCriterion("num_id_docum not between", value1, value2, "numIdDocum");
            return this;
        }

        public Criteria andNumIdExpedIsNull() {
            addCriterion("num_id_exped is null");
            return this;
        }

        public Criteria andNumIdExpedIsNotNull() {
            addCriterion("num_id_exped is not null");
            return this;
        }

        public Criteria andNumIdExpedEqualTo(Integer value) {
            addCriterion("num_id_exped =", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotEqualTo(Integer value) {
            addCriterion("num_id_exped <>", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedGreaterThan(Integer value) {
            addCriterion("num_id_exped >", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_id_exped >=", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedLessThan(Integer value) {
            addCriterion("num_id_exped <", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedLessThanOrEqualTo(Integer value) {
            addCriterion("num_id_exped <=", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedIn(List<Integer> values) {
            addCriterion("num_id_exped in", values, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotIn(List<Integer> values) {
            addCriterion("num_id_exped not in", values, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedBetween(Integer value1, Integer value2) {
            addCriterion("num_id_exped between", value1, value2, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotBetween(Integer value1, Integer value2) {
            addCriterion("num_id_exped not between", value1, value2, "numIdExped");
            return this;
        }

        public Criteria andCodPersDenunIsNull() {
            addCriterion("cod_pers_denun is null");
            return this;
        }

        public Criteria andCodPersDenunIsNotNull() {
            addCriterion("cod_pers_denun is not null");
            return this;
        }

        public Criteria andCodPersDenunEqualTo(String value) {
            addCriterion("cod_pers_denun =", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunNotEqualTo(String value) {
            addCriterion("cod_pers_denun <>", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunGreaterThan(String value) {
            addCriterion("cod_pers_denun >", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pers_denun >=", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunLessThan(String value) {
            addCriterion("cod_pers_denun <", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunLessThanOrEqualTo(String value) {
            addCriterion("cod_pers_denun <=", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunLike(String value) {
            addCriterion("cod_pers_denun like", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunNotLike(String value) {
            addCriterion("cod_pers_denun not like", value, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunIn(List<String> values) {
            addCriterion("cod_pers_denun in", values, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunNotIn(List<String> values) {
            addCriterion("cod_pers_denun not in", values, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunBetween(String value1, String value2) {
            addCriterion("cod_pers_denun between", value1, value2, "codPersDenun");
            return this;
        }

        public Criteria andCodPersDenunNotBetween(String value1, String value2) {
            addCriterion("cod_pers_denun not between", value1, value2, "codPersDenun");
            return this;
        }

        public Criteria andCodTipDocumIsNull() {
            addCriterion("cod_tip_docum is null");
            return this;
        }

        public Criteria andCodTipDocumIsNotNull() {
            addCriterion("cod_tip_docum is not null");
            return this;
        }

        public Criteria andCodTipDocumEqualTo(String value) {
            addCriterion("cod_tip_docum =", value, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumNotEqualTo(String value) {
            addCriterion("cod_tip_docum <>", value, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumGreaterThan(String value) {
            addCriterion("cod_tip_docum >", value, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tip_docum >=", value, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumLessThan(String value) {
            addCriterion("cod_tip_docum <", value, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_tip_docum <=", value, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumLike(String value) {
            addCriterion("cod_tip_docum like", value, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumNotLike(String value) {
            addCriterion("cod_tip_docum not like", value, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumIn(List<String> values) {
            addCriterion("cod_tip_docum in", values, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumNotIn(List<String> values) {
            addCriterion("cod_tip_docum not in", values, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumBetween(String value1, String value2) {
            addCriterion("cod_tip_docum between", value1, value2, "codTipDocum");
            return this;
        }

        public Criteria andCodTipDocumNotBetween(String value1, String value2) {
            addCriterion("cod_tip_docum not between", value1, value2, "codTipDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumInformIsNull() {
            addCriterion("num_inform is null");
            return this;
        }

        public Criteria andNumInformIsNotNull() {
            addCriterion("num_inform is not null");
            return this;
        }

        public Criteria andNumInformEqualTo(String value) {
            addCriterion("num_inform =", value, "numInform");
            return this;
        }

        public Criteria andNumInformNotEqualTo(String value) {
            addCriterion("num_inform <>", value, "numInform");
            return this;
        }

        public Criteria andNumInformGreaterThan(String value) {
            addCriterion("num_inform >", value, "numInform");
            return this;
        }

        public Criteria andNumInformGreaterThanOrEqualTo(String value) {
            addCriterion("num_inform >=", value, "numInform");
            return this;
        }

        public Criteria andNumInformLessThan(String value) {
            addCriterion("num_inform <", value, "numInform");
            return this;
        }

        public Criteria andNumInformLessThanOrEqualTo(String value) {
            addCriterion("num_inform <=", value, "numInform");
            return this;
        }

        public Criteria andNumInformLike(String value) {
            addCriterion("num_inform like", value, "numInform");
            return this;
        }

        public Criteria andNumInformNotLike(String value) {
            addCriterion("num_inform not like", value, "numInform");
            return this;
        }

        public Criteria andNumInformIn(List<String> values) {
            addCriterion("num_inform in", values, "numInform");
            return this;
        }

        public Criteria andNumInformNotIn(List<String> values) {
            addCriterion("num_inform not in", values, "numInform");
            return this;
        }

        public Criteria andNumInformBetween(String value1, String value2) {
            addCriterion("num_inform between", value1, value2, "numInform");
            return this;
        }

        public Criteria andNumInformNotBetween(String value1, String value2) {
            addCriterion("num_inform not between", value1, value2, "numInform");
            return this;
        }

        public Criteria andFecEmisionIsNull() {
            addCriterion("fec_emision is null");
            return this;
        }

        public Criteria andFecEmisionIsNotNull() {
            addCriterion("fec_emision is not null");
            return this;
        }

        public Criteria andFecEmisionEqualTo(Date value) {
            addCriterionForJDBCDate("fec_emision =", value, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_emision <>", value, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_emision >", value, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_emision >=", value, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionLessThan(Date value) {
            addCriterionForJDBCDate("fec_emision <", value, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_emision <=", value, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionIn(List<Date> values) {
            addCriterionForJDBCDate("fec_emision in", values, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_emision not in", values, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_emision between", value1, value2, "fecEmision");
            return this;
        }

        public Criteria andFecEmisionNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_emision not between", value1, value2, "fecEmision");
            return this;
        }

        public Criteria andFecRecepcionIsNull() {
            addCriterion("fec_recepcion is null");
            return this;
        }

        public Criteria andFecRecepcionIsNotNull() {
            addCriterion("fec_recepcion is not null");
            return this;
        }

        public Criteria andFecRecepcionEqualTo(Date value) {
            addCriterionForJDBCDate("fec_recepcion =", value, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_recepcion <>", value, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_recepcion >", value, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_recepcion >=", value, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionLessThan(Date value) {
            addCriterionForJDBCDate("fec_recepcion <", value, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_recepcion <=", value, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionIn(List<Date> values) {
            addCriterionForJDBCDate("fec_recepcion in", values, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_recepcion not in", values, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_recepcion between", value1, value2, "fecRecepcion");
            return this;
        }

        public Criteria andFecRecepcionNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_recepcion not between", value1, value2, "fecRecepcion");
            return this;
        }

        public Criteria andFecNotificaIsNull() {
            addCriterion("fec_notifica is null");
            return this;
        }

        public Criteria andFecNotificaIsNotNull() {
            addCriterion("fec_notifica is not null");
            return this;
        }

        public Criteria andFecNotificaEqualTo(Date value) {
            addCriterionForJDBCDate("fec_notifica =", value, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_notifica <>", value, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_notifica >", value, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_notifica >=", value, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaLessThan(Date value) {
            addCriterionForJDBCDate("fec_notifica <", value, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_notifica <=", value, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaIn(List<Date> values) {
            addCriterionForJDBCDate("fec_notifica in", values, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_notifica not in", values, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_notifica between", value1, value2, "fecNotifica");
            return this;
        }

        public Criteria andFecNotificaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_notifica not between", value1, value2, "fecNotifica");
            return this;
        }

        public Criteria andNumArchDocumIsNull() {
            addCriterion("num_arch_docum is null");
            return this;
        }

        public Criteria andNumArchDocumIsNotNull() {
            addCriterion("num_arch_docum is not null");
            return this;
        }

        public Criteria andNumArchDocumEqualTo(Integer value) {
            addCriterion("num_arch_docum =", value, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumNotEqualTo(Integer value) {
            addCriterion("num_arch_docum <>", value, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumGreaterThan(Integer value) {
            addCriterion("num_arch_docum >", value, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_arch_docum >=", value, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumLessThan(Integer value) {
            addCriterion("num_arch_docum <", value, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumLessThanOrEqualTo(Integer value) {
            addCriterion("num_arch_docum <=", value, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumIn(List<Integer> values) {
            addCriterion("num_arch_docum in", values, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumNotIn(List<Integer> values) {
            addCriterion("num_arch_docum not in", values, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumBetween(Integer value1, Integer value2) {
            addCriterion("num_arch_docum between", value1, value2, "numArchDocum");
            return this;
        }

        public Criteria andNumArchDocumNotBetween(Integer value1, Integer value2) {
            addCriterion("num_arch_docum not between", value1, value2, "numArchDocum");
            return this;
        }

        public Criteria andDesObservaIsNull() {
            addCriterion("des_observa is null");
            return this;
        }

        public Criteria andDesObservaIsNotNull() {
            addCriterion("des_observa is not null");
            return this;
        }

        public Criteria andDesObservaEqualTo(String value) {
            addCriterion("des_observa =", value, "desObserva");
            return this;
        }

        public Criteria andDesObservaNotEqualTo(String value) {
            addCriterion("des_observa <>", value, "desObserva");
            return this;
        }

        public Criteria andDesObservaGreaterThan(String value) {
            addCriterion("des_observa >", value, "desObserva");
            return this;
        }

        public Criteria andDesObservaGreaterThanOrEqualTo(String value) {
            addCriterion("des_observa >=", value, "desObserva");
            return this;
        }

        public Criteria andDesObservaLessThan(String value) {
            addCriterion("des_observa <", value, "desObserva");
            return this;
        }

        public Criteria andDesObservaLessThanOrEqualTo(String value) {
            addCriterion("des_observa <=", value, "desObserva");
            return this;
        }

        public Criteria andDesObservaLike(String value) {
            addCriterion("des_observa like", value, "desObserva");
            return this;
        }

        public Criteria andDesObservaNotLike(String value) {
            addCriterion("des_observa not like", value, "desObserva");
            return this;
        }

        public Criteria andDesObservaIn(List<String> values) {
            addCriterion("des_observa in", values, "desObserva");
            return this;
        }

        public Criteria andDesObservaNotIn(List<String> values) {
            addCriterion("des_observa not in", values, "desObserva");
            return this;
        }

        public Criteria andDesObservaBetween(String value1, String value2) {
            addCriterion("des_observa between", value1, value2, "desObserva");
            return this;
        }

        public Criteria andDesObservaNotBetween(String value1, String value2) {
            addCriterion("des_observa not between", value1, value2, "desObserva");
            return this;
        }

        public Criteria andCodUnidEmisIsNull() {
            addCriterion("cod_unid_emis is null");
            return this;
        }

        public Criteria andCodUnidEmisIsNotNull() {
            addCriterion("cod_unid_emis is not null");
            return this;
        }

        public Criteria andCodUnidEmisEqualTo(String value) {
            addCriterion("cod_unid_emis =", value, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisNotEqualTo(String value) {
            addCriterion("cod_unid_emis <>", value, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisGreaterThan(String value) {
            addCriterion("cod_unid_emis >", value, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_unid_emis >=", value, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisLessThan(String value) {
            addCriterion("cod_unid_emis <", value, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisLessThanOrEqualTo(String value) {
            addCriterion("cod_unid_emis <=", value, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisLike(String value) {
            addCriterion("cod_unid_emis like", value, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisNotLike(String value) {
            addCriterion("cod_unid_emis not like", value, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisIn(List<String> values) {
            addCriterion("cod_unid_emis in", values, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisNotIn(List<String> values) {
            addCriterion("cod_unid_emis not in", values, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisBetween(String value1, String value2) {
            addCriterion("cod_unid_emis between", value1, value2, "codUnidEmis");
            return this;
        }

        public Criteria andCodUnidEmisNotBetween(String value1, String value2) {
            addCriterion("cod_unid_emis not between", value1, value2, "codUnidEmis");
            return this;
        }

        public Criteria andCodFaseDocumIsNull() {
            addCriterion("cod_fase_docum is null");
            return this;
        }

        public Criteria andCodFaseDocumIsNotNull() {
            addCriterion("cod_fase_docum is not null");
            return this;
        }

        public Criteria andCodFaseDocumEqualTo(String value) {
            addCriterion("cod_fase_docum =", value, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumNotEqualTo(String value) {
            addCriterion("cod_fase_docum <>", value, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumGreaterThan(String value) {
            addCriterion("cod_fase_docum >", value, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_fase_docum >=", value, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumLessThan(String value) {
            addCriterion("cod_fase_docum <", value, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_fase_docum <=", value, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumLike(String value) {
            addCriterion("cod_fase_docum like", value, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumNotLike(String value) {
            addCriterion("cod_fase_docum not like", value, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumIn(List<String> values) {
            addCriterion("cod_fase_docum in", values, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumNotIn(List<String> values) {
            addCriterion("cod_fase_docum not in", values, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumBetween(String value1, String value2) {
            addCriterion("cod_fase_docum between", value1, value2, "codFaseDocum");
            return this;
        }

        public Criteria andCodFaseDocumNotBetween(String value1, String value2) {
            addCriterion("cod_fase_docum not between", value1, value2, "codFaseDocum");
            return this;
        }

        public Criteria andIndDocInicioIsNull() {
            addCriterion("ind_doc_inicio is null");
            return this;
        }

        public Criteria andIndDocInicioIsNotNull() {
            addCriterion("ind_doc_inicio is not null");
            return this;
        }

        public Criteria andIndDocInicioEqualTo(String value) {
            addCriterion("ind_doc_inicio =", value, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioNotEqualTo(String value) {
            addCriterion("ind_doc_inicio <>", value, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioGreaterThan(String value) {
            addCriterion("ind_doc_inicio >", value, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioGreaterThanOrEqualTo(String value) {
            addCriterion("ind_doc_inicio >=", value, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioLessThan(String value) {
            addCriterion("ind_doc_inicio <", value, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioLessThanOrEqualTo(String value) {
            addCriterion("ind_doc_inicio <=", value, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioLike(String value) {
            addCriterion("ind_doc_inicio like", value, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioNotLike(String value) {
            addCriterion("ind_doc_inicio not like", value, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioIn(List<String> values) {
            addCriterion("ind_doc_inicio in", values, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioNotIn(List<String> values) {
            addCriterion("ind_doc_inicio not in", values, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioBetween(String value1, String value2) {
            addCriterion("ind_doc_inicio between", value1, value2, "indDocInicio");
            return this;
        }

        public Criteria andIndDocInicioNotBetween(String value1, String value2) {
            addCriterion("ind_doc_inicio not between", value1, value2, "indDocInicio");
            return this;
        }

        public Criteria andNumDiasAmpliaIsNull() {
            addCriterion("num_dias_amplia is null");
            return this;
        }

        public Criteria andNumDiasAmpliaIsNotNull() {
            addCriterion("num_dias_amplia is not null");
            return this;
        }

        public Criteria andNumDiasAmpliaEqualTo(Integer value) {
            addCriterion("num_dias_amplia =", value, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaNotEqualTo(Integer value) {
            addCriterion("num_dias_amplia <>", value, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaGreaterThan(Integer value) {
            addCriterion("num_dias_amplia >", value, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_dias_amplia >=", value, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaLessThan(Integer value) {
            addCriterion("num_dias_amplia <", value, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaLessThanOrEqualTo(Integer value) {
            addCriterion("num_dias_amplia <=", value, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaIn(List<Integer> values) {
            addCriterion("num_dias_amplia in", values, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaNotIn(List<Integer> values) {
            addCriterion("num_dias_amplia not in", values, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaBetween(Integer value1, Integer value2) {
            addCriterion("num_dias_amplia between", value1, value2, "numDiasAmplia");
            return this;
        }

        public Criteria andNumDiasAmpliaNotBetween(Integer value1, Integer value2) {
            addCriterion("num_dias_amplia not between", value1, value2, "numDiasAmplia");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }

        public Criteria andCodUsuregisIsNull() {
            addCriterion("cod_usuregis is null");
            return this;
        }

        public Criteria andCodUsuregisIsNotNull() {
            addCriterion("cod_usuregis is not null");
            return this;
        }

        public Criteria andCodUsuregisEqualTo(String value) {
            addCriterion("cod_usuregis =", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotEqualTo(String value) {
            addCriterion("cod_usuregis <>", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThan(String value) {
            addCriterion("cod_usuregis >", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuregis >=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThan(String value) {
            addCriterion("cod_usuregis <", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThanOrEqualTo(String value) {
            addCriterion("cod_usuregis <=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLike(String value) {
            addCriterion("cod_usuregis like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotLike(String value) {
            addCriterion("cod_usuregis not like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisIn(List<String> values) {
            addCriterion("cod_usuregis in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotIn(List<String> values) {
            addCriterion("cod_usuregis not in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisBetween(String value1, String value2) {
            addCriterion("cod_usuregis between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotBetween(String value1, String value2) {
            addCriterion("cod_usuregis not between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andFecRegisIsNull() {
            addCriterion("fec_regis is null");
            return this;
        }

        public Criteria andFecRegisIsNotNull() {
            addCriterion("fec_regis is not null");
            return this;
        }

        public Criteria andFecRegisEqualTo(Date value) {
            addCriterion("fec_regis =", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotEqualTo(Date value) {
            addCriterion("fec_regis <>", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThan(Date value) {
            addCriterion("fec_regis >", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_regis >=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThan(Date value) {
            addCriterion("fec_regis <", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThanOrEqualTo(Date value) {
            addCriterion("fec_regis <=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisIn(List<Date> values) {
            addCriterion("fec_regis in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotIn(List<Date> values) {
            addCriterion("fec_regis not in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisBetween(Date value1, Date value2) {
            addCriterion("fec_regis between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotBetween(Date value1, Date value2) {
            addCriterion("fec_regis not between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }
    }
}