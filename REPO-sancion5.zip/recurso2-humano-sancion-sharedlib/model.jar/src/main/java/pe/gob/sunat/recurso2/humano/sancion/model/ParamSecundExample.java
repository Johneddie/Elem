package pe.gob.sunat.recurso2.humano.sancion.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParamSecundExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ParamSecundExample() {
        oredCriteria = new ArrayList<>();
    }

    protected ParamSecundExample(ParamSecundExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }
	
	public Criteria createCriteria() {
		
		Criteria criteria = createCriteriaInternal();
		
		if (oredCriteria.isEmpty()) {
			oredCriteria.add(criteria);
		}
		
		return criteria;
		
	}
	
	protected Criteria createCriteriaInternal() {
		return new Criteria();
	}
	
    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }
		
		public boolean isValid() {
			
			return !criteriaWithoutValue.isEmpty() || !criteriaWithSingleValue.isEmpty() || !criteriaWithListValue.isEmpty() || !criteriaWithBetweenValue.isEmpty();
			
		}

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodTabIsNull() {
            addCriterion("cod_tab is null");
            return this;
        }

        public Criteria andCodTabIsNotNull() {
            addCriterion("cod_tab is not null");
            return this;
        }

        public Criteria andCodTabEqualTo(String value) {
            addCriterion("cod_tab =", value, "codTab");
            return this;
        }

        public Criteria andCodTabNotEqualTo(String value) {
            addCriterion("cod_tab <>", value, "codTab");
            return this;
        }

        public Criteria andCodTabGreaterThan(String value) {
            addCriterion("cod_tab >", value, "codTab");
            return this;
        }

        public Criteria andCodTabGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tab >=", value, "codTab");
            return this;
        }

        public Criteria andCodTabLessThan(String value) {
            addCriterion("cod_tab <", value, "codTab");
            return this;
        }

        public Criteria andCodTabLessThanOrEqualTo(String value) {
            addCriterion("cod_tab <=", value, "codTab");
            return this;
        }

        public Criteria andCodTabLike(String value) {
            addCriterion("cod_tab like", value, "codTab");
            return this;
        }

        public Criteria andCodTabNotLike(String value) {
            addCriterion("cod_tab not like", value, "codTab");
            return this;
        }

        public Criteria andCodTabIn(List<String> values) {
            addCriterion("cod_tab in", values, "codTab");
            return this;
        }

        public Criteria andCodTabNotIn(List<String> values) {
            addCriterion("cod_tab not in", values, "codTab");
            return this;
        }

        public Criteria andCodTabBetween(String value1, String value2) {
            addCriterion("cod_tab between", value1, value2, "codTab");
            return this;
        }

        public Criteria andCodTabNotBetween(String value1, String value2) {
            addCriterion("cod_tab not between", value1, value2, "codTab");
            return this;
        }

        public Criteria andCodTipDescIsNull() {
            addCriterion("cod_tip_desc is null");
            return this;
        }

        public Criteria andCodTipDescIsNotNull() {
            addCriterion("cod_tip_desc is not null");
            return this;
        }

        public Criteria andCodTipDescEqualTo(String value) {
            addCriterion("cod_tip_desc =", value, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescNotEqualTo(String value) {
            addCriterion("cod_tip_desc <>", value, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescGreaterThan(String value) {
            addCriterion("cod_tip_desc >", value, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tip_desc >=", value, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescLessThan(String value) {
            addCriterion("cod_tip_desc <", value, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescLessThanOrEqualTo(String value) {
            addCriterion("cod_tip_desc <=", value, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescLike(String value) {
            addCriterion("cod_tip_desc like", value, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescNotLike(String value) {
            addCriterion("cod_tip_desc not like", value, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescIn(List<String> values) {
            addCriterion("cod_tip_desc in", values, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescNotIn(List<String> values) {
            addCriterion("cod_tip_desc not in", values, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescBetween(String value1, String value2) {
            addCriterion("cod_tip_desc between", value1, value2, "codTipDesc");
            return this;
        }

        public Criteria andCodTipDescNotBetween(String value1, String value2) {
            addCriterion("cod_tip_desc not between", value1, value2, "codTipDesc");
            return this;
        }

        public Criteria andNumCodigoIsNull() {
            addCriterion("num_codigo is null");
            return this;
        }

        public Criteria andNumCodigoIsNotNull() {
            addCriterion("num_codigo is not null");
            return this;
        }

        public Criteria andNumCodigoEqualTo(String value) {
            addCriterion("num_codigo =", value, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoNotEqualTo(String value) {
            addCriterion("num_codigo <>", value, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoGreaterThan(String value) {
            addCriterion("num_codigo >", value, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoGreaterThanOrEqualTo(String value) {
            addCriterion("num_codigo >=", value, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoLessThan(String value) {
            addCriterion("num_codigo <", value, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoLessThanOrEqualTo(String value) {
            addCriterion("num_codigo <=", value, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoLike(String value) {
            addCriterion("num_codigo like", value, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoNotLike(String value) {
            addCriterion("num_codigo not like", value, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoIn(List<String> values) {
            addCriterion("num_codigo in", values, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoNotIn(List<String> values) {
            addCriterion("num_codigo not in", values, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoBetween(String value1, String value2) {
            addCriterion("num_codigo between", value1, value2, "numCodigo");
            return this;
        }

        public Criteria andNumCodigoNotBetween(String value1, String value2) {
            addCriterion("num_codigo not between", value1, value2, "numCodigo");
            return this;
        }

        public Criteria andDesCortaIsNull() {
            addCriterion("des_corta is null");
            return this;
        }

        public Criteria andDesCortaIsNotNull() {
            addCriterion("des_corta is not null");
            return this;
        }

        public Criteria andDesCortaEqualTo(String value) {
            addCriterion("des_corta =", value, "desCorta");
            return this;
        }

        public Criteria andDesCortaNotEqualTo(String value) {
            addCriterion("des_corta <>", value, "desCorta");
            return this;
        }

        public Criteria andDesCortaGreaterThan(String value) {
            addCriterion("des_corta >", value, "desCorta");
            return this;
        }

        public Criteria andDesCortaGreaterThanOrEqualTo(String value) {
            addCriterion("des_corta >=", value, "desCorta");
            return this;
        }

        public Criteria andDesCortaLessThan(String value) {
            addCriterion("des_corta <", value, "desCorta");
            return this;
        }

        public Criteria andDesCortaLessThanOrEqualTo(String value) {
            addCriterion("des_corta <=", value, "desCorta");
            return this;
        }

        public Criteria andDesCortaLike(String value) {
            addCriterion("des_corta like", value, "desCorta");
            return this;
        }

        public Criteria andDesCortaNotLike(String value) {
            addCriterion("des_corta not like", value, "desCorta");
            return this;
        }

        public Criteria andDesCortaIn(List<String> values) {
            addCriterion("des_corta in", values, "desCorta");
            return this;
        }

        public Criteria andDesCortaNotIn(List<String> values) {
            addCriterion("des_corta not in", values, "desCorta");
            return this;
        }

        public Criteria andDesCortaBetween(String value1, String value2) {
            addCriterion("des_corta between", value1, value2, "desCorta");
            return this;
        }

        public Criteria andDesCortaNotBetween(String value1, String value2) {
            addCriterion("des_corta not between", value1, value2, "desCorta");
            return this;
        }

        public Criteria andDesAbreviaturaIsNull() {
            addCriterion("des_abreviatura is null");
            return this;
        }

        public Criteria andDesAbreviaturaIsNotNull() {
            addCriterion("des_abreviatura is not null");
            return this;
        }

        public Criteria andDesAbreviaturaEqualTo(String value) {
            addCriterion("des_abreviatura =", value, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaNotEqualTo(String value) {
            addCriterion("des_abreviatura <>", value, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaGreaterThan(String value) {
            addCriterion("des_abreviatura >", value, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaGreaterThanOrEqualTo(String value) {
            addCriterion("des_abreviatura >=", value, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaLessThan(String value) {
            addCriterion("des_abreviatura <", value, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaLessThanOrEqualTo(String value) {
            addCriterion("des_abreviatura <=", value, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaLike(String value) {
            addCriterion("des_abreviatura like", value, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaNotLike(String value) {
            addCriterion("des_abreviatura not like", value, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaIn(List<String> values) {
            addCriterion("des_abreviatura in", values, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaNotIn(List<String> values) {
            addCriterion("des_abreviatura not in", values, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaBetween(String value1, String value2) {
            addCriterion("des_abreviatura between", value1, value2, "desAbreviatura");
            return this;
        }

        public Criteria andDesAbreviaturaNotBetween(String value1, String value2) {
            addCriterion("des_abreviatura not between", value1, value2, "desAbreviatura");
            return this;
        }

        public Criteria andValParamIsNull() {
            addCriterion("val_param is null");
            return this;
        }

        public Criteria andValParamIsNotNull() {
            addCriterion("val_param is not null");
            return this;
        }

        public Criteria andValParamEqualTo(BigDecimal value) {
            addCriterion("val_param =", value, "valParam");
            return this;
        }

        public Criteria andValParamNotEqualTo(BigDecimal value) {
            addCriterion("val_param <>", value, "valParam");
            return this;
        }

        public Criteria andValParamGreaterThan(BigDecimal value) {
            addCriterion("val_param >", value, "valParam");
            return this;
        }

        public Criteria andValParamGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("val_param >=", value, "valParam");
            return this;
        }

        public Criteria andValParamLessThan(BigDecimal value) {
            addCriterion("val_param <", value, "valParam");
            return this;
        }

        public Criteria andValParamLessThanOrEqualTo(BigDecimal value) {
            addCriterion("val_param <=", value, "valParam");
            return this;
        }

        public Criteria andValParamIn(List<BigDecimal> values) {
            addCriterion("val_param in", values, "valParam");
            return this;
        }

        public Criteria andValParamNotIn(List<BigDecimal> values) {
            addCriterion("val_param not in", values, "valParam");
            return this;
        }

        public Criteria andValParamBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("val_param between", value1, value2, "valParam");
            return this;
        }

        public Criteria andValParamNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("val_param not between", value1, value2, "valParam");
            return this;
        }

        public Criteria andCodEstadoIsNull() {
            addCriterion("cod_estado is null");
            return this;
        }

        public Criteria andCodEstadoIsNotNull() {
            addCriterion("cod_estado is not null");
            return this;
        }

        public Criteria andCodEstadoEqualTo(String value) {
            addCriterion("cod_estado =", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotEqualTo(String value) {
            addCriterion("cod_estado <>", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThan(String value) {
            addCriterion("cod_estado >", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estado >=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThan(String value) {
            addCriterion("cod_estado <", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThanOrEqualTo(String value) {
            addCriterion("cod_estado <=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLike(String value) {
            addCriterion("cod_estado like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotLike(String value) {
            addCriterion("cod_estado not like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoIn(List<String> values) {
            addCriterion("cod_estado in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotIn(List<String> values) {
            addCriterion("cod_estado not in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoBetween(String value1, String value2) {
            addCriterion("cod_estado between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotBetween(String value1, String value2) {
            addCriterion("cod_estado not between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodUsuregisIsNull() {
            addCriterion("cod_usuregis is null");
            return this;
        }

        public Criteria andCodUsuregisIsNotNull() {
            addCriterion("cod_usuregis is not null");
            return this;
        }

        public Criteria andCodUsuregisEqualTo(String value) {
            addCriterion("cod_usuregis =", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotEqualTo(String value) {
            addCriterion("cod_usuregis <>", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThan(String value) {
            addCriterion("cod_usuregis >", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuregis >=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThan(String value) {
            addCriterion("cod_usuregis <", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThanOrEqualTo(String value) {
            addCriterion("cod_usuregis <=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLike(String value) {
            addCriterion("cod_usuregis like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotLike(String value) {
            addCriterion("cod_usuregis not like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisIn(List<String> values) {
            addCriterion("cod_usuregis in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotIn(List<String> values) {
            addCriterion("cod_usuregis not in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisBetween(String value1, String value2) {
            addCriterion("cod_usuregis between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotBetween(String value1, String value2) {
            addCriterion("cod_usuregis not between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andFecRegisIsNull() {
            addCriterion("fec_regis is null");
            return this;
        }

        public Criteria andFecRegisIsNotNull() {
            addCriterion("fec_regis is not null");
            return this;
        }

        public Criteria andFecRegisEqualTo(Date value) {
            addCriterion("fec_regis =", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotEqualTo(Date value) {
            addCriterion("fec_regis <>", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThan(Date value) {
            addCriterion("fec_regis >", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_regis >=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThan(Date value) {
            addCriterion("fec_regis <", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThanOrEqualTo(Date value) {
            addCriterion("fec_regis <=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisIn(List<Date> values) {
            addCriterion("fec_regis in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotIn(List<Date> values) {
            addCriterion("fec_regis not in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisBetween(Date value1, Date value2) {
            addCriterion("fec_regis between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotBetween(Date value1, Date value2) {
            addCriterion("fec_regis not between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }
    }
}