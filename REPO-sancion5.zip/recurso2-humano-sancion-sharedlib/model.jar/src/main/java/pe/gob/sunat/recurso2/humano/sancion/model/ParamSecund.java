package pe.gob.sunat.recurso2.humano.sancion.model;

import java.math.BigDecimal;
import java.util.Date;

public class ParamSecund extends ParamSecundKey {
    private String desCorta;

    private String desAbreviatura;

    private BigDecimal valParam;

    private String codEstado;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;

    public String getDesCorta() {
        return desCorta;
    }

    public void setDesCorta(String desCorta) {
        this.desCorta = desCorta == null ? null : desCorta.trim();
    }

    public String getDesAbreviatura() {
        return desAbreviatura;
    }

    public void setDesAbreviatura(String desAbreviatura) {
        this.desAbreviatura = desAbreviatura == null ? null : desAbreviatura.trim();
    }

    public BigDecimal getValParam() {
        return valParam;
    }

    public void setValParam(BigDecimal valParam) {
        this.valParam = valParam;
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }
}