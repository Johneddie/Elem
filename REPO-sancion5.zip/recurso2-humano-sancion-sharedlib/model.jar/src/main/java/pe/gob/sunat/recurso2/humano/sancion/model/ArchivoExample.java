package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArchivoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ArchivoExample() {
        oredCriteria = new ArrayList<>();
    }

    protected ArchivoExample(ArchivoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andNumArchivoIsNull() {
            addCriterion("num_archivo is null");
            return this;
        }

        public Criteria andNumArchivoIsNotNull() {
            addCriterion("num_archivo is not null");
            return this;
        }

        public Criteria andNumArchivoEqualTo(Integer value) {
            addCriterion("num_archivo =", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotEqualTo(Integer value) {
            addCriterion("num_archivo <>", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoGreaterThan(Integer value) {
            addCriterion("num_archivo >", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_archivo >=", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoLessThan(Integer value) {
            addCriterion("num_archivo <", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoLessThanOrEqualTo(Integer value) {
            addCriterion("num_archivo <=", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoIn(List<Integer> values) {
            addCriterion("num_archivo in", values, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotIn(List<Integer> values) {
            addCriterion("num_archivo not in", values, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoBetween(Integer value1, Integer value2) {
            addCriterion("num_archivo between", value1, value2, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotBetween(Integer value1, Integer value2) {
            addCriterion("num_archivo not between", value1, value2, "numArchivo");
            return this;
        }

        public Criteria andFecRegistroIsNull() {
            addCriterion("fec_registro is null");
            return this;
        }

        public Criteria andFecRegistroIsNotNull() {
            addCriterion("fec_registro is not null");
            return this;
        }

        public Criteria andFecRegistroEqualTo(Date value) {
            addCriterion("fec_registro =", value, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroNotEqualTo(Date value) {
            addCriterion("fec_registro <>", value, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroGreaterThan(Date value) {
            addCriterion("fec_registro >", value, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_registro >=", value, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroLessThan(Date value) {
            addCriterion("fec_registro <", value, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroLessThanOrEqualTo(Date value) {
            addCriterion("fec_registro <=", value, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroIn(List<Date> values) {
            addCriterion("fec_registro in", values, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroNotIn(List<Date> values) {
            addCriterion("fec_registro not in", values, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroBetween(Date value1, Date value2) {
            addCriterion("fec_registro between", value1, value2, "fecRegistro");
            return this;
        }

        public Criteria andFecRegistroNotBetween(Date value1, Date value2) {
            addCriterion("fec_registro not between", value1, value2, "fecRegistro");
            return this;
        }

        public Criteria andCodEstadoIsNull() {
            addCriterion("cod_estado is null");
            return this;
        }

        public Criteria andCodEstadoIsNotNull() {
            addCriterion("cod_estado is not null");
            return this;
        }

        public Criteria andCodEstadoEqualTo(String value) {
            addCriterion("cod_estado =", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotEqualTo(String value) {
            addCriterion("cod_estado <>", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThan(String value) {
            addCriterion("cod_estado >", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estado >=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThan(String value) {
            addCriterion("cod_estado <", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThanOrEqualTo(String value) {
            addCriterion("cod_estado <=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLike(String value) {
            addCriterion("cod_estado like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotLike(String value) {
            addCriterion("cod_estado not like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoIn(List<String> values) {
            addCriterion("cod_estado in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotIn(List<String> values) {
            addCriterion("cod_estado not in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoBetween(String value1, String value2) {
            addCriterion("cod_estado between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotBetween(String value1, String value2) {
            addCriterion("cod_estado not between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }
    }
}