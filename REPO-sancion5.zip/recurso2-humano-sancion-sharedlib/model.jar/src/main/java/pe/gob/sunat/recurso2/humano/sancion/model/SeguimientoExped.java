package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class SeguimientoExped extends SeguimientoExpedKey {
    private String codTipActor;

    private String codPersOrig;

    private String codUnidOrig;

    private String codPersDest;

    private String codUnidDest;

    private String codAccion;

    private String codEstado;

    private String indUltSeguim;

    private String desObserv;

    private String codFaseDest;

    private String indDel;

    private String codUsuregis;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss",timezone="GMT-5:00")
    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;
    
    
    private String desEstado;
    
    private String desFaseDest;
    
    private String nomPersOrig;
    
    private String nomPersDest;

    public String getCodTipActor() {
        return codTipActor;
    }

    public void setCodTipActor(String codTipActor) {
        this.codTipActor = codTipActor == null ? null : codTipActor.trim();
    }

    public String getCodPersOrig() {
        return codPersOrig;
    }

    public void setCodPersOrig(String codPersOrig) {
        this.codPersOrig = codPersOrig == null ? null : codPersOrig.trim();
    }

    public String getCodUnidOrig() {
        return codUnidOrig;
    }

    public void setCodUnidOrig(String codUnidOrig) {
        this.codUnidOrig = codUnidOrig == null ? null : codUnidOrig.trim();
    }

    public String getCodPersDest() {
        return codPersDest;
    }

    public void setCodPersDest(String codPersDest) {
        this.codPersDest = codPersDest == null ? null : codPersDest.trim();
    }

    public String getCodUnidDest() {
        return codUnidDest;
    }

    public void setCodUnidDest(String codUnidDest) {
        this.codUnidDest = codUnidDest == null ? null : codUnidDest.trim();
    }

    public String getCodAccion() {
        return codAccion;
    }

    public void setCodAccion(String codAccion) {
        this.codAccion = codAccion == null ? null : codAccion.trim();
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public String getIndUltSeguim() {
        return indUltSeguim;
    }

    public void setIndUltSeguim(String indUltSeguim) {
        this.indUltSeguim = indUltSeguim == null ? null : indUltSeguim.trim();
    }

    public String getDesObserv() {
        return desObserv;
    }

    public void setDesObserv(String desObserv) {
        this.desObserv = desObserv == null ? null : desObserv.trim();
    }

    public String getCodFaseDest() {
        return codFaseDest;
    }

    public void setCodFaseDest(String codFaseDest) {
        this.codFaseDest = codFaseDest == null ? null : codFaseDest.trim();
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

	public String getDesEstado() {
		return desEstado;
	}

	public void setDesEstado(String desEstado) {
		this.desEstado = desEstado;
	}

	public String getDesFaseDest() {
		return desFaseDest;
	}

	public void setDesFaseDest(String desFaseDest) {
		this.desFaseDest = desFaseDest;
	}

	public String getNomPersOrig() {
		return nomPersOrig;
	}

	public void setNomPersOrig(String nomPersOrig) {
		this.nomPersOrig = nomPersOrig;
	}

	public String getNomPersDest() {
		return nomPersDest;
	}

	public void setNomPersDest(String nomPersDest) {
		this.nomPersDest = nomPersDest;
	}
    
    
}