package pe.gob.sunat.recurso2.humano.sancion.model;

public class DelegacionKey {
    private String codOpcion;

    private String codPersonalJefe;

    private String cunidadOrgan;

    public String getCodOpcion() {
        return codOpcion;
    }

    public void setCodOpcion(String codOpcion) {
        this.codOpcion = codOpcion == null ? null : codOpcion.trim();
    }

    public String getCodPersonalJefe() {
        return codPersonalJefe;
    }

    public void setCodPersonalJefe(String codPersonalJefe) {
        this.codPersonalJefe = codPersonalJefe == null ? null : codPersonalJefe.trim();
    }

    public String getCunidadOrgan() {
        return cunidadOrgan;
    }

    public void setCunidadOrgan(String cunidadOrgan) {
        this.cunidadOrgan = cunidadOrgan == null ? null : cunidadOrgan.trim();
    }
}