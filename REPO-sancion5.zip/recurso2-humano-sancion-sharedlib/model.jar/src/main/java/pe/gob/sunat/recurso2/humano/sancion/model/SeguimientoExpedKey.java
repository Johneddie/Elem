package pe.gob.sunat.recurso2.humano.sancion.model;

public class SeguimientoExpedKey {
    private Integer numIdExped;

    private Integer numSeguim;

    public Integer getNumIdExped() {
        return numIdExped;
    }

    public void setNumIdExped(Integer numIdExped) {
        this.numIdExped = numIdExped;
    }

    public Integer getNumSeguim() {
        return numSeguim;
    }

    public void setNumSeguim(Integer numSeguim) {
        this.numSeguim = numSeguim;
    }
}