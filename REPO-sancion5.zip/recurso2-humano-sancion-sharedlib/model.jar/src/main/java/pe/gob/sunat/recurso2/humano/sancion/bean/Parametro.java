package pe.gob.sunat.recurso2.humano.sancion.bean;

public class Parametro {
    
    private String codParametro;
    private String codEstado;
    private String codDataParametro;
    private String desParametro;
    private String desParametroAbrev;
    private String desSiglas;
	private String desGlosa;
    
	public String getCodParametro() {
		return codParametro;
	}
	public void setCodParametro(String codParametro) {
		this.codParametro = codParametro;
	}
	public String getCodDataParametro() {
		return codDataParametro;
	}
	public void setCodDataParametro(String codDataParametro) {
		this.codDataParametro = codDataParametro;
	}
	public String getDesParametro() {
		return desParametro;
	}
	public void setDesParametro(String desParametro) {
		this.desParametro = desParametro;
	}
	public String getDesParametroAbrev() {
		return desParametroAbrev;
	}
	public void setDesParametroAbrev(String desParametroAbrev) {
		this.desParametroAbrev = desParametroAbrev;
	}
	public String getDesSiglas() {
		return desSiglas;
	}
	public void setDesSiglas(String desSiglas) {
		this.desSiglas = desSiglas;
	}
	public String getDesGlosa() {
		return desGlosa;
	}
	public void setDesGlosa(String desGlosa) {
		this.desGlosa = desGlosa;
	}	
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	
	
}
