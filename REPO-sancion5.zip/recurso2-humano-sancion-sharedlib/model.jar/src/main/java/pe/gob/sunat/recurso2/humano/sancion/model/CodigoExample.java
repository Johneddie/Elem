package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CodigoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public CodigoExample() {
        oredCriteria = new ArrayList<>();
    }

    protected CodigoExample(CodigoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andT99codTabIsNull() {
            addCriterion("t99cod_tab is null");
            return this;
        }

        public Criteria andT99codTabIsNotNull() {
            addCriterion("t99cod_tab is not null");
            return this;
        }

        public Criteria andT99codTabEqualTo(String value) {
            addCriterion("t99cod_tab =", value, "t99codTab");
            return this;
        }

        public Criteria andT99codTabNotEqualTo(String value) {
            addCriterion("t99cod_tab <>", value, "t99codTab");
            return this;
        }

        public Criteria andT99codTabGreaterThan(String value) {
            addCriterion("t99cod_tab >", value, "t99codTab");
            return this;
        }

        public Criteria andT99codTabGreaterThanOrEqualTo(String value) {
            addCriterion("t99cod_tab >=", value, "t99codTab");
            return this;
        }

        public Criteria andT99codTabLessThan(String value) {
            addCriterion("t99cod_tab <", value, "t99codTab");
            return this;
        }

        public Criteria andT99codTabLessThanOrEqualTo(String value) {
            addCriterion("t99cod_tab <=", value, "t99codTab");
            return this;
        }

        public Criteria andT99codTabLike(String value) {
            addCriterion("t99cod_tab like", value, "t99codTab");
            return this;
        }

        public Criteria andT99codTabNotLike(String value) {
            addCriterion("t99cod_tab not like", value, "t99codTab");
            return this;
        }

        public Criteria andT99codTabIn(List<String> values) {
            addCriterion("t99cod_tab in", values, "t99codTab");
            return this;
        }

        public Criteria andT99codTabNotIn(List<String> values) {
            addCriterion("t99cod_tab not in", values, "t99codTab");
            return this;
        }

        public Criteria andT99codTabBetween(String value1, String value2) {
            addCriterion("t99cod_tab between", value1, value2, "t99codTab");
            return this;
        }

        public Criteria andT99codTabNotBetween(String value1, String value2) {
            addCriterion("t99cod_tab not between", value1, value2, "t99codTab");
            return this;
        }

        public Criteria andT99tipDescIsNull() {
            addCriterion("t99tip_desc is null");
            return this;
        }

        public Criteria andT99tipDescIsNotNull() {
            addCriterion("t99tip_desc is not null");
            return this;
        }

        public Criteria andT99tipDescEqualTo(String value) {
            addCriterion("t99tip_desc =", value, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescNotEqualTo(String value) {
            addCriterion("t99tip_desc <>", value, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescGreaterThan(String value) {
            addCriterion("t99tip_desc >", value, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescGreaterThanOrEqualTo(String value) {
            addCriterion("t99tip_desc >=", value, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescLessThan(String value) {
            addCriterion("t99tip_desc <", value, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescLessThanOrEqualTo(String value) {
            addCriterion("t99tip_desc <=", value, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescLike(String value) {
            addCriterion("t99tip_desc like", value, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescNotLike(String value) {
            addCriterion("t99tip_desc not like", value, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescIn(List<String> values) {
            addCriterion("t99tip_desc in", values, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescNotIn(List<String> values) {
            addCriterion("t99tip_desc not in", values, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescBetween(String value1, String value2) {
            addCriterion("t99tip_desc between", value1, value2, "t99tipDesc");
            return this;
        }

        public Criteria andT99tipDescNotBetween(String value1, String value2) {
            addCriterion("t99tip_desc not between", value1, value2, "t99tipDesc");
            return this;
        }

        public Criteria andT99codigoIsNull() {
            addCriterion("t99codigo is null");
            return this;
        }

        public Criteria andT99codigoIsNotNull() {
            addCriterion("t99codigo is not null");
            return this;
        }

        public Criteria andT99codigoEqualTo(String value) {
            addCriterion("t99codigo =", value, "t99codigo");
            return this;
        }

        public Criteria andT99codigoNotEqualTo(String value) {
            addCriterion("t99codigo <>", value, "t99codigo");
            return this;
        }

        public Criteria andT99codigoGreaterThan(String value) {
            addCriterion("t99codigo >", value, "t99codigo");
            return this;
        }

        public Criteria andT99codigoGreaterThanOrEqualTo(String value) {
            addCriterion("t99codigo >=", value, "t99codigo");
            return this;
        }

        public Criteria andT99codigoLessThan(String value) {
            addCriterion("t99codigo <", value, "t99codigo");
            return this;
        }

        public Criteria andT99codigoLessThanOrEqualTo(String value) {
            addCriterion("t99codigo <=", value, "t99codigo");
            return this;
        }

        public Criteria andT99codigoLike(String value) {
            addCriterion("t99codigo like", value, "t99codigo");
            return this;
        }

        public Criteria andT99codigoNotLike(String value) {
            addCriterion("t99codigo not like", value, "t99codigo");
            return this;
        }

        public Criteria andT99codigoIn(List<String> values) {
            addCriterion("t99codigo in", values, "t99codigo");
            return this;
        }

        public Criteria andT99codigoNotIn(List<String> values) {
            addCriterion("t99codigo not in", values, "t99codigo");
            return this;
        }

        public Criteria andT99codigoBetween(String value1, String value2) {
            addCriterion("t99codigo between", value1, value2, "t99codigo");
            return this;
        }

        public Criteria andT99codigoNotBetween(String value1, String value2) {
            addCriterion("t99codigo not between", value1, value2, "t99codigo");
            return this;
        }

        public Criteria andT99descripIsNull() {
            addCriterion("t99descrip is null");
            return this;
        }

        public Criteria andT99descripIsNotNull() {
            addCriterion("t99descrip is not null");
            return this;
        }

        public Criteria andT99descripEqualTo(String value) {
            addCriterion("t99descrip =", value, "t99descrip");
            return this;
        }

        public Criteria andT99descripNotEqualTo(String value) {
            addCriterion("t99descrip <>", value, "t99descrip");
            return this;
        }

        public Criteria andT99descripGreaterThan(String value) {
            addCriterion("t99descrip >", value, "t99descrip");
            return this;
        }

        public Criteria andT99descripGreaterThanOrEqualTo(String value) {
            addCriterion("t99descrip >=", value, "t99descrip");
            return this;
        }

        public Criteria andT99descripLessThan(String value) {
            addCriterion("t99descrip <", value, "t99descrip");
            return this;
        }

        public Criteria andT99descripLessThanOrEqualTo(String value) {
            addCriterion("t99descrip <=", value, "t99descrip");
            return this;
        }

        public Criteria andT99descripLike(String value) {
            addCriterion("t99descrip like", value, "t99descrip");
            return this;
        }

        public Criteria andT99descripNotLike(String value) {
            addCriterion("t99descrip not like", value, "t99descrip");
            return this;
        }

        public Criteria andT99descripIn(List<String> values) {
            addCriterion("t99descrip in", values, "t99descrip");
            return this;
        }

        public Criteria andT99descripNotIn(List<String> values) {
            addCriterion("t99descrip not in", values, "t99descrip");
            return this;
        }

        public Criteria andT99descripBetween(String value1, String value2) {
            addCriterion("t99descrip between", value1, value2, "t99descrip");
            return this;
        }

        public Criteria andT99descripNotBetween(String value1, String value2) {
            addCriterion("t99descrip not between", value1, value2, "t99descrip");
            return this;
        }

        public Criteria andT99abrevIsNull() {
            addCriterion("t99abrev is null");
            return this;
        }

        public Criteria andT99abrevIsNotNull() {
            addCriterion("t99abrev is not null");
            return this;
        }

        public Criteria andT99abrevEqualTo(String value) {
            addCriterion("t99abrev =", value, "t99abrev");
            return this;
        }

        public Criteria andT99abrevNotEqualTo(String value) {
            addCriterion("t99abrev <>", value, "t99abrev");
            return this;
        }

        public Criteria andT99abrevGreaterThan(String value) {
            addCriterion("t99abrev >", value, "t99abrev");
            return this;
        }

        public Criteria andT99abrevGreaterThanOrEqualTo(String value) {
            addCriterion("t99abrev >=", value, "t99abrev");
            return this;
        }

        public Criteria andT99abrevLessThan(String value) {
            addCriterion("t99abrev <", value, "t99abrev");
            return this;
        }

        public Criteria andT99abrevLessThanOrEqualTo(String value) {
            addCriterion("t99abrev <=", value, "t99abrev");
            return this;
        }

        public Criteria andT99abrevLike(String value) {
            addCriterion("t99abrev like", value, "t99abrev");
            return this;
        }

        public Criteria andT99abrevNotLike(String value) {
            addCriterion("t99abrev not like", value, "t99abrev");
            return this;
        }

        public Criteria andT99abrevIn(List<String> values) {
            addCriterion("t99abrev in", values, "t99abrev");
            return this;
        }

        public Criteria andT99abrevNotIn(List<String> values) {
            addCriterion("t99abrev not in", values, "t99abrev");
            return this;
        }

        public Criteria andT99abrevBetween(String value1, String value2) {
            addCriterion("t99abrev between", value1, value2, "t99abrev");
            return this;
        }

        public Criteria andT99abrevNotBetween(String value1, String value2) {
            addCriterion("t99abrev not between", value1, value2, "t99abrev");
            return this;
        }

        public Criteria andT99siglasIsNull() {
            addCriterion("t99siglas is null");
            return this;
        }

        public Criteria andT99siglasIsNotNull() {
            addCriterion("t99siglas is not null");
            return this;
        }

        public Criteria andT99siglasEqualTo(String value) {
            addCriterion("t99siglas =", value, "t99siglas");
            return this;
        }

        public Criteria andT99siglasNotEqualTo(String value) {
            addCriterion("t99siglas <>", value, "t99siglas");
            return this;
        }

        public Criteria andT99siglasGreaterThan(String value) {
            addCriterion("t99siglas >", value, "t99siglas");
            return this;
        }

        public Criteria andT99siglasGreaterThanOrEqualTo(String value) {
            addCriterion("t99siglas >=", value, "t99siglas");
            return this;
        }

        public Criteria andT99siglasLessThan(String value) {
            addCriterion("t99siglas <", value, "t99siglas");
            return this;
        }

        public Criteria andT99siglasLessThanOrEqualTo(String value) {
            addCriterion("t99siglas <=", value, "t99siglas");
            return this;
        }

        public Criteria andT99siglasLike(String value) {
            addCriterion("t99siglas like", value, "t99siglas");
            return this;
        }

        public Criteria andT99siglasNotLike(String value) {
            addCriterion("t99siglas not like", value, "t99siglas");
            return this;
        }

        public Criteria andT99siglasIn(List<String> values) {
            addCriterion("t99siglas in", values, "t99siglas");
            return this;
        }

        public Criteria andT99siglasNotIn(List<String> values) {
            addCriterion("t99siglas not in", values, "t99siglas");
            return this;
        }

        public Criteria andT99siglasBetween(String value1, String value2) {
            addCriterion("t99siglas between", value1, value2, "t99siglas");
            return this;
        }

        public Criteria andT99siglasNotBetween(String value1, String value2) {
            addCriterion("t99siglas not between", value1, value2, "t99siglas");
            return this;
        }

        public Criteria andT99tipoIsNull() {
            addCriterion("t99tipo is null");
            return this;
        }

        public Criteria andT99tipoIsNotNull() {
            addCriterion("t99tipo is not null");
            return this;
        }

        public Criteria andT99tipoEqualTo(String value) {
            addCriterion("t99tipo =", value, "t99tipo");
            return this;
        }

        public Criteria andT99tipoNotEqualTo(String value) {
            addCriterion("t99tipo <>", value, "t99tipo");
            return this;
        }

        public Criteria andT99tipoGreaterThan(String value) {
            addCriterion("t99tipo >", value, "t99tipo");
            return this;
        }

        public Criteria andT99tipoGreaterThanOrEqualTo(String value) {
            addCriterion("t99tipo >=", value, "t99tipo");
            return this;
        }

        public Criteria andT99tipoLessThan(String value) {
            addCriterion("t99tipo <", value, "t99tipo");
            return this;
        }

        public Criteria andT99tipoLessThanOrEqualTo(String value) {
            addCriterion("t99tipo <=", value, "t99tipo");
            return this;
        }

        public Criteria andT99tipoLike(String value) {
            addCriterion("t99tipo like", value, "t99tipo");
            return this;
        }

        public Criteria andT99tipoNotLike(String value) {
            addCriterion("t99tipo not like", value, "t99tipo");
            return this;
        }

        public Criteria andT99tipoIn(List<String> values) {
            addCriterion("t99tipo in", values, "t99tipo");
            return this;
        }

        public Criteria andT99tipoNotIn(List<String> values) {
            addCriterion("t99tipo not in", values, "t99tipo");
            return this;
        }

        public Criteria andT99tipoBetween(String value1, String value2) {
            addCriterion("t99tipo between", value1, value2, "t99tipo");
            return this;
        }

        public Criteria andT99tipoNotBetween(String value1, String value2) {
            addCriterion("t99tipo not between", value1, value2, "t99tipo");
            return this;
        }

        public Criteria andT99estadoIsNull() {
            addCriterion("t99estado is null");
            return this;
        }

        public Criteria andT99estadoIsNotNull() {
            addCriterion("t99estado is not null");
            return this;
        }

        public Criteria andT99estadoEqualTo(String value) {
            addCriterion("t99estado =", value, "t99estado");
            return this;
        }

        public Criteria andT99estadoNotEqualTo(String value) {
            addCriterion("t99estado <>", value, "t99estado");
            return this;
        }

        public Criteria andT99estadoGreaterThan(String value) {
            addCriterion("t99estado >", value, "t99estado");
            return this;
        }

        public Criteria andT99estadoGreaterThanOrEqualTo(String value) {
            addCriterion("t99estado >=", value, "t99estado");
            return this;
        }

        public Criteria andT99estadoLessThan(String value) {
            addCriterion("t99estado <", value, "t99estado");
            return this;
        }

        public Criteria andT99estadoLessThanOrEqualTo(String value) {
            addCriterion("t99estado <=", value, "t99estado");
            return this;
        }

        public Criteria andT99estadoLike(String value) {
            addCriterion("t99estado like", value, "t99estado");
            return this;
        }

        public Criteria andT99estadoNotLike(String value) {
            addCriterion("t99estado not like", value, "t99estado");
            return this;
        }

        public Criteria andT99estadoIn(List<String> values) {
            addCriterion("t99estado in", values, "t99estado");
            return this;
        }

        public Criteria andT99estadoNotIn(List<String> values) {
            addCriterion("t99estado not in", values, "t99estado");
            return this;
        }

        public Criteria andT99estadoBetween(String value1, String value2) {
            addCriterion("t99estado between", value1, value2, "t99estado");
            return this;
        }

        public Criteria andT99estadoNotBetween(String value1, String value2) {
            addCriterion("t99estado not between", value1, value2, "t99estado");
            return this;
        }

        public Criteria andT99codUserIsNull() {
            addCriterion("t99cod_user is null");
            return this;
        }

        public Criteria andT99codUserIsNotNull() {
            addCriterion("t99cod_user is not null");
            return this;
        }

        public Criteria andT99codUserEqualTo(String value) {
            addCriterion("t99cod_user =", value, "t99codUser");
            return this;
        }

        public Criteria andT99codUserNotEqualTo(String value) {
            addCriterion("t99cod_user <>", value, "t99codUser");
            return this;
        }

        public Criteria andT99codUserGreaterThan(String value) {
            addCriterion("t99cod_user >", value, "t99codUser");
            return this;
        }

        public Criteria andT99codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t99cod_user >=", value, "t99codUser");
            return this;
        }

        public Criteria andT99codUserLessThan(String value) {
            addCriterion("t99cod_user <", value, "t99codUser");
            return this;
        }

        public Criteria andT99codUserLessThanOrEqualTo(String value) {
            addCriterion("t99cod_user <=", value, "t99codUser");
            return this;
        }

        public Criteria andT99codUserLike(String value) {
            addCriterion("t99cod_user like", value, "t99codUser");
            return this;
        }

        public Criteria andT99codUserNotLike(String value) {
            addCriterion("t99cod_user not like", value, "t99codUser");
            return this;
        }

        public Criteria andT99codUserIn(List<String> values) {
            addCriterion("t99cod_user in", values, "t99codUser");
            return this;
        }

        public Criteria andT99codUserNotIn(List<String> values) {
            addCriterion("t99cod_user not in", values, "t99codUser");
            return this;
        }

        public Criteria andT99codUserBetween(String value1, String value2) {
            addCriterion("t99cod_user between", value1, value2, "t99codUser");
            return this;
        }

        public Criteria andT99codUserNotBetween(String value1, String value2) {
            addCriterion("t99cod_user not between", value1, value2, "t99codUser");
            return this;
        }

        public Criteria andT99FactualIsNull() {
            addCriterion("t99_factual is null");
            return this;
        }

        public Criteria andT99FactualIsNotNull() {
            addCriterion("t99_factual is not null");
            return this;
        }

        public Criteria andT99FactualEqualTo(Date value) {
            addCriterion("t99_factual =", value, "t99Factual");
            return this;
        }

        public Criteria andT99FactualNotEqualTo(Date value) {
            addCriterion("t99_factual <>", value, "t99Factual");
            return this;
        }

        public Criteria andT99FactualGreaterThan(Date value) {
            addCriterion("t99_factual >", value, "t99Factual");
            return this;
        }

        public Criteria andT99FactualGreaterThanOrEqualTo(Date value) {
            addCriterion("t99_factual >=", value, "t99Factual");
            return this;
        }

        public Criteria andT99FactualLessThan(Date value) {
            addCriterion("t99_factual <", value, "t99Factual");
            return this;
        }

        public Criteria andT99FactualLessThanOrEqualTo(Date value) {
            addCriterion("t99_factual <=", value, "t99Factual");
            return this;
        }

        public Criteria andT99FactualIn(List<Date> values) {
            addCriterion("t99_factual in", values, "t99Factual");
            return this;
        }

        public Criteria andT99FactualNotIn(List<Date> values) {
            addCriterion("t99_factual not in", values, "t99Factual");
            return this;
        }

        public Criteria andT99FactualBetween(Date value1, Date value2) {
            addCriterion("t99_factual between", value1, value2, "t99Factual");
            return this;
        }

        public Criteria andT99FactualNotBetween(Date value1, Date value2) {
            addCriterion("t99_factual not between", value1, value2, "t99Factual");
            return this;
        }

        public Criteria andT99ModuloIsNull() {
            addCriterion("t99_modulo is null");
            return this;
        }

        public Criteria andT99ModuloIsNotNull() {
            addCriterion("t99_modulo is not null");
            return this;
        }

        public Criteria andT99ModuloEqualTo(String value) {
            addCriterion("t99_modulo =", value, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloNotEqualTo(String value) {
            addCriterion("t99_modulo <>", value, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloGreaterThan(String value) {
            addCriterion("t99_modulo >", value, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloGreaterThanOrEqualTo(String value) {
            addCriterion("t99_modulo >=", value, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloLessThan(String value) {
            addCriterion("t99_modulo <", value, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloLessThanOrEqualTo(String value) {
            addCriterion("t99_modulo <=", value, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloLike(String value) {
            addCriterion("t99_modulo like", value, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloNotLike(String value) {
            addCriterion("t99_modulo not like", value, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloIn(List<String> values) {
            addCriterion("t99_modulo in", values, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloNotIn(List<String> values) {
            addCriterion("t99_modulo not in", values, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloBetween(String value1, String value2) {
            addCriterion("t99_modulo between", value1, value2, "t99Modulo");
            return this;
        }

        public Criteria andT99ModuloNotBetween(String value1, String value2) {
            addCriterion("t99_modulo not between", value1, value2, "t99Modulo");
            return this;
        }

        public Criteria andCodClasif1IsNull() {
            addCriterion("cod_clasif1 is null");
            return this;
        }

        public Criteria andCodClasif1IsNotNull() {
            addCriterion("cod_clasif1 is not null");
            return this;
        }

        public Criteria andCodClasif1EqualTo(String value) {
            addCriterion("cod_clasif1 =", value, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1NotEqualTo(String value) {
            addCriterion("cod_clasif1 <>", value, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1GreaterThan(String value) {
            addCriterion("cod_clasif1 >", value, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_clasif1 >=", value, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1LessThan(String value) {
            addCriterion("cod_clasif1 <", value, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1LessThanOrEqualTo(String value) {
            addCriterion("cod_clasif1 <=", value, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1Like(String value) {
            addCriterion("cod_clasif1 like", value, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1NotLike(String value) {
            addCriterion("cod_clasif1 not like", value, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1In(List<String> values) {
            addCriterion("cod_clasif1 in", values, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1NotIn(List<String> values) {
            addCriterion("cod_clasif1 not in", values, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1Between(String value1, String value2) {
            addCriterion("cod_clasif1 between", value1, value2, "codClasif1");
            return this;
        }

        public Criteria andCodClasif1NotBetween(String value1, String value2) {
            addCriterion("cod_clasif1 not between", value1, value2, "codClasif1");
            return this;
        }

        public Criteria andCodClasif2IsNull() {
            addCriterion("cod_clasif2 is null");
            return this;
        }

        public Criteria andCodClasif2IsNotNull() {
            addCriterion("cod_clasif2 is not null");
            return this;
        }

        public Criteria andCodClasif2EqualTo(String value) {
            addCriterion("cod_clasif2 =", value, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2NotEqualTo(String value) {
            addCriterion("cod_clasif2 <>", value, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2GreaterThan(String value) {
            addCriterion("cod_clasif2 >", value, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_clasif2 >=", value, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2LessThan(String value) {
            addCriterion("cod_clasif2 <", value, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2LessThanOrEqualTo(String value) {
            addCriterion("cod_clasif2 <=", value, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2Like(String value) {
            addCriterion("cod_clasif2 like", value, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2NotLike(String value) {
            addCriterion("cod_clasif2 not like", value, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2In(List<String> values) {
            addCriterion("cod_clasif2 in", values, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2NotIn(List<String> values) {
            addCriterion("cod_clasif2 not in", values, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2Between(String value1, String value2) {
            addCriterion("cod_clasif2 between", value1, value2, "codClasif2");
            return this;
        }

        public Criteria andCodClasif2NotBetween(String value1, String value2) {
            addCriterion("cod_clasif2 not between", value1, value2, "codClasif2");
            return this;
        }
    }
}