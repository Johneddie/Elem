package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.sancion.model.Persona;
import pe.gob.sunat.recurso2.humano.sancion.model.UnidadOrg;
import pe.gob.sunat.recurso2.humano.sancion.model.UnidadOrgExample;

public interface UnidadOrgDAO {
    int countByExample(UnidadOrgExample example);

    int deleteByExample(UnidadOrgExample example);

    int deleteByPrimaryKey(String t12codUorga);

    void insert(UnidadOrg record);

    void insertSelective(UnidadOrg record);

    List<UnidadOrg> selectByExample(UnidadOrgExample example);

    UnidadOrg selectByPrimaryKey(String t12codUorga);

    int updateByExampleSelective(UnidadOrg record, UnidadOrgExample example);

    int updateByExample(UnidadOrg record, UnidadOrgExample example);

    int updateByPrimaryKeySelective(UnidadOrg record);

    int updateByPrimaryKey(UnidadOrg record);
    
    
    
    public String obtenerCodJefeByCodUorga(String codUorga);

	List<UnidadOrg> selectByExampleBasic(UnidadOrgExample example);
}