package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.sancion.model.Delegacion;
import pe.gob.sunat.recurso2.humano.sancion.model.DelegacionExample;
import pe.gob.sunat.recurso2.humano.sancion.model.DelegacionKey;

public interface DelegacionDAO {
    int countByExample(DelegacionExample example);

    int deleteByExample(DelegacionExample example);

    int deleteByPrimaryKey(DelegacionKey key);

    void insert(Delegacion record);

    void insertSelective(Delegacion record);

    List<Delegacion> selectByExample(DelegacionExample example);

    Delegacion selectByPrimaryKey(DelegacionKey key);

    int updateByExampleSelective(Delegacion record, DelegacionExample example);

    int updateByExample(Delegacion record, DelegacionExample example);

    int updateByPrimaryKeySelective(Delegacion record);

    int updateByPrimaryKey(Delegacion record);
    
    public Delegacion obtenerDelegacionPorUnidad(String codUnidad, List<String> lstOpciones);
}