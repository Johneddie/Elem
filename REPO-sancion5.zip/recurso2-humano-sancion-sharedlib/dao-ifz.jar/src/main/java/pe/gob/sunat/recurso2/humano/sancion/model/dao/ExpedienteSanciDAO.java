package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanciExample;

public interface ExpedienteSanciDAO {
    int countByExample(ExpedienteSanciExample example);

    int deleteByExample(ExpedienteSanciExample example);

    int deleteByPrimaryKey(Integer numIdExped);

    void insert(ExpedienteSanci record);

    void insertSelective(ExpedienteSanci record);

    List<ExpedienteSanci> selectByExampleWithBLOBs(ExpedienteSanciExample example);

    List<ExpedienteSanci> selectByExampleWithoutBLOBs(ExpedienteSanciExample example);

    ExpedienteSanci selectByPrimaryKey(Integer numIdExped);

    int updateByExampleSelective(ExpedienteSanci record, ExpedienteSanciExample example);

    int updateByExampleWithBLOBs(ExpedienteSanci record, ExpedienteSanciExample example);

    int updateByExampleWithoutBLOBs(ExpedienteSanci record, ExpedienteSanciExample example);

    int updateByPrimaryKeySelective(ExpedienteSanci record);

    int updateByPrimaryKeyWithBLOBs(ExpedienteSanci record);

    int updateByPrimaryKeyWithoutBLOBs(ExpedienteSanci record);
    
    
    public List<ExpedienteSanci> listarExpedientesIniciados(Map<String, Object> example);
    
    public Integer obtenerMaxCorrelByAnio(Integer numAnio);
}