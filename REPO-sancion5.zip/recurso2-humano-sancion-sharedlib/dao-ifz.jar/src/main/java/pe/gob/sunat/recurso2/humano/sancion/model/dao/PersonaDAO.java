package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.sancion.model.Persona;
import pe.gob.sunat.recurso2.humano.sancion.model.PersonaExample;

public interface PersonaDAO {
    int countByExample(PersonaExample example);

    int deleteByExample(PersonaExample example);

    int deleteByPrimaryKey(String t02codPers);

    void insert(Persona record);

    void insertSelective(Persona record);

    List<Persona> selectByExample(PersonaExample example);

    Persona selectByPrimaryKey(String t02codPers);

    int updateByExampleSelective(Persona record, PersonaExample example);

    int updateByExample(Persona record, PersonaExample example);

    int updateByPrimaryKeySelective(Persona record);

    int updateByPrimaryKey(Persona record);
    
    
    public String obtenerCodUorgaByCodPers(String codPersonal);

	List<Persona> listarPersonasByUnidad(String codUnidadOrg);

	List<Persona> selectByExampleBasic(PersonaExample example);
	
	public List<Persona> listarPersonal(Map<String, String> params);
}