package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanciExample;

public interface DocumentoSanciDAO {
    int countByExample(DocumentoSanciExample example);

    int deleteByExample(DocumentoSanciExample example);

    int deleteByPrimaryKey(Integer numIdDocum);

    void insert(DocumentoSanci record);

    void insertSelective(DocumentoSanci record);

    List<DocumentoSanci> selectByExample(DocumentoSanciExample example);

    DocumentoSanci selectByPrimaryKey(Integer numIdDocum);

    int updateByExampleSelective(DocumentoSanci record, DocumentoSanciExample example);

    int updateByExample(DocumentoSanci record, DocumentoSanciExample example);

    int updateByPrimaryKeySelective(DocumentoSanci record);

    int updateByPrimaryKey(DocumentoSanci record);
}