package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.sancion.model.Correo;
import pe.gob.sunat.recurso2.humano.sancion.model.CorreoExample;

public interface CorreoDAO {
    int countByExample(CorreoExample example);

    int deleteByExample(CorreoExample example);

    int deleteByPrimaryKey(String codPers);

    void insert(Correo record);

    void insertSelective(Correo record);

    List<Correo> selectByExample(CorreoExample example);

    Correo selectByPrimaryKey(String codPers);

    int updateByExampleSelective(Correo record, CorreoExample example);

    int updateByExample(Correo record, CorreoExample example);

    int updateByPrimaryKeySelective(Correo record);

    int updateByPrimaryKey(Correo record);
}