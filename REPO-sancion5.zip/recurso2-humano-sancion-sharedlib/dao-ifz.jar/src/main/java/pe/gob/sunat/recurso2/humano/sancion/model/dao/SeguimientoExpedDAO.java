package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExped;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExpedExample;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExpedKey;

public interface SeguimientoExpedDAO {
    int countByExample(SeguimientoExpedExample example);

    int deleteByExample(SeguimientoExpedExample example);

    int deleteByPrimaryKey(SeguimientoExpedKey key);

    void insert(SeguimientoExped record);

    void insertSelective(SeguimientoExped record);

    List<SeguimientoExped> selectByExample(SeguimientoExpedExample example);

    SeguimientoExped selectByPrimaryKey(SeguimientoExpedKey key);

    int updateByExampleSelective(SeguimientoExped record, SeguimientoExpedExample example);

    int updateByExample(SeguimientoExped record, SeguimientoExpedExample example);

    int updateByPrimaryKeySelective(SeguimientoExped record);

    int updateByPrimaryKey(SeguimientoExped record);
}