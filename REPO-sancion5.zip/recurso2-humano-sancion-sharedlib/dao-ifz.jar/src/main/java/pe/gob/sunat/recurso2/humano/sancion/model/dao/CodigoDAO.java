package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.model.Codigo;
import pe.gob.sunat.recurso2.humano.sancion.model.CodigoExample;

public interface CodigoDAO {
    int countByExample(CodigoExample example);

    int deleteByExample(CodigoExample example);

    void insert(Codigo record);

    void insertSelective(Codigo record);

    List<Codigo> selectByExample(CodigoExample example);

    int updateByExampleSelective(Codigo record, CodigoExample example);

    int updateByExample(Codigo record, CodigoExample example);
    
    public Parametro obtenerParametro(String codTabla, String codParametro);
    
    public String obtenerDescripcion(String codTabla, String codParametro);
    
    public Parametro obtenerParametroBySigla(String codTabla, String codSigla);
    
    public List<Parametro> listarParametros(String codTabla);
    
    public List<Parametro> selectByExampleBasic(CodigoExample example);
    
}