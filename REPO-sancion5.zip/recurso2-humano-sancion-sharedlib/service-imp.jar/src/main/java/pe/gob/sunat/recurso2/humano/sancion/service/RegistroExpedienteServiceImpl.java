package pe.gob.sunat.recurso2.humano.sancion.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.Persona;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExped;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExpedExample;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.recurso2.humano.sancion.model.Archivo;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDet;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDetExample;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanciExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ExpedienteSanciDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.PersonaDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.SeguimientoExpedDAO;
import pe.gob.sunat.recurso2.humano.sancion.util.Constantes;
import pe.gob.sunat.recurso2.humano.sancion.util.FechasUtil;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ArchivoDetDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DocumentoSanciDAO;

@Service("registroExpedienteService")
public class RegistroExpedienteServiceImpl implements RegistroExpedienteService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ExpedienteSanciDAO expedienteSanciDAO;

	@Autowired
	SeguimientoExpedDAO seguimientoExpedDAO;

	@Autowired
	DocumentoSanciDAO documentoSanciDAO;
	
	@Autowired
	SeguimientoExpedService seguimientoExpedService;
	
	@Autowired
	ArchivoService archivoService;
	
	@Autowired
	CodigoDAO codigoDAO;
	
	@Autowired
	ArchivoDetDAO archivoDetDAO;
	
	@Autowired
	PersonaDAO personaDAO;
	
	@Override
	public List<ExpedienteSanci> listarExpedientesIniciados(Map<String, String> params) {
		if(log.isDebugEnabled()) log.debug("method listarExpedientesIniciados");
		
		List<ExpedienteSanci> lstDocumentos = new ArrayList<>();
		
		try{
			String codPersonal = params.get("codPersonal");
			String codTipExped = !StringUtils.isBlank(params.get("codTipExpedBusq"))?params.get("codTipExpedBusq"):null;
			Date fecRegisIni = FechasUtil.getDateFromStringDDMMYY(params.get("fecRegisIniBusq")) ;
			Date fecRegisFin = FechasUtil.getDateFromStringDDMMYY(params.get("fecRegisFinBusq")) ;
			if(fecRegisFin!=null)
				fecRegisFin = FechasUtil.obtenerFinalDia(fecRegisFin);
			
			//consulta
			Map<String, Object> hmParams = new HashMap<>();
			hmParams.put("codPersonal", codPersonal);
			hmParams.put("codTipExped", codTipExped);
			hmParams.put("fecRegisIni", fecRegisIni);
			hmParams.put("fecRegisFin", fecRegisFin);
			lstDocumentos = expedienteSanciDAO.listarExpedientesIniciados(hmParams);
			
			for(ExpedienteSanci e:lstDocumentos){
				calcularDiasFases(e);
			}
		}catch(ServiceException e){
			log.error("Ha ocurrido un error en listarDeclaracionesIniciadas: " + e.getMessage(), e);
		}
		return lstDocumentos;
	}
	
	private void calcularDiasFases(ExpedienteSanci e){
		Calendar cHoy = Calendar.getInstance();
		Integer diasPrec = null;
		Integer diasInst = null;
		Integer diasSanc = null;
		SeguimientoExpedExample sde = new SeguimientoExpedExample();
		SeguimientoExpedExample.Criteria sdc = sde.createCriteria();
		sdc.andNumIdExpedEqualTo(e.getNumIdExped());
		sdc.andIndDelEqualTo(Constantes.INDI_NOELIMIN);
		List<SeguimientoExped> lstSeguim = seguimientoExpedDAO.selectByExample(sde);
		SeguimientoExped sPrec = lstSeguim.get(0);
		SeguimientoExped sIntr = null;
		SeguimientoExped sSanc = null;
		for(SeguimientoExped s:lstSeguim){
			boolean esUltimo = Constantes.INDI_GENE_ACTI.equals(s.getIndUltSeguim());
			if(Constantes.CODI_FASE_EXPE_PREC.equals(s.getCodFaseDest())){
				if(esUltimo){
					long diff = cHoy.getTimeInMillis() - sPrec.getFecRegis().getTime();
					diasPrec = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				}
			}else if(Constantes.CODI_FASE_EXPE_INST.equals(s.getCodFaseDest())){
				long diff = (esUltimo?cHoy.getTimeInMillis():s.getFecRegis().getTime()) - sPrec.getFecRegis().getTime();
				diasPrec = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				sIntr = s;
			}else if(Constantes.CODI_FASE_EXPE_SANC.equals(s.getCodFaseDest())){
				long diff = (esUltimo?cHoy.getTimeInMillis():s.getFecRegis().getTime()) - sIntr.getFecRegis().getTime();
				diasInst = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				sSanc = s;
			}else if(Constantes.CODI_FASE_EXPE_PREC.equals(s.getCodFaseDest()) && Constantes.CODI_ESTA_SOLI_CONC.equals(e.getCodEstado())){
				long diff = (esUltimo?cHoy.getTimeInMillis():s.getFecRegis().getTime()) - sSanc.getFecRegis().getTime();
				diasSanc = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			}
		}
		e.setNumDiasPrec(diasPrec);
		e.setNumDiasInst(diasInst);
		e.setNumDiasSanc(diasSanc);
		e.setNumDiasTotal(diasPrec + (diasInst==null?0:diasInst) + (diasSanc==null?0:diasSanc));
	}
	
	
	@Override
	public Map<String, Object> registrarExpediente(ExpedienteSanci expediente, String usuario, String codTicket) throws ServiceException {
		log.debug("method registrarDeclaracion");
		Calendar calToday = Calendar.getInstance();
		Map<String, Object> mapRpta = new HashMap<>();

		try{
			DataSourceContextHolder.setKeyDataSource("g");
			
			//datos
			Persona persOrig = personaDAO.selectByPrimaryKey(usuario);
			String codUnidOrig =  StringUtils.isBlank(persOrig.getT02codUorgl()) ? persOrig.getT02codUorg() : persOrig.getT02codUorgl();
			
			Persona persDest = personaDAO.selectByPrimaryKey(expediente.getCodPersEspec());
			String codUnidDest =  StringUtils.isBlank(persDest.getT02codUorgl()) ? persDest.getT02codUorg() : persDest.getT02codUorgl();
			
			if(expediente.getNumIdExped() == null){ //nuevo
				//solicitud
				expediente.setFecRegis(calToday.getTime());
				expediente.setCodUsuregis(usuario);
				expediente.setIndDel(Constantes.INDI_NOELIMIN);
				expediente.setCodFaseAct(Constantes.CODI_FASE_EXPE_PREC);
				expediente.setCodEstado(Constantes.CODI_ESTA_SOLI_INIC);
				expediente.setNumAnio(calToday.get(Calendar.YEAR));
				expediente.setNumCorrel(expedienteSanciDAO.obtenerMaxCorrelByAnio(calToday.get(Calendar.YEAR))+1);
				expedienteSanciDAO.insertSelective(expediente);
				
				//detalle
				List<DocumentoSanci> documentos = expediente.getDocumentos();
				if(documentos != null){
					for(DocumentoSanci documento:documentos){
						registrarDocumento(documento, expediente.getNumIdExped(), usuario, calToday.getTime(), codTicket);
					}
				}
				
				//seguimiento
				SeguimientoExped seguim = new SeguimientoExped();
				seguim.setNumIdExped(expediente.getNumIdExped());
				seguim.setCodPersOrig(usuario);
				seguim.setCodPersDest(expediente.getCodPersEspec());
				seguim.setCodEstado(Constantes.CODI_ESTA_SOLI_INIC);
				seguim.setCodAccion(Constantes.CODI_ACCI_DECL_REGI);
				seguim.setCodTipActor(Constantes.CODI_TIPO_ACTO_SECR);
				seguim.setCodFaseDest(Constantes.CODI_FASE_EXPE_PREC);
				seguim.setCodUnidOrig(codUnidOrig);
				seguim.setCodUnidDest(codUnidDest);
				seguimientoExpedService.registrarSeguimiento(seguim, usuario);
				
			}else{ //modificaci�n
				
				//expediente
				ExpedienteSanci expedienteBD = expedienteSanciDAO.selectByPrimaryKey(expediente.getNumIdExped());
				expediente.setFecModif(calToday.getTime());
				expediente.setCodUsumodif(usuario);
				expedienteSanciDAO.updateByPrimaryKeySelective(expediente);
				
				//documentos
				List<DocumentoSanci> lstDocumentos = expediente.getDocumentos();
				DocumentoSanciExample hse = new DocumentoSanciExample();
				DocumentoSanciExample.Criteria hsc = hse.createCriteria();
				hsc.andNumIdExpedEqualTo(expediente.getNumIdExped());
				hsc.andIndDelEqualTo(Constantes.INDI_NOELIMIN);
				List<DocumentoSanci> lstDocumentosBD = documentoSanciDAO.selectByExample(hse);
				//baja
				for(DocumentoSanci documentoBD:lstDocumentosBD){
					if(!existeDocumentoLista(documentoBD, lstDocumentos)){
						documentoBD.setIndDel(Constantes.INDI_ELIMINAD);
						documentoBD.setCodUsumodif(usuario);
						documentoBD.setFecModif(calToday.getTime());
						documentoSanciDAO.updateByPrimaryKeySelective(documentoBD);
					}
				}
				//altas
				for(DocumentoSanci documento:lstDocumentos){
					if(!existeDocumentoLista(documento, lstDocumentosBD)){
						registrarDocumento(documento, expediente.getNumIdExped(), usuario, calToday.getTime(), codTicket);
					}
				}
				
				//seguimiento
				if(!expedienteBD.getCodPersEspec().equals(expediente.getCodPersEspec())){
					SeguimientoExped seguim = new SeguimientoExped();
					seguim.setNumIdExped(expediente.getNumIdExped());
					seguim.setCodPersOrig(usuario);
					seguim.setCodPersDest(expediente.getCodPersEspec());
					seguim.setCodEstado(Constantes.CODI_ESTA_SOLI_INIC);
					seguim.setCodAccion(Constantes.CODI_ACCI_DECL_REGI);
					seguim.setCodTipActor(Constantes.CODI_TIPO_ACTO_SECR);
					seguim.setCodFaseDest(Constantes.CODI_FASE_EXPE_PREC);
					seguim.setCodUnidOrig(codUnidOrig);
					seguim.setCodUnidDest(codUnidDest);
					seguimientoExpedService.registrarSeguimiento(seguim, usuario);
				}
			}

			mapRpta.put("indError", false);
			mapRpta.put("numIdExped", expediente.getNumIdExped());
				
		}catch(Exception e){
			log.error("Ha ocurrido un error en registrarDeclaracion:" + e.getMessage(), e);
			throw new ServiceException(e,e);
		}
		
		return mapRpta;
	}
	
	private boolean existeDocumentoLista(DocumentoSanci documento, List<DocumentoSanci> lista){
		boolean existe = false;
		for(DocumentoSanci d:lista){
			if(d.getCodTipDocum().equals(documento.getCodTipDocum()) && d.getNumDocum().equals(documento.getNumDocum())){
				existe = true;
				break;
			}
		}
		return existe;
	}
	
	private void registrarDocumento(DocumentoSanci documento, Integer numIdExped, String usuario, Date fecha, String codTicket)  throws ServiceException, IOException {
		documento.setNumIdExped(numIdExped);
		documento.setIndDocInicio(Constantes.INDI_GENE_ACTI);
		documento.setFecRegis(fecha);
		documento.setCodUsuregis(usuario);
		documento.setIndDocInicio(Constantes.INDI_GENE_ACTI);
		documento.setIndDel(Constantes.INDI_NOELIMIN);
		documentoSanciDAO.insertSelective(documento);
		
		//archivos
		List<ArchivoDet> archivos = documento.getArchivos();
		Archivo archivoDocum = archivoService.registrarDocumento(usuario, archivos, codTicket, documento.getNumIdDocum());
		
		DocumentoSanci solicitudArc = new DocumentoSanci();
		solicitudArc.setNumIdDocum(documento.getNumIdDocum());
		solicitudArc.setNumArchDocum(archivoDocum.getNumArchivo());
		solicitudArc.setCodUsumodif(usuario);
		solicitudArc.setFecModif(fecha);
		documentoSanciDAO.updateByPrimaryKeySelective(solicitudArc);
	}
	
	
	@Override
	public ExpedienteSanci obtenerExpediente(Integer numIdExped){
		if(log.isDebugEnabled()) log.debug("method obtenerExpediente");
		
		//solicitud
		ExpedienteSanci solicitud = expedienteSanciDAO.selectByPrimaryKey(numIdExped);
		
		if(solicitud !=  null){
			//detalle
			DocumentoSanciExample hse = new DocumentoSanciExample();
			DocumentoSanciExample.Criteria hsc = hse.createCriteria();
			hsc.andNumIdExpedEqualTo(numIdExped);
			hsc.andIndDelEqualTo(Constantes.INDI_NOELIMIN);
			List<DocumentoSanci> lstDocumentos = documentoSanciDAO.selectByExample(hse);
			
			for(DocumentoSanci d:lstDocumentos){
				d.setDesTipDocum(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_TDOC_EXPE, d.getCodTipDocum()));
				
				ArchivoDetExample ade = new ArchivoDetExample();
				ArchivoDetExample.Criteria adc = ade.createCriteria();
				adc.andNumArchivoEqualTo(d.getNumArchDocum());
				adc.andIndDelEqualTo(Constantes.INDI_NOELIMIN);
				d.setArchivos(archivoDetDAO.selectByExampleWithoutBLOBs(ade));
			}
				
			solicitud.setDocumentos(lstDocumentos);
		}
		
		return solicitud;
	}

}
