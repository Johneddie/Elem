package pe.gob.sunat.recurso2.humano.sancion.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.Archivo;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDet;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDetKey;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ArchivoDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ArchivoDetDAO;
import pe.gob.sunat.recurso2.humano.sancion.util.Constantes;

@Service("archivoService")
public class ArchivoServiceImpl implements ArchivoService{

	public final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private ArchivoDAO archivoDAO;
	
	@Autowired
	private ArchivoDetDAO archivoDetDAO;
	
    @Autowired
    SequenceDAO sequenceDAO;
	
	@Override
	public Archivo registrarDocumento(String usuario, List<ArchivoDet> archivos, String codTicket, Integer numIdSolic) throws IOException{
		if (log.isDebugEnabled())log.debug("Inicio - registrarDocumento");
		
		//archivo
		for(ArchivoDet a:archivos){
			InputStream is = (InputStream) new FileInputStream(Constantes.DIRE_TEMP + codTicket + a.getNomArchivo());
			byte[] binArchivo = IOUtils.toByteArray(is);
			is.close();
			a.setArcAdjunto(binArchivo);
		}
		
		return registrarArchivoBinario(usuario, archivos, numIdSolic);
	}
	
	public Archivo registrarArchivoBinario(String usuario, List<ArchivoDet> archivos, Integer numIdSolic){
		Calendar caltoday = Calendar.getInstance();
		
		//secuencia
		Long secuencia = sequenceDAO.getNextSequence(Constantes.NOMB_SEQU_ARCH);
		
		//cabecera
		Archivo archivo = new Archivo();
		archivo.setNumArchivo(secuencia.intValue());
		archivo.setFecRegistro(caltoday.getTime());
		archivo.setCodEstado("A");
		archivo.setCodUsucrea(usuario);
		archivo.setFecCreacion(caltoday.getTime());
		archivo.setIndDel(Constantes.INDI_NOELIMIN);
		archivoDAO.insertSelective(archivo);
		
		for(int i=0; i<archivos.size(); i++){
			ArchivoDet a = archivos.get(i);
			//detalle
			ArchivoDet detalle = new ArchivoDet();
			detalle.setNumArchivo(secuencia.intValue());
			detalle.setNumArcdet(i+1);
			detalle.setNumSeqdoc(numIdSolic);
			detalle.setIndDel(Constantes.INDI_NOELIMIN);
			detalle.setFecCarga(caltoday.getTime());
			detalle.setCodTiparc("PDF");
			detalle.setNomArchivo(a.getNomArchivo());
			detalle.setDesArchivo(a.getDesArchivo());
			detalle.setCodUsucrea(usuario);
			detalle.setFecCreacion(caltoday.getTime());
			archivoDetDAO.insertSelective(detalle);
			
			//binario
			ArchivoDet detalleFile = new ArchivoDet();
			detalleFile.setNumArchivo(secuencia.intValue());
			detalleFile.setNumArcdet(i+1);
			detalleFile.setArcAdjunto(a.getArcAdjunto());
			detalleFile.setCodUsumodif(usuario);
			detalleFile.setFecModif(caltoday.getTime());
			archivoDetDAO.updateByPrimaryKeySelective(detalleFile);
		}
		
		return archivo;
	}
	
	public ArchivoDet obtenerDocumento(Integer numArchivo, Integer numArcdet) {
		log.debug("Inicio - descargarDocumento");

		ArchivoDetKey adk = new ArchivoDetKey();
		adk.setNumArchivo(numArchivo);
		adk.setNumArcdet(numArcdet);
		return archivoDetDAO.selectByPrimaryKey(adk);
	}
	

}
