package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.model.Delegacion;
import pe.gob.sunat.recurso2.humano.sancion.model.Documento;
import pe.gob.sunat.recurso2.humano.sancion.model.Persona;
import pe.gob.sunat.recurso2.humano.sancion.model.UnidadOrg;
import pe.gob.sunat.recurso2.humano.sancion.model.UnidadOrgExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DelegacionDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DocumentoDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.PersonaDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.T01paramDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.UnidadOrgDAO;
import static pe.gob.sunat.recurso2.humano.sancion.util.Constantes.*;

@Service("personalService")
public class PersonalServiceImpl implements PersonalService {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	UnidadOrgDAO unidadOrgDAO;
	
	@Autowired
	private DelegacionDAO delegacionDAO;
	
	@Autowired
	PersonaDAO personaDAO;
	
	@Autowired
	CodigoDAO codigoDAO;
	
	@Autowired
	DocumentoDAO documentoDAO;
	
	@Autowired
	T01paramDAO t01paramDAO;
	
	@Override
	public List<Persona> listarPersonal(Map<String, String> params){
		if(log.isDebugEnabled()) 
			log.debug("method listarPersonalAnalista");
		boolean isValido = false;
		List<Persona> lstPersonal = new ArrayList<>();
		String apPate = params.get("apPatePersona");
		String apMate = params.get("apMatePersona");
		String nombres = params.get("nombresPersona");
		String codPers = params.get("codPersPersona");
		String numDocum = params.get("numDocumPersona");
		
		//validaciones
		if(esVacio(apPate) && esVacio(apMate) && esVacio(nombres) && esVacio(codPers) && esVacio(numDocum))
			return lstPersonal;
		
		if(!esVacio(apPate) && apPate.trim().length() >= NUME_CARA_MINI_BUSQ 
				||!esVacio(apMate) && apMate.trim().length() >= NUME_CARA_MINI_BUSQ
				|| !esVacio(nombres) && nombres.trim().length() >= NUME_CARA_MINI_BUSQ
				|| !esVacio(codPers) && codPers.trim().length() >= NUME_CARA_MINI_BUSQ
				|| !esVacio(numDocum) && numDocum.trim().length() >= NUME_CARA_MINI_BUSQ){
				isValido = true;
		}
		
		//b�squeda
		if(isValido){
			Map<String, String> mapPersona = new HashMap<>();
			if(!esVacio(apPate)) 
				mapPersona.put("apPate",apPate + '%');
			if(!esVacio(apMate)) 
				mapPersona.put("apMate",apMate + '%');
			if(!esVacio(nombres)) 
				mapPersona.put("nombres",nombres + '%');
			if(!esVacio(codPers)) 
				mapPersona.put("codPers",codPers + '%');
			if(!esVacio(numDocum)) 
				mapPersona.put("numDocum", numDocum);
			if(!esVacio(codPers)) 
				mapPersona.put("codPers",codPers + '%');
			
			lstPersonal = personaDAO.listarPersonal(mapPersona);
		}
		
		return lstPersonal;
	}
	
	@Override
	public List<UnidadOrg> listarUnidadOrg(Map<String, String> params){
		if(log.isDebugEnabled()) 
			log.debug("method listarUnidadOrg");
		boolean isValido = false;
		List<UnidadOrg> lstUnidad = new ArrayList<>();
		String codUorga = params.get("codUorgaUnidad");
		String desUorga = params.get("desUorgaUnidad");
		String indEstad = params.get("indEstadUnidad");
		
		//validaciones
		if(esVacio(codUorga) && esVacio(desUorga) && esVacio(indEstad))
			return lstUnidad;
		
		if(!esVacio(codUorga) && codUorga.trim().length() >= NUME_CARA_MINI_BUSQ 
				|| !esVacio(desUorga) && desUorga.trim().length() >= NUME_CARA_MINI_BUSQ
				|| !esVacio(indEstad)){
				isValido = true;
		}
			
		//b�squeda
		if(isValido){
			UnidadOrgExample param = new UnidadOrgExample() ;
			UnidadOrgExample.Criteria criterio = param.createCriteria();
			if(!esVacio(codUorga)) 
				criterio.andT12codUorgaLike(codUorga + '%');
			if(!esVacio(desUorga)) 
				criterio.andT12desUorgaLike('%' + desUorga + '%');
			if(!esVacio(indEstad)) 
				criterio.andT12indEstadEqualTo(indEstad);
			lstUnidad = unidadOrgDAO.selectByExampleBasic(param);
		}
		return lstUnidad;
	}
	
	
	public Map<String, String> obtenerJefeDelegado(String codPersonal, String codUorga){
		if(log.isDebugEnabled()) log.debug("method obtenerJefeDelegado");
		UnidadOrg unidadEmp = unidadOrgDAO.selectByPrimaryKey(codUorga);
		String codPersJefe = esVacio(unidadEmp.getT12codEncar()) ? unidadEmp.getT12codJefat() : unidadEmp.getT12codEncar();
		String codUnidJefe = codUorga;
		Map<String, String> mapJefe = new HashMap<>();
		
		List<String> lstOpcDelega = Arrays.asList(new String[]{CODI_DELE_SANC});
		Delegacion delegacion = delegacionDAO.obtenerDelegacionPorUnidad(codUorga, lstOpcDelega);
		
		if(delegacion != null){ //delegacion
			String codDelegado = delegacion.getCodPersonalDeleg();
			if(!codPersonal.equals(codPersJefe) && !codPersonal.equals(codDelegado)){//no es jefe ni delegado
				codPersJefe = codDelegado;
			}else{
				Delegacion delegacionSup = delegacionDAO.obtenerDelegacionPorUnidad(unidadEmp.getT12codRepor(), lstOpcDelega);
				if(delegacionSup != null)
					codPersJefe = delegacionSup.getCodPersonalDeleg();
				else{
					UnidadOrg unidadSup = unidadOrgDAO.selectByPrimaryKey(unidadEmp.getT12codRepor());
					codPersJefe = esVacio(unidadSup.getT12codEncar()) ? unidadSup.getT12codJefat() : unidadSup.getT12codEncar();
				}
				codUnidJefe = unidadEmp.getT12codRepor();
			}
		}else{ //no delegacion
			if(codPersonal.equals(codPersJefe)){//jefe
				Delegacion delegacionSup = delegacionDAO.obtenerDelegacionPorUnidad(unidadEmp.getT12codRepor(), lstOpcDelega);
				if(delegacionSup != null){
					codPersJefe = delegacionSup.getCodPersonalDeleg();
				}else{
					UnidadOrg unidadSup = unidadOrgDAO.selectByPrimaryKey(unidadEmp.getT12codRepor());
					codPersJefe = esVacio(unidadSup.getT12codEncar()) ? unidadSup.getT12codJefat() : unidadSup.getT12codEncar();
				}
				codUnidJefe = unidadEmp.getT12codRepor();
			}
		}
		
		mapJefe.put("codPersJefe", codPersJefe);
		mapJefe.put("codUnidJefe", codUnidJefe);
		
		return mapJefe;
	}
	
	@Override
	public String obtenerJefeDelegado(String codUorga){
		String codJefeDelegado;
		List<String> lstOpcDelega = Arrays.asList(new String[]{CODI_DELE_SANC});
		Delegacion delegacion = delegacionDAO.obtenerDelegacionPorUnidad(codUorga, lstOpcDelega);
		if(delegacion != null){
			codJefeDelegado = delegacion.getCodPersonalDeleg();
		}else{
			codJefeDelegado = unidadOrgDAO.obtenerCodJefeByCodUorga(codUorga);
		}
		return codJefeDelegado;
	}
	
	private boolean esVacio(String texto){
		return (texto == null || "".equals(texto.trim()));
	}
	
	@Override
	public Persona obtenerDatosPersona(String codPersonal){
		Persona persona = personaDAO.selectByPrimaryKey(codPersonal);
		
		//obtener documento
		Documento documento = documentoDAO.obtenerDocumento(codPersonal);
		if(documento != null){
			Parametro paramDocumento = codigoDAO.obtenerParametroBySigla(CODI_TABL_EQUI_TIPO_DOCU, documento.getT07codDcto());
			persona.setCodTipDocum(paramDocumento.getCodParametro());
			persona.setNumDocum(documento.getT07nroDcto());
		}
		
		//direccion
		Parametro paramUbigeo = t01paramDAO.selectByPrimaryKey(PARA_TABL_UBIG_SIRH, persona.getT02codUbip());
		persona.setDesUbigeo(paramUbigeo.getDesParametro());
		return persona;
	}
	
	@Override
	public List<Persona> listarAnalistasSancion(){
		String codUorga = codigoDAO.obtenerDescripcion(CODI_TABL_PARA_GENE, CODI_GENE_DIRE_DGCD);
		return personaDAO.listarPersonasByUnidad(codUorga);
	}
	
	@Override
	public UnidadOrg obtenerUnidadOrg(String codUnidadOrg){
		UnidadOrg unidad = null; 
		UnidadOrgExample uoe = new UnidadOrgExample();
		UnidadOrgExample.Criteria uoc = uoe.createCriteria();
		uoc.andT12codUorgaEqualTo(codUnidadOrg);
		uoc.andT12indEstadEqualTo(INDI_GENE_ACTI);
		List<UnidadOrg> lstUnidades = unidadOrgDAO.selectByExampleBasic(uoe);
		if(!lstUnidades.isEmpty()){
			unidad = lstUnidades.get(0);
		}
		return unidad;
	}

}
