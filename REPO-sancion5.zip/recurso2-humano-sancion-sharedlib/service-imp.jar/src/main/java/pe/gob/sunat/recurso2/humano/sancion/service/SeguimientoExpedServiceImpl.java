package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.sancion.model.Persona;
//import pe.gob.sunat.recurso2.humano.docencia.model.Persona;
//import pe.gob.sunat.recurso2.humano.docencia.model.SeguimientoExped;
//import pe.gob.sunat.recurso2.humano.docencia.model.SeguimientoExpedExample;
//import pe.gob.sunat.recurso2.humano.docencia.model.dao.CodigoDAO;
//import pe.gob.sunat.recurso2.humano.docencia.model.dao.PersonaDAO;
//import pe.gob.sunat.recurso2.humano.docencia.model.dao.SeguimientoExpedDAO;
//import pe.gob.sunat.recurso2.humano.docencia.util.Constantes;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExped;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExpedExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.PersonaDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.SeguimientoExpedDAO;
import pe.gob.sunat.recurso2.humano.sancion.util.Constantes;

@Service("seguimientoExpedService")
public class SeguimientoExpedServiceImpl implements SeguimientoExpedService {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	SeguimientoExpedDAO seguimientoExpedDAO;
	
	@Autowired
	CodigoDAO codigoDAO;
	
	@Autowired
	PersonaDAO personaDAO;

	@Override
	public SeguimientoExped registrarSeguimiento(SeguimientoExped seguim, String usuario) {
		log.debug("method registrarSeguimiento");
		Calendar calToday = Calendar.getInstance();
		SeguimientoExped seguimAnterior = null;
		
		//total
		SeguimientoExpedExample sde = new SeguimientoExpedExample();
		SeguimientoExpedExample.Criteria sdc = sde.createCriteria();
		sdc.andNumIdExpedEqualTo(seguim.getNumIdExped());
		sdc.andIndDelEqualTo(Constantes.INDI_NOELIMIN);
		sdc.andIndUltSeguimEqualTo(Constantes.INDI_GENE_ACTI);
		List<SeguimientoExped> lstSeguim = seguimientoExpedDAO.selectByExample(sde);
		if(!lstSeguim.isEmpty()){
			seguimAnterior = lstSeguim.get(0);
		}
		
		if(seguimAnterior!=null){
			//nuevo seguimiento
			seguim.setNumSeguim(seguimAnterior.getNumSeguim()+1);
			seguim.setIndUltSeguim(Constantes.INDI_GENE_ACTI);
			seguim.setIndDel(Constantes.INDI_NOELIMIN);
			seguim.setCodUsuregis(usuario);
			seguim.setFecRegis(calToday.getTime());
			seguimientoExpedDAO.insertSelective(seguim);
			
			//anterior
			SeguimientoExped seguimAntes = new SeguimientoExped();
			seguimAntes.setIndUltSeguim(Constantes.INDI_GENE_INAC);
			seguimAntes.setNumIdExped(seguim.getNumIdExped());
			seguimAntes.setNumSeguim(seguimAnterior.getNumSeguim());
			seguimAntes.setCodUsumodif(usuario);
			seguimAntes.setFecModif(calToday.getTime());
			seguimientoExpedDAO.updateByPrimaryKeySelective(seguimAntes);
			
		}else{
			//nueva declaracion
			seguim.setNumSeguim(1);
			seguim.setIndUltSeguim(Constantes.INDI_GENE_ACTI);
			seguim.setIndDel(Constantes.INDI_NOELIMIN);
			seguim.setCodUsuregis(usuario);
			seguim.setFecRegis(calToday.getTime());
			seguimientoExpedDAO.insertSelective(seguim);
		}
		return seguim;
	}
	
	@Override
	public List<SeguimientoExped> listarSeguimientos(Map<String, String> params) {
		if(log.isDebugEnabled()) log.debug("method listarSeguimientos");
		
		SeguimientoExpedExample se = new SeguimientoExpedExample();
		SeguimientoExpedExample.Criteria sc = se.createCriteria();
		sc.andNumIdExpedEqualTo(Integer.parseInt(params.get("numIdExped")));
		se.setOrderByClause("num_seguim desc");
		List<SeguimientoExped> lstDeclaraciones = seguimientoExpedDAO.selectByExample(se);
		
		for(SeguimientoExped s:lstDeclaraciones){
			s.setDesEstado(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_ESTA_EXPE, s.getCodEstado()));
			s.setDesFaseDest(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_FASE_EXPE, s.getCodFaseDest()));
			Persona porig = personaDAO.selectByPrimaryKey(s.getCodPersOrig());
			s.setNomPersOrig(porig.getT02apPate() + " " + porig.getT02apMate() + ", " + porig.getT02nombres());
			
			Persona pdest = personaDAO.selectByPrimaryKey(s.getCodPersDest());
			s.setNomPersDest(pdest.getT02apPate() + " " + pdest.getT02apMate() + ", " + pdest.getT02nombres());
		}
		
		return lstDeclaraciones;
	}
	
	
	/*
	@Override
	public SeguimientoExped obtenerSeguimientoEnvio(Integer numIdSolic) {
		SeguimientoExped seguimEnvio = null;
		SeguimientoExpedExample sde = new SeguimientoExpedExample();
		SeguimientoExpedExample.Criteria sdc = sde.createCriteria();
		sdc.andNumIdSolicEqualTo(numIdSolic);
		sdc.andIndDelEqualTo(Constantes.INDI_NOELIMIN);
		sdc.andCodAccionEqualTo(Constantes.CODI_ACCI_DECL_REGI);
		sde.setOrderByClause("num_seguim desc");
		List<SeguimientoExped> lstSeguim = seguimDeclaraDAO.selectByExample(sde);
		if(!lstSeguim.isEmpty()){
			seguimEnvio = lstSeguim.get(0);
		}
		return seguimEnvio;
	}
	
	@Override
	public List<SeguimientoExped> listarSeguimientos(Map<String, String> params) {
		if(log.isDebugEnabled()) log.debug("method listarSeguimientos");
		
		SeguimientoExpedExample se = new SeguimientoExpedExample();
		SeguimientoExpedExample.Criteria sc = se.createCriteria();
		sc.andNumIdSolicEqualTo(Integer.parseInt(params.get("numIdSolic")));
		se.setOrderByClause("num_seguim desc");
		List<SeguimientoExped> lstDeclaraciones = seguimDeclaraDAO.selectByExample(se);
		
		for(SeguimientoExped s:lstDeclaraciones){
			s.setDesEstado(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_ESTA_SOLI, s.getCodEstado()));
			s.setDesAccion(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_ACCI_SOLI, s.getCodAccion()));
			Persona porig = personaDAO.selectByPrimaryKey(s.getCodPersOrig());
			s.setNomPersOrig(porig.getT02apPate() + " " + porig.getT02apMate() + ", " + porig.getT02nombres());
			
			Persona pdest = personaDAO.selectByPrimaryKey(s.getCodPersDest());
			s.setNomPersDest(pdest.getT02apPate() + " " + pdest.getT02apMate() + ", " + pdest.getT02nombres());
		}
		
		return lstDeclaraciones;
	}
	*/

}
