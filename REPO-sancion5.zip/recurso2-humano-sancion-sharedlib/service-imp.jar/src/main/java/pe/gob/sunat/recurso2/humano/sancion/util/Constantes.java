package pe.gob.sunat.recurso2.humano.sancion.util;


public class Constantes {
	
	private Constantes(){
	}
	
	public static final String INDI_ELIMINAD = "1";
	public static final String INDI_NOELIMIN = "0";
	
	public static final String INDI_GENE_ACTI = "1";
	public static final String INDI_GENE_INAC = "0";
	
	public static final String TIPO_CODI_CABE = "C";
	public static final String TIPO_CODI_DESC = "D";
	
	public static final String DIRE_TEMP = "/data0/recurso2/humano/sancion/upload/";
	
	public static final String CODI_ACCI_DECL_REGI = "01";
	public static final String CODI_ACCI_DECL_APRO = "02";
	public static final String CODI_ACCI_DECL_RECH = "03";
	
	public static final String CODI_ESTA_SOLI_INIC = "01";
	public static final String CODI_ESTA_SOLI_SEGU = "02";
	public static final String CODI_ESTA_SOLI_CONC = "03";
	
	//codigos
	public static final String CODI_TABL_TIPO_SANC = "691";
	public static final String CODI_TABL_TIPO_EXPE = "693";
	public static final String CODI_TABL_FASE_EXPE = "696";
	public static final String CODI_TABL_ACCI_EXPE = "697";
	public static final String CODI_TABL_ESTA_EXPE = "698";
	public static final String CODI_TABL_FUEN_PROC = "694";
	public static final String CODI_TABL_TDOC_EXPE = "692";
	public static final String CODI_TABL_TDOC_TRAB = "594";
	public static final String CODI_TABL_PARA_GENE = "699";
	public static final String CODI_TABL_EQUI_TIPO_DOCU = "594";
	public static final String PARA_TABL_UBIG_SIRH = "700";
	
	public static final String CODI_DELE_SANC = "B";
	public static final String CODI_GENE_DIRE_DGCD = "01";
	
	public static final int NUME_CARA_MINI_BUSQ = 3;
	
	//c�digo tipo actor
	public static final String CODI_TIPO_ACTO_SECR = "01";
	public static final String CODI_TIPO_ACTO_ESPE = "02";
	public static final String CODI_TIPO_ACTO_INST = "03";
	public static final String CODI_TIPO_ACTO_SANC = "04";
	
	
	public static final String CODI_FASE_EXPE_PREC = "01";
	public static final String CODI_FASE_EXPE_INST = "02";
	public static final String CODI_FASE_EXPE_SANC = "03";
	
	public static final String NOMB_SEQU_ARCH = "SET8152";
	
	public static final String MENS_ERRO_PERM_DESC = "Usted no cuenta con los permisos suficientes para ingresar a esta opci�n.";
	public static final String MENS_ERRO_PERM_SOLU = "Por favor consulte con su analista.";
	
}
