package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.model.CodigoExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ParamSecundDAO;
import pe.gob.sunat.recurso2.humano.sancion.util.Constantes;


@Service("catalogoService")
public class CatalogoServiceImpl implements CatalogoService{

	public final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private CodigoDAO codigoDAO;
	
	@Autowired
	ParamSecundDAO paramSecundDAO;
	
	@Override
	public List<Parametro> listarParametros(String codTabla){
		return codigoDAO.listarParametros(codTabla);
	}
	
	@Override
	public String obtenerDescripParam(String codTabla, String codParametro){
		return codigoDAO.obtenerDescripcion(codTabla, codParametro);
		
	}
	
	@Override
	public String obtenerDescripParamSecund(String codTabla, String codParametro){
		return paramSecundDAO.obtenerDescripcion(codTabla, codParametro);
		
	}
	
	@Override
	public List<Parametro> listarTiposDocumento(String codGruTipDocum) {
		CodigoExample param = new CodigoExample() ;
		CodigoExample.Criteria criterio = param.createCriteria();
		criterio.andT99codTabEqualTo(Constantes.CODI_TABL_TDOC_EXPE);
		criterio.andT99estadoEqualTo("1");
		criterio.andT99tipDescEqualTo("D");
		criterio.andT99tipoEqualTo(codGruTipDocum);
		return codigoDAO.selectByExampleBasic(param);
	}
	
}
