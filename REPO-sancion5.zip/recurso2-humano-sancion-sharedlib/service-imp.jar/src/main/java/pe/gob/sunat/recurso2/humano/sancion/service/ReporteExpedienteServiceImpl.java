package pe.gob.sunat.recurso2.humano.sancion.service;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;
import pe.gob.sunat.recurso2.humano.sancion.util.FechasUtil;

@Service("reporteExpedienteService")
public class ReporteExpedienteServiceImpl implements ReporteExpedienteService {

	protected final Log log = LogFactory.getLog(getClass());
	
	// CAS
	@Override
	public Map<String, Object> exportarExpedientesIniciados(List<ExpedienteSanci> expedientes){
		if(log.isDebugEnabled()) 
			log.debug("method exportarExcelPuestosCAS");
		String strToday = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String sFileName =  "EXP_" + strToday + ".xls";
		Map<String, Object> hmReporte = new HashMap<>();
		
		String url = null;
		String[] arrTitles = {
			"N�mero", 
			"Fec. Registro", 
			"Tipo de Expediente", 
			"Nombres del Denunciado", 
			"Nro. de Documento",
			"Nro. de Informe",
			"Fase",
			"D�as Prec.", 
			"D�as Inst.",
			"D�as Sanc.",
			"D�as Total",
			"Estado"
		};
		try{		 
			Workbook wb = new HSSFWorkbook();
			Sheet sheet = wb.createSheet("Informaci�n");
			Row row;
			Cell c;		
			
	        CellStyle style = wb.createCellStyle();
	        Font font = wb.createFont();
	        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
	        style.setFont(font);
	        style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	        
			// Creamos la cabecera
	        row = sheet.createRow(0);
	        for(int i=0; i<arrTitles.length; i++){
	        	c = row.createCell(i);
	        	c.setCellValue(arrTitles[i]);
	        	c.setCellStyle(style);
	        }
	        
	        // informaci�n       
	        int cntItems = 1;
			for(ExpedienteSanci e:expedientes){
				row = sheet.createRow(cntItems++);
				
				int cel = 0;
				//N�mero
				c = row.createCell(cel++); 
				c.setCellValue("EXP" + e.getNumAnio() + String.format("%05d", e.getNumIdExped()));
				//Fec. Registro
				c = row.createCell(cel++); 
				c.setCellValue(FechasUtil.getStringAAAAMMDDHH(e.getFecRegis()));
				//Tipo de Expediente
				c = row.createCell(cel++); 
				c.setCellValue(e.getDesTipExped());
				//Nombres del Denunciado
				c = row.createCell(cel++); 
				c.setCellValue(e.getCodPersDenun() + " - " + e.getNomPersDenun());
				//Nro. de Documento
				c = row.createCell(cel++); 
				c.setCellValue(e.getNumDocum());
				//Nro. de Informe
				c = row.createCell(cel++); 
				c.setCellValue(e.getNumInform());
				//Fase
				c = row.createCell(cel++); 
				c.setCellValue(e.getDesFaseAct());
				//D�as Prec.
				c = row.createCell(cel++); 
				c.setCellValue(e.getNumDiasPrec());
				//D�as Inst.
				c = row.createCell(cel++); 
				if(e.getNumDiasInst()!=null)
					c.setCellValue(e.getNumDiasInst());
				//D�as Sanc.
				c = row.createCell(cel++); 
				if(e.getNumDiasSanc()!=null)
					c.setCellValue(e.getNumDiasSanc());
				//D�as Total
				c = row.createCell(cel++); 
				c.setCellValue(e.getNumDiasTotal());
				//Estado
				c = row.createCell(cel++); 
				c.setCellValue(e.getDesEstado());
			}
			
		    // ajusta el ancho de las columnas en funci�n de su contenido
	        final short numeroColumnas = sheet.getRow(0).getLastCellNum();
	        for (int i = 0; i < numeroColumnas; i++) 
	        	sheet.autoSizeColumn(i);
	        
			//Write the Excel file
			url = "/data0/tempo/" + sFileName;
			FileOutputStream fileOut = new FileOutputStream(url);	
			wb.write(fileOut);
			fileOut.close();
			
			hmReporte.put("nomFile", sFileName);
			hmReporte.put("url", url);
			hmReporte.put("workbook", wb);
		}
		catch (Exception e) {
		 	log.error("Ha ocurrido un error en exportarExcelPuestosCAS: " + e.getMessage(), e);
		}		
		return hmReporte;
	}

}
