package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanciExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DocumentoSanciDAO;

@SuppressWarnings("deprecation")
public class SqlMapDocumentoSanciDAO extends SqlMapDAOBase implements DocumentoSanciDAO {

    public SqlMapDocumentoSanciDAO() {
        super();
    }

    public int countByExample(DocumentoSanciExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t12015documsanci.countByExample", example);
    }

    public int deleteByExample(DocumentoSanciExample example) {
    	return getSqlMapClientTemplate().delete("t12015documsanci.deleteByExample", example);
    }

    public int deleteByPrimaryKey(Integer numIdDocum) {
        DocumentoSanci key = new DocumentoSanci();
        key.setNumIdDocum(numIdDocum);
        return getSqlMapClientTemplate().delete("t12015documsanci.deleteByPrimaryKey", key);
    }

    public void insert(DocumentoSanci record) {
        getSqlMapClientTemplate().insert("t12015documsanci.insert", record);
    }

    public void insertSelective(DocumentoSanci record) {
        getSqlMapClientTemplate().insert("t12015documsanci.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<DocumentoSanci> selectByExample(DocumentoSanciExample example) {
    	return getSqlMapClientTemplate().queryForList("t12015documsanci.selectByExample", example);
    }

    public DocumentoSanci selectByPrimaryKey(Integer numIdDocum) {
        DocumentoSanci key = new DocumentoSanci();
        key.setNumIdDocum(numIdDocum);
        return (DocumentoSanci) getSqlMapClientTemplate().queryForObject("t12015documsanci.selectByPrimaryKey", key);
    }

    public int updateByExampleSelective(DocumentoSanci record, DocumentoSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12015documsanci.updateByExampleSelective", parms);
    }

    public int updateByExample(DocumentoSanci record, DocumentoSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12015documsanci.updateByExample", parms);
    }

    public int updateByPrimaryKeySelective(DocumentoSanci record) {
    	return getSqlMapClientTemplate().update("t12015documsanci.updateByPrimaryKeySelective", record);
    }

    public int updateByPrimaryKey(DocumentoSanci record) {
    	return getSqlMapClientTemplate().update("t12015documsanci.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends DocumentoSanciExample {
        private Object record;

        public UpdateByExampleParms(Object record, DocumentoSanciExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
}