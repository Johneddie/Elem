package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;
import java.util.Map;


import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanciExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ExpedienteSanciDAO;

@SuppressWarnings("deprecation")
public class SqlMapExpedienteSanciDAO extends SqlMapDAOBase implements ExpedienteSanciDAO {

    public SqlMapExpedienteSanciDAO() {
        super();
    }

    public int countByExample(ExpedienteSanciExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t12014expedisanci.countByExample", example);
    }

    public int deleteByExample(ExpedienteSanciExample example) {
    	return getSqlMapClientTemplate().delete("t12014expedisanci.deleteByExample", example);
    }

    public int deleteByPrimaryKey(Integer numIdExped) {
        ExpedienteSanci key = new ExpedienteSanci();
        key.setNumIdExped(numIdExped);
        return getSqlMapClientTemplate().delete("t12014expedisanci.deleteByPrimaryKey", key);
    }

    public void insert(ExpedienteSanci record) {
        getSqlMapClientTemplate().insert("t12014expedisanci.insert", record);
    }

    public void insertSelective(ExpedienteSanci record) {
        getSqlMapClientTemplate().insert("t12014expedisanci.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<ExpedienteSanci> selectByExampleWithBLOBs(ExpedienteSanciExample example) {
    	return getSqlMapClientTemplate().queryForList("t12014expedisanci.selectByExampleWithBLOBs", example);
    }

    @SuppressWarnings("unchecked")
    public List<ExpedienteSanci> selectByExampleWithoutBLOBs(ExpedienteSanciExample example) {
    	return getSqlMapClientTemplate().queryForList("t12014expedisanci.selectByExample", example);
    }

    public ExpedienteSanci selectByPrimaryKey(Integer numIdExped) {
        ExpedienteSanci key = new ExpedienteSanci();
        key.setNumIdExped(numIdExped);
        return (ExpedienteSanci) getSqlMapClientTemplate().queryForObject("t12014expedisanci.selectByPrimaryKey", key);
    }

    public int updateByExampleSelective(ExpedienteSanci record, ExpedienteSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12014expedisanci.updateByExampleSelective", parms);
    }

    public int updateByExampleWithBLOBs(ExpedienteSanci record, ExpedienteSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12014expedisanci.updateByExampleWithBLOBs", parms);
    }

    public int updateByExampleWithoutBLOBs(ExpedienteSanci record, ExpedienteSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12014expedisanci.updateByExample", parms);
    }

    public int updateByPrimaryKeySelective(ExpedienteSanci record) {
    	return getSqlMapClientTemplate().update("t12014expedisanci.updateByPrimaryKeySelective", record);
    }

    public int updateByPrimaryKeyWithBLOBs(ExpedienteSanci record) {
    	return getSqlMapClientTemplate().update("t12014expedisanci.updateByPrimaryKeyWithBLOBs", record);
    }

    public int updateByPrimaryKeyWithoutBLOBs(ExpedienteSanci record) {
    	return getSqlMapClientTemplate().update("t12014expedisanci.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends ExpedienteSanciExample {
        private Object record;

        public UpdateByExampleParms(Object record, ExpedienteSanciExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
    
    @SuppressWarnings("unchecked")
    public List<ExpedienteSanci> listarExpedientesIniciados(Map<String, Object> example) {
    	return getSqlMapClientTemplate().queryForList("t12014expedisanci.listarExpedientesIniciados", example);
    }
    
    public Integer obtenerMaxCorrelByAnio(Integer numAnio) {
    	return (Integer)getSqlMapClientTemplate().queryForObject("t12014expedisanci.obtenerMaxCorrelByAnio", numAnio);
    }
}