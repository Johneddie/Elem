package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExped;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExpedExample;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExpedKey;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.SeguimientoExpedDAO;

@SuppressWarnings("deprecation")
public class SqlMapSeguimientoExpedDAO extends SqlMapDAOBase implements SeguimientoExpedDAO {

    public SqlMapSeguimientoExpedDAO() {
        super();
    }

    public int countByExample(SeguimientoExpedExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t12016seguimexped.countByExample", example);
    }

    public int deleteByExample(SeguimientoExpedExample example) {
    	return getSqlMapClientTemplate().delete("t12016seguimexped.deleteByExample", example);
    }

    public int deleteByPrimaryKey(SeguimientoExpedKey key) {
    	return getSqlMapClientTemplate().delete("t12016seguimexped.deleteByPrimaryKey", key);
    }

    public void insert(SeguimientoExped record) {
        getSqlMapClientTemplate().insert("t12016seguimexped.insert", record);
    }

    public void insertSelective(SeguimientoExped record) {
        getSqlMapClientTemplate().insert("t12016seguimexped.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<SeguimientoExped> selectByExample(SeguimientoExpedExample example) {
    	return getSqlMapClientTemplate().queryForList("t12016seguimexped.selectByExample", example);
    }

    public SeguimientoExped selectByPrimaryKey(SeguimientoExpedKey key) {
    	return (SeguimientoExped) getSqlMapClientTemplate().queryForObject("t12016seguimexped.selectByPrimaryKey", key);
    }

    public int updateByExampleSelective(SeguimientoExped record, SeguimientoExpedExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12016seguimexped.updateByExampleSelective", parms);
    }

    public int updateByExample(SeguimientoExped record, SeguimientoExpedExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12016seguimexped.updateByExample", parms);
    }

    public int updateByPrimaryKeySelective(SeguimientoExped record) {
    	return getSqlMapClientTemplate().update("t12016seguimexped.updateByPrimaryKeySelective", record);
    }

    public int updateByPrimaryKey(SeguimientoExped record) {
    	return getSqlMapClientTemplate().update("t12016seguimexped.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends SeguimientoExpedExample {
        private Object record;

        public UpdateByExampleParms(Object record, SeguimientoExpedExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
}