package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.Documento;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DocumentoDAO;

@SuppressWarnings("deprecation")
public class SqlMapDocumentoDAO extends SqlMapDAOBase implements DocumentoDAO {

    public SqlMapDocumentoDAO() {
        super();
    }
    
    @Override
    public int countByExample(DocumentoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t07pdcto.countByExample", example);
    }
    
    @Override
    public int deleteByExample(DocumentoExample example) {
    	return getSqlMapClientTemplate().delete("t07pdcto.deleteByExample", example);
    }
    
    @Override
    public void insert(Documento record) {
        getSqlMapClientTemplate().insert("t07pdcto.insert", record);
    }

    @Override
    public void insertSelective(Documento record) {
        getSqlMapClientTemplate().insert("t07pdcto.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Documento> selectByExample(DocumentoExample example) {
    	return getSqlMapClientTemplate().queryForList("t07pdcto.selectByExample", example);
    }

    @Override
    public int updateByExampleSelective(Documento record, DocumentoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t07pdcto.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(Documento record, DocumentoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t07pdcto.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends DocumentoExample {
        private Object record;

        public UpdateByExampleParms(Object record, DocumentoExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
    
    //personalizado
    
    @Override
    public Documento obtenerDocumento(String codPersonal) {
    	return (Documento)getSqlMapClientTemplate().queryForObject("t07pdcto.obtenerDocumento", codPersonal);
    }
}