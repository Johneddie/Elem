package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.Persona;
import pe.gob.sunat.recurso2.humano.sancion.model.PersonaExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.PersonaDAO;

@SuppressWarnings("deprecation")
public class SqlMapPersonaDAO extends SqlMapDAOBase implements PersonaDAO {

    public SqlMapPersonaDAO() {
        super();
    }

    @Override
    public int countByExample(PersonaExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t02perdp.countByExample", example);
    }

    @Override
    public int deleteByExample(PersonaExample example) {
    	return getSqlMapClientTemplate().delete("t02perdp.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(String t02codPers) {
        Persona key = new Persona();
        key.setT02codPers(t02codPers);
        return getSqlMapClientTemplate().delete("t02perdp.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(Persona record) {
        getSqlMapClientTemplate().insert("t02perdp.insert", record);
    }

    @Override
    public void insertSelective(Persona record) {
        getSqlMapClientTemplate().insert("t02perdp.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Persona> selectByExample(PersonaExample example) {
    	return getSqlMapClientTemplate().queryForList("t02perdp.selectByExample", example);
    }

    @Override
    public Persona selectByPrimaryKey(String t02codPers) {
        Persona key = new Persona();
        key.setT02codPers(t02codPers);
        return (Persona) getSqlMapClientTemplate().queryForObject("t02perdp.selectByPrimaryKey", key);
    }

    @Override
    public int updateByExampleSelective(Persona record, PersonaExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t02perdp.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(Persona record, PersonaExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t02perdp.updateByExample", parms);
    }

    @Override
    public int updateByPrimaryKeySelective(Persona record) {
    	return getSqlMapClientTemplate().update("t02perdp.updateByPrimaryKeySelective", record);
    }

    @Override
    public int updateByPrimaryKey(Persona record) {
    	return getSqlMapClientTemplate().update("t02perdp.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends PersonaExample {
        private Object record;

        public UpdateByExampleParms(Object record, PersonaExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
    
    public String obtenerCodUorgaByCodPers(String codPersonal){
        Persona key = new Persona();
        key.setT02codPers(codPersonal);
        Persona persona = (Persona) getSqlMapClientTemplate().queryForObject("t02perdp.selectByPrimaryKey", key);
    	return  StringUtils.isBlank(persona.getT02codUorgl()) ? persona.getT02codUorg() : persona.getT02codUorgl();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Persona> listarPersonasByUnidad(String codUnidadOrg) {
    	return getSqlMapClientTemplate().queryForList("t02perdp.listarPersonasByUnidad", codUnidadOrg);
    }
    
    
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Persona> selectByExampleBasic(PersonaExample example) {
    	return getSqlMapClientTemplate().queryForList("t02perdp.selectByExampleBasic", example);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Persona> listarPersonal(Map<String, String> params) {
    	return getSqlMapClientTemplate().queryForList("t02perdp.listarPersonal", params);
    }
}