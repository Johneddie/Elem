package pe.gob.sunat.recurso2.humano.sancion.service;

import java.io.IOException;
import java.util.List;

import pe.gob.sunat.recurso2.humano.sancion.model.Archivo;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDet;


public interface ArchivoService {

	Archivo registrarDocumento(String usuario, List<ArchivoDet> archivos, String codTicket, Integer numIdSolic) throws IOException;

	public ArchivoDet obtenerDocumento(Integer numArchivo, Integer numArcdet);
	
}
