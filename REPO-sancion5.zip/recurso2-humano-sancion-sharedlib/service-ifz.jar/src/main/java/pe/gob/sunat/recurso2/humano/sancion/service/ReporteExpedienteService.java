package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;

public interface ReporteExpedienteService {

	Map<String, Object> exportarExpedientesIniciados(List<ExpedienteSanci> expedientes);


}
