package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.sancion.model.Persona;
import pe.gob.sunat.recurso2.humano.sancion.model.UnidadOrg;

public interface PersonalService {

	public Map<String, String> obtenerJefeDelegado(String codPersonal, String codUorga);
	
	public Persona obtenerDatosPersona(String codPersonal);
	
	public String obtenerJefeDelegado(String codUorga);

	List<Persona> listarAnalistasSancion();

	List<UnidadOrg> listarUnidadOrg(Map<String, String> params);
	
	UnidadOrg obtenerUnidadOrg(String codUnidadOrg);

	List<Persona> listarPersonal(Map<String, String> params);
}
