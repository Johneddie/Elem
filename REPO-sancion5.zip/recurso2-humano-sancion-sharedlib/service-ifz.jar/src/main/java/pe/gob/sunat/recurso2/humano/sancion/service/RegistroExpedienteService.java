package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;

public interface RegistroExpedienteService {

	List<ExpedienteSanci> listarExpedientesIniciados(Map<String, String> params);

	Map<String, Object> registrarExpediente(ExpedienteSanci solicitud, String usuario, String codTicket) throws ServiceException;

	ExpedienteSanci obtenerExpediente(Integer numIdExped);

}
