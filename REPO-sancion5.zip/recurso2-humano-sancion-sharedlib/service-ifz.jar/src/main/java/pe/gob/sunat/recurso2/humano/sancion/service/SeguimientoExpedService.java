package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExped;

public interface SeguimientoExpedService {

	SeguimientoExped registrarSeguimiento(SeguimientoExped seguim, String usuario);

	List<SeguimientoExped> listarSeguimientos(Map<String, String> params);
}
