package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanciExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DocumentoSanciDAO;

public class SqlMapDocumentoSanciDAO extends SqlMapClientDaoSupport implements DocumentoSanciDAO {

    public SqlMapDocumentoSanciDAO() {
        super();
    }

    public int countByExample(DocumentoSanciExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("txxxx4documsanci.countByExample", example);
        return count;
    }

    public int deleteByExample(DocumentoSanciExample example) {
        int rows = getSqlMapClientTemplate().delete("txxxx4documsanci.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer numIdDocum) {
        DocumentoSanci key = new DocumentoSanci();
        key.setNumIdDocum(numIdDocum);
        int rows = getSqlMapClientTemplate().delete("txxxx4documsanci.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(DocumentoSanci record) {
        getSqlMapClientTemplate().insert("txxxx4documsanci.insert", record);
    }

    public void insertSelective(DocumentoSanci record) {
        getSqlMapClientTemplate().insert("txxxx4documsanci.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<DocumentoSanci> selectByExample(DocumentoSanciExample example) {
        List<DocumentoSanci> list = getSqlMapClientTemplate().queryForList("txxxx4documsanci.selectByExample", example);
        return list;
    }

    public DocumentoSanci selectByPrimaryKey(Integer numIdDocum) {
        DocumentoSanci key = new DocumentoSanci();
        key.setNumIdDocum(numIdDocum);
        DocumentoSanci record = (DocumentoSanci) getSqlMapClientTemplate().queryForObject("txxxx4documsanci.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(DocumentoSanci record, DocumentoSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx4documsanci.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(DocumentoSanci record, DocumentoSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx4documsanci.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(DocumentoSanci record) {
        int rows = getSqlMapClientTemplate().update("txxxx4documsanci.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(DocumentoSanci record) {
        int rows = getSqlMapClientTemplate().update("txxxx4documsanci.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends DocumentoSanciExample {
        private Object record;

        public UpdateByExampleParms(Object record, DocumentoSanciExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}