package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExped;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExpedExample;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExpedKey;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.SeguimientoExpedDAO;

public class SqlMapSeguimientoExpedDAO extends SqlMapClientDaoSupport implements SeguimientoExpedDAO {

    public SqlMapSeguimientoExpedDAO() {
        super();
    }

    public int countByExample(SeguimientoExpedExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("txxxx2seguimexped.countByExample", example);
        return count;
    }

    public int deleteByExample(SeguimientoExpedExample example) {
        int rows = getSqlMapClientTemplate().delete("txxxx2seguimexped.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(SeguimientoExpedKey key) {
        int rows = getSqlMapClientTemplate().delete("txxxx2seguimexped.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(SeguimientoExped record) {
        getSqlMapClientTemplate().insert("txxxx2seguimexped.insert", record);
    }

    public void insertSelective(SeguimientoExped record) {
        getSqlMapClientTemplate().insert("txxxx2seguimexped.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<SeguimientoExped> selectByExample(SeguimientoExpedExample example) {
        List<SeguimientoExped> list = getSqlMapClientTemplate().queryForList("txxxx2seguimexped.selectByExample", example);
        return list;
    }

    public SeguimientoExped selectByPrimaryKey(SeguimientoExpedKey key) {
        SeguimientoExped record = (SeguimientoExped) getSqlMapClientTemplate().queryForObject("txxxx2seguimexped.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(SeguimientoExped record, SeguimientoExpedExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx2seguimexped.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(SeguimientoExped record, SeguimientoExpedExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx2seguimexped.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(SeguimientoExped record) {
        int rows = getSqlMapClientTemplate().update("txxxx2seguimexped.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(SeguimientoExped record) {
        int rows = getSqlMapClientTemplate().update("txxxx2seguimexped.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends SeguimientoExpedExample {
        private Object record;

        public UpdateByExampleParms(Object record, SeguimientoExpedExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}