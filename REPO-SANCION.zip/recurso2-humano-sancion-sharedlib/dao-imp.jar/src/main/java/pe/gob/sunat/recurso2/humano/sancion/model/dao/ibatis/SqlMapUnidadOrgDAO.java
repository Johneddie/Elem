package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.UnidadOrg;
import pe.gob.sunat.recurso2.humano.sancion.model.UnidadOrgExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.UnidadOrgDAO;

@SuppressWarnings("deprecation")
public class SqlMapUnidadOrgDAO extends SqlMapDAOBase implements UnidadOrgDAO {

    public SqlMapUnidadOrgDAO() {
        super();
    }
    
    @Override
    public int countByExample(UnidadOrgExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t12uorga.countByExample", example);
    }
    
    @Override
    public int deleteByExample(UnidadOrgExample example) {
    	return getSqlMapClientTemplate().delete("t12uorga.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(String t12codUorga) {
        UnidadOrg key = new UnidadOrg();
        key.setT12codUorga(t12codUorga);
        return getSqlMapClientTemplate().delete("t12uorga.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(UnidadOrg record) {
        getSqlMapClientTemplate().insert("t12uorga.insert", record);
    }
    
    @Override
    public void insertSelective(UnidadOrg record) {
        getSqlMapClientTemplate().insert("t12uorga.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<UnidadOrg> selectByExample(UnidadOrgExample example) {
    	return getSqlMapClientTemplate().queryForList("t12uorga.selectByExample", example);
    }
    
    @Override
    public UnidadOrg selectByPrimaryKey(String t12codUorga) {
        UnidadOrg key = new UnidadOrg();
        key.setT12codUorga(t12codUorga);
        return (UnidadOrg) getSqlMapClientTemplate().queryForObject("t12uorga.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(UnidadOrg record, UnidadOrgExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12uorga.updateByExampleSelective", parms);
        
    }
    
    @Override
    public int updateByExample(UnidadOrg record, UnidadOrgExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t12uorga.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(UnidadOrg record) {
    	return getSqlMapClientTemplate().update("t12uorga.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(UnidadOrg record) {
    	return getSqlMapClientTemplate().update("t12uorga.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends UnidadOrgExample {
        private Object record;

        public UpdateByExampleParms(Object record, UnidadOrgExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
    
    //personalizado
    
    public String obtenerCodJefeByCodUorga(String codUorga){
        UnidadOrg key = new UnidadOrg();
        key.setT12codUorga(codUorga);
    	UnidadOrg unidad = (UnidadOrg) getSqlMapClientTemplate().queryForObject("t12uorga.selectByPrimaryKey", key);
    	return  StringUtils.isBlank(unidad.getT12codEncar()) ? unidad.getT12codJefat() : unidad.getT12codEncar();
    }
  

}