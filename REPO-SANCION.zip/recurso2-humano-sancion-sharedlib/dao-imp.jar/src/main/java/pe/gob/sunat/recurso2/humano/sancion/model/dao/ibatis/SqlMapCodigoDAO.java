package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.model.Codigo;
import pe.gob.sunat.recurso2.humano.sancion.model.CodigoExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.CodigoDAO;

@SuppressWarnings("deprecation")
public class SqlMapCodigoDAO extends SqlMapDAOBase implements CodigoDAO {

    public SqlMapCodigoDAO() {
        super();
    }

    @Override
    public int countByExample(CodigoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t99codigos.countByExample", example);
    }

    @Override
    public int deleteByExample(CodigoExample example) {
    	return getSqlMapClientTemplate().delete("t99codigos.deleteByExample", example);
    }

    @Override
    public void insert(Codigo record) {
        getSqlMapClientTemplate().insert("t99codigos.insert", record);
    }

    @Override
    public void insertSelective(Codigo record) {
        getSqlMapClientTemplate().insert("t99codigos.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Codigo> selectByExample(CodigoExample example) {
    	return getSqlMapClientTemplate().queryForList("t99codigos.selectByExample", example);
    }

    @Override
    public int updateByExampleSelective(Codigo record, CodigoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t99codigos.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(Codigo record, CodigoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t99codigos.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends CodigoExample {
        private Object record;

        public UpdateByExampleParms(Object record, CodigoExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
    
    //personalizados
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Parametro> selectByExampleBasic(CodigoExample example) {
    	return getSqlMapClientTemplate().queryForList("t99codigos.selectByExampleBasic", example);
    }
    
	@SuppressWarnings("unchecked")
	@Override
	public List<Parametro> listarParametros(String codTabla){
		CodigoExample param = new CodigoExample() ;
		CodigoExample.Criteria criterio = param.createCriteria();
		criterio.andT99codTabEqualTo(codTabla);
		criterio.andT99estadoEqualTo("1");
		criterio.andT99tipDescEqualTo("D");
		return getSqlMapClientTemplate().queryForList("t99codigos.selectByExampleBasic", param);
	}
    
	@SuppressWarnings("unchecked")
	@Override
	public Parametro obtenerParametro(String codTabla, String codParametro){
		Parametro parametro = null;
		CodigoExample param = new CodigoExample() ;
		CodigoExample.Criteria criterio = param.createCriteria();
		criterio.andT99codTabEqualTo(codTabla);
		criterio.andT99estadoEqualTo("1");
		criterio.andT99tipDescEqualTo("D");
		criterio.andT99codigoEqualTo(codParametro);
		List<Parametro> lstParametros = getSqlMapClientTemplate().queryForList("t99codigos.selectByExampleBasic", param);
		if(!lstParametros.isEmpty())
			parametro = lstParametros.get(0);
		return parametro;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public String obtenerDescripcion(String codTabla, String codParametro){
		String parametro = null;
		CodigoExample param = new CodigoExample() ;
		CodigoExample.Criteria criterio = param.createCriteria();
		criterio.andT99codTabEqualTo(codTabla);
		criterio.andT99estadoEqualTo("1");
		criterio.andT99tipDescEqualTo("D");
		criterio.andT99codigoEqualTo(codParametro);
		List<Parametro> lstParametros = getSqlMapClientTemplate().queryForList("t99codigos.selectByExampleBasic", param);
		if(!lstParametros.isEmpty())
			parametro = lstParametros.get(0).getDesParametro();
		return parametro;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Parametro obtenerParametroBySigla(String codTabla, String codSigla){
		Parametro parametro = null;
		CodigoExample param = new CodigoExample() ;
		CodigoExample.Criteria criterio = param.createCriteria();
		criterio.andT99codTabEqualTo(codTabla);
		criterio.andT99estadoEqualTo("1");
		criterio.andT99tipDescEqualTo("D");
		criterio.andT99siglasEqualTo(codSigla);
		List<Parametro> lstParametros = getSqlMapClientTemplate().queryForList("t99codigos.selectByExampleBasic", param);
		if(!lstParametros.isEmpty())
			parametro = lstParametros.get(0);
		return parametro;
	}
	

}