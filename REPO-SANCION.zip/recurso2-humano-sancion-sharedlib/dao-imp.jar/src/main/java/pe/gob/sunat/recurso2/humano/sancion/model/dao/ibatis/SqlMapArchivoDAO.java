package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.Archivo;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ArchivoDAO;

@SuppressWarnings("deprecation")
public class SqlMapArchivoDAO extends SqlMapDAOBase implements ArchivoDAO {

    public SqlMapArchivoDAO() {
        super();
    }

    public int countByExample(ArchivoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t8152archivo.countByExample", example);
    }

    public int deleteByExample(ArchivoExample example) {
    	return getSqlMapClientTemplate().delete("t8152archivo.deleteByExample", example);
    }

    public int deleteByPrimaryKey(Integer numArchivo) {
        Archivo key = new Archivo();
        key.setNumArchivo(numArchivo);
        return getSqlMapClientTemplate().delete("t8152archivo.deleteByPrimaryKey", key);
    }

    public void insert(Archivo record) {
        getSqlMapClientTemplate().insert("t8152archivo.insert", record);
    }

    public void insertSelective(Archivo record) {
        getSqlMapClientTemplate().insert("t8152archivo.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Archivo> selectByExample(ArchivoExample example) {
    	return getSqlMapClientTemplate().queryForList("t8152archivo.selectByExample", example);
    }

    public Archivo selectByPrimaryKey(Integer numArchivo) {
        Archivo key = new Archivo();
        key.setNumArchivo(numArchivo);
        return (Archivo) getSqlMapClientTemplate().queryForObject("t8152archivo.selectByPrimaryKey", key);
    }

    public int updateByExampleSelective(Archivo record, ArchivoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8152archivo.updateByExampleSelective", parms);
    }

    public int updateByExample(Archivo record, ArchivoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8152archivo.updateByExample", parms);
    }

    public int updateByPrimaryKeySelective(Archivo record) {
    	return getSqlMapClientTemplate().update("t8152archivo.updateByPrimaryKeySelective", record);
    }

    public int updateByPrimaryKey(Archivo record) {
    	return getSqlMapClientTemplate().update("t8152archivo.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends ArchivoExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
}