package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanciExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ExpedienteSanciDAO;

public class SqlMapExpedienteSanciDAO extends SqlMapClientDaoSupport implements ExpedienteSanciDAO {

    public SqlMapExpedienteSanciDAO() {
        super();
    }

    public int countByExample(ExpedienteSanciExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("txxxx1expedisanci.countByExample", example);
        return count;
    }

    public int deleteByExample(ExpedienteSanciExample example) {
        int rows = getSqlMapClientTemplate().delete("txxxx1expedisanci.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer numIdExped) {
        ExpedienteSanci key = new ExpedienteSanci();
        key.setNumIdExped(numIdExped);
        int rows = getSqlMapClientTemplate().delete("txxxx1expedisanci.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(ExpedienteSanci record) {
        getSqlMapClientTemplate().insert("txxxx1expedisanci.insert", record);
    }

    public void insertSelective(ExpedienteSanci record) {
        getSqlMapClientTemplate().insert("txxxx1expedisanci.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<ExpedienteSanci> selectByExampleWithBLOBs(ExpedienteSanciExample example) {
        List<ExpedienteSanci> list = getSqlMapClientTemplate().queryForList("txxxx1expedisanci.selectByExampleWithBLOBs", example);
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<ExpedienteSanci> selectByExampleWithoutBLOBs(ExpedienteSanciExample example) {
        List<ExpedienteSanci> list = getSqlMapClientTemplate().queryForList("txxxx1expedisanci.selectByExample", example);
        return list;
    }

    public ExpedienteSanci selectByPrimaryKey(Integer numIdExped) {
        ExpedienteSanci key = new ExpedienteSanci();
        key.setNumIdExped(numIdExped);
        ExpedienteSanci record = (ExpedienteSanci) getSqlMapClientTemplate().queryForObject("txxxx1expedisanci.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(ExpedienteSanci record, ExpedienteSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx1expedisanci.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExampleWithBLOBs(ExpedienteSanci record, ExpedienteSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx1expedisanci.updateByExampleWithBLOBs", parms);
        return rows;
    }

    public int updateByExampleWithoutBLOBs(ExpedienteSanci record, ExpedienteSanciExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("txxxx1expedisanci.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(ExpedienteSanci record) {
        int rows = getSqlMapClientTemplate().update("txxxx1expedisanci.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKeyWithBLOBs(ExpedienteSanci record) {
        int rows = getSqlMapClientTemplate().update("txxxx1expedisanci.updateByPrimaryKeyWithBLOBs", record);
        return rows;
    }

    public int updateByPrimaryKeyWithoutBLOBs(ExpedienteSanci record) {
        int rows = getSqlMapClientTemplate().update("txxxx1expedisanci.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ExpedienteSanciExample {
        private Object record;

        public UpdateByExampleParms(Object record, ExpedienteSanciExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
    
    @SuppressWarnings("unchecked")
    public List<ExpedienteSanci> listarExpedientesIniciados(Map<String, Object> example) {
    	return getSqlMapClientTemplate().queryForList("txxxx1expedisanci.listarExpedientesIniciados", example);
    }
}