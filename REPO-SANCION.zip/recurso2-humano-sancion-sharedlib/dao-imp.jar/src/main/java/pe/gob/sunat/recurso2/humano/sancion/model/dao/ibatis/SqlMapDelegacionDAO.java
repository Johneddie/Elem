package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.Date;
import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.Delegacion;
import pe.gob.sunat.recurso2.humano.sancion.model.DelegacionExample;
import pe.gob.sunat.recurso2.humano.sancion.model.DelegacionKey;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DelegacionDAO;

@SuppressWarnings("deprecation")
public class SqlMapDelegacionDAO extends SqlMapDAOBase implements DelegacionDAO {

    public SqlMapDelegacionDAO() {
        super();
    }

    public int countByExample(DelegacionExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t1595delega.countByExample", example);
    }

    public int deleteByExample(DelegacionExample example) {
    	return getSqlMapClientTemplate().delete("t1595delega.deleteByExample", example);
    }

    public int deleteByPrimaryKey(DelegacionKey key) {
    	return getSqlMapClientTemplate().delete("t1595delega.deleteByPrimaryKey", key);
    }

    public void insert(Delegacion record) {
        getSqlMapClientTemplate().insert("t1595delega.insert", record);
    }

    public void insertSelective(Delegacion record) {
        getSqlMapClientTemplate().insert("t1595delega.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Delegacion> selectByExample(DelegacionExample example) {
    	return getSqlMapClientTemplate().queryForList("t1595delega.selectByExample", example);
    }

    public Delegacion selectByPrimaryKey(DelegacionKey key) {
    	return (Delegacion) getSqlMapClientTemplate().queryForObject("t1595delega.selectByPrimaryKey", key);
    }

    public int updateByExampleSelective(Delegacion record, DelegacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t1595delega.updateByExampleSelective", parms);
    }

    public int updateByExample(Delegacion record, DelegacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t1595delega.updateByExample", parms);
    }

    public int updateByPrimaryKeySelective(Delegacion record) {
        int rows = getSqlMapClientTemplate().update("t1595delega.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Delegacion record) {
    	return getSqlMapClientTemplate().update("t1595delega.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends DelegacionExample {
        private Object record;

        public UpdateByExampleParms(Object record, DelegacionExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
    
    @SuppressWarnings("unchecked")
    public Delegacion obtenerDelegacionPorUnidad(String codUnidad, List<String> lstOpciones) {
    	Delegacion delegacion = null;
    	Date today = new Date();
    	DelegacionExample exampleDel = new DelegacionExample();
    	DelegacionExample.Criteria criterioDel = exampleDel.createCriteria();
    	criterioDel.andCunidadOrganEqualTo(codUnidad);
    	criterioDel.andFinivigLessThanOrEqualTo(today);
    	criterioDel.andFfinvigGreaterThanOrEqualTo(today);
    	criterioDel.andSestadoActivoEqualTo("1");
    	criterioDel.andCodOpcionIn(lstOpciones);
        List<Delegacion> lstDelegaciones = getSqlMapClientTemplate().queryForList("t1595delega.selectByExample", exampleDel);
        if(!lstDelegaciones.isEmpty())
        	delegacion = lstDelegaciones.get(0);
        
        return delegacion;
    }
	
}