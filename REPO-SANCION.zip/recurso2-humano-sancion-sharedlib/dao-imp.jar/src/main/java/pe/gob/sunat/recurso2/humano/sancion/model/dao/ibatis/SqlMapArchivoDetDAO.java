package pe.gob.sunat.recurso2.humano.sancion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDet;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDetExample;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoDetKey;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ArchivoDetDAO;

@SuppressWarnings("deprecation")
public class SqlMapArchivoDetDAO extends SqlMapDAOBase implements ArchivoDetDAO {

    public SqlMapArchivoDetDAO() {
        super();
    }

    public int countByExample(ArchivoDetExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t8151archivodet.countByExample", example);
    }

    public int deleteByExample(ArchivoDetExample example) {
    	return getSqlMapClientTemplate().delete("t8151archivodet.deleteByExample", example);
    }

    public int deleteByPrimaryKey(ArchivoDetKey key) {
    	return getSqlMapClientTemplate().delete("t8151archivodet.deleteByPrimaryKey", key);
    }

    public void insert(ArchivoDet record) {
        getSqlMapClientTemplate().insert("t8151archivodet.insert", record);
    }

    public void insertSelective(ArchivoDet record) {
        getSqlMapClientTemplate().insert("t8151archivodet.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<ArchivoDet> selectByExampleWithBLOBs(ArchivoDetExample example) {
    	return getSqlMapClientTemplate().queryForList("t8151archivodet.selectByExampleWithBLOBs", example);
    }

    @SuppressWarnings("unchecked")
    public List<ArchivoDet> selectByExampleWithoutBLOBs(ArchivoDetExample example) {
    	return getSqlMapClientTemplate().queryForList("t8151archivodet.selectByExample", example);
    }

    public ArchivoDet selectByPrimaryKey(ArchivoDetKey key) {
    	return (ArchivoDet) getSqlMapClientTemplate().queryForObject("t8151archivodet.selectByPrimaryKey", key);
    }

    public int updateByExampleSelective(ArchivoDet record, ArchivoDetExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8151archivodet.updateByExampleSelective", parms);
    }

    public int updateByExampleWithBLOBs(ArchivoDet record, ArchivoDetExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8151archivodet.updateByExampleWithBLOBs", parms);
    }

    public int updateByExampleWithoutBLOBs(ArchivoDet record, ArchivoDetExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8151archivodet.updateByExample", parms);
    }

    public int updateByPrimaryKeySelective(ArchivoDet record) {
    	return getSqlMapClientTemplate().update("t8151archivodet.updateByPrimaryKeySelective", record);
    }

    public int updateByPrimaryKeyWithBLOBs(ArchivoDet record) {
    	return getSqlMapClientTemplate().update("t8151archivodet.updateByPrimaryKeyWithBLOBs", record);
    }

    public int updateByPrimaryKeyWithoutBLOBs(ArchivoDet record) {
    	return getSqlMapClientTemplate().update("t8151archivodet.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends ArchivoDetExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoDetExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
}