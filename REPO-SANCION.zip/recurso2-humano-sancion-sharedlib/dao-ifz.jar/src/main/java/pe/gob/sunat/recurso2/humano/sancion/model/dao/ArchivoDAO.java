package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.sancion.model.Archivo;
import pe.gob.sunat.recurso2.humano.sancion.model.ArchivoExample;

public interface ArchivoDAO {
    int countByExample(ArchivoExample example);

    int deleteByExample(ArchivoExample example);

    int deleteByPrimaryKey(Integer numArchivo);

    void insert(Archivo record);

    void insertSelective(Archivo record);

    List<Archivo> selectByExample(ArchivoExample example);

    Archivo selectByPrimaryKey(Integer numArchivo);

    int updateByExampleSelective(Archivo record, ArchivoExample example);

    int updateByExample(Archivo record, ArchivoExample example);

    int updateByPrimaryKeySelective(Archivo record);

    int updateByPrimaryKey(Archivo record);
}