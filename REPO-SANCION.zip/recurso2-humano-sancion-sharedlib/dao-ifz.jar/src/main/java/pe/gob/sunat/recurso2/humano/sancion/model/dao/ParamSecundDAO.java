package pe.gob.sunat.recurso2.humano.sancion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.sancion.model.ParamSecund;
import pe.gob.sunat.recurso2.humano.sancion.model.ParamSecundExample;
import pe.gob.sunat.recurso2.humano.sancion.model.ParamSecundKey;
import pe.gob.sunat.recurso2.humano.sancion.model.ParamSecundWithBLOBs;

public interface ParamSecundDAO {
    int countByExample(ParamSecundExample example);

    int deleteByExample(ParamSecundExample example);

    int deleteByPrimaryKey(ParamSecundKey key);

    void insert(ParamSecundWithBLOBs record);

    void insertSelective(ParamSecundWithBLOBs record);

    List<ParamSecundWithBLOBs> selectByExampleWithBLOBs(ParamSecundExample example);

    List<ParamSecund> selectByExampleWithoutBLOBs(ParamSecundExample example);

    ParamSecundWithBLOBs selectByPrimaryKey(ParamSecundKey key);

    int updateByExampleSelective(ParamSecundWithBLOBs record, ParamSecundExample example);

    int updateByExample(ParamSecundWithBLOBs record, ParamSecundExample example);

    int updateByExample(ParamSecund record, ParamSecundExample example);

    int updateByPrimaryKeySelective(ParamSecundWithBLOBs record);

    int updateByPrimaryKey(ParamSecundWithBLOBs record);

    int updateByPrimaryKey(ParamSecund record);
    
    public String obtenerDescripcion(String codTabla, String codParametro);
    
}