package pe.gob.sunat.recurso2.humano.sancion.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class PersonaExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public PersonaExample() {
        oredCriteria = new ArrayList<>();
    }

    protected PersonaExample(PersonaExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andT02codPersIsNull() {
            addCriterion("t02cod_pers is null");
            return this;
        }

        public Criteria andT02codPersIsNotNull() {
            addCriterion("t02cod_pers is not null");
            return this;
        }

        public Criteria andT02codPersEqualTo(String value) {
            addCriterion("t02cod_pers =", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersNotEqualTo(String value) {
            addCriterion("t02cod_pers <>", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersGreaterThan(String value) {
            addCriterion("t02cod_pers >", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_pers >=", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersLessThan(String value) {
            addCriterion("t02cod_pers <", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersLessThanOrEqualTo(String value) {
            addCriterion("t02cod_pers <=", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersLike(String value) {
            addCriterion("t02cod_pers like", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersNotLike(String value) {
            addCriterion("t02cod_pers not like", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersIn(List<String> values) {
            addCriterion("t02cod_pers in", values, "t02codPers");
            return this;
        }

        public Criteria andT02codPersNotIn(List<String> values) {
            addCriterion("t02cod_pers not in", values, "t02codPers");
            return this;
        }

        public Criteria andT02codPersBetween(String value1, String value2) {
            addCriterion("t02cod_pers between", value1, value2, "t02codPers");
            return this;
        }

        public Criteria andT02codPersNotBetween(String value1, String value2) {
            addCriterion("t02cod_pers not between", value1, value2, "t02codPers");
            return this;
        }

        public Criteria andT02codRelIsNull() {
            addCriterion("t02cod_rel is null");
            return this;
        }

        public Criteria andT02codRelIsNotNull() {
            addCriterion("t02cod_rel is not null");
            return this;
        }

        public Criteria andT02codRelEqualTo(String value) {
            addCriterion("t02cod_rel =", value, "t02codRel");
            return this;
        }

        public Criteria andT02codRelNotEqualTo(String value) {
            addCriterion("t02cod_rel <>", value, "t02codRel");
            return this;
        }

        public Criteria andT02codRelGreaterThan(String value) {
            addCriterion("t02cod_rel >", value, "t02codRel");
            return this;
        }

        public Criteria andT02codRelGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_rel >=", value, "t02codRel");
            return this;
        }

        public Criteria andT02codRelLessThan(String value) {
            addCriterion("t02cod_rel <", value, "t02codRel");
            return this;
        }

        public Criteria andT02codRelLessThanOrEqualTo(String value) {
            addCriterion("t02cod_rel <=", value, "t02codRel");
            return this;
        }

        public Criteria andT02codRelLike(String value) {
            addCriterion("t02cod_rel like", value, "t02codRel");
            return this;
        }

        public Criteria andT02codRelNotLike(String value) {
            addCriterion("t02cod_rel not like", value, "t02codRel");
            return this;
        }

        public Criteria andT02codRelIn(List<String> values) {
            addCriterion("t02cod_rel in", values, "t02codRel");
            return this;
        }

        public Criteria andT02codRelNotIn(List<String> values) {
            addCriterion("t02cod_rel not in", values, "t02codRel");
            return this;
        }

        public Criteria andT02codRelBetween(String value1, String value2) {
            addCriterion("t02cod_rel between", value1, value2, "t02codRel");
            return this;
        }

        public Criteria andT02codRelNotBetween(String value1, String value2) {
            addCriterion("t02cod_rel not between", value1, value2, "t02codRel");
            return this;
        }

        public Criteria andT02apPateIsNull() {
            addCriterion("t02ap_pate is null");
            return this;
        }

        public Criteria andT02apPateIsNotNull() {
            addCriterion("t02ap_pate is not null");
            return this;
        }

        public Criteria andT02apPateEqualTo(String value) {
            addCriterion("t02ap_pate =", value, "t02apPate");
            return this;
        }

        public Criteria andT02apPateNotEqualTo(String value) {
            addCriterion("t02ap_pate <>", value, "t02apPate");
            return this;
        }

        public Criteria andT02apPateGreaterThan(String value) {
            addCriterion("t02ap_pate >", value, "t02apPate");
            return this;
        }

        public Criteria andT02apPateGreaterThanOrEqualTo(String value) {
            addCriterion("t02ap_pate >=", value, "t02apPate");
            return this;
        }

        public Criteria andT02apPateLessThan(String value) {
            addCriterion("t02ap_pate <", value, "t02apPate");
            return this;
        }

        public Criteria andT02apPateLessThanOrEqualTo(String value) {
            addCriterion("t02ap_pate <=", value, "t02apPate");
            return this;
        }

        public Criteria andT02apPateLike(String value) {
            addCriterion("t02ap_pate like", value, "t02apPate");
            return this;
        }

        public Criteria andT02apPateNotLike(String value) {
            addCriterion("t02ap_pate not like", value, "t02apPate");
            return this;
        }

        public Criteria andT02apPateIn(List<String> values) {
            addCriterion("t02ap_pate in", values, "t02apPate");
            return this;
        }

        public Criteria andT02apPateNotIn(List<String> values) {
            addCriterion("t02ap_pate not in", values, "t02apPate");
            return this;
        }

        public Criteria andT02apPateBetween(String value1, String value2) {
            addCriterion("t02ap_pate between", value1, value2, "t02apPate");
            return this;
        }

        public Criteria andT02apPateNotBetween(String value1, String value2) {
            addCriterion("t02ap_pate not between", value1, value2, "t02apPate");
            return this;
        }

        public Criteria andT02apMateIsNull() {
            addCriterion("t02ap_mate is null");
            return this;
        }

        public Criteria andT02apMateIsNotNull() {
            addCriterion("t02ap_mate is not null");
            return this;
        }

        public Criteria andT02apMateEqualTo(String value) {
            addCriterion("t02ap_mate =", value, "t02apMate");
            return this;
        }

        public Criteria andT02apMateNotEqualTo(String value) {
            addCriterion("t02ap_mate <>", value, "t02apMate");
            return this;
        }

        public Criteria andT02apMateGreaterThan(String value) {
            addCriterion("t02ap_mate >", value, "t02apMate");
            return this;
        }

        public Criteria andT02apMateGreaterThanOrEqualTo(String value) {
            addCriterion("t02ap_mate >=", value, "t02apMate");
            return this;
        }

        public Criteria andT02apMateLessThan(String value) {
            addCriterion("t02ap_mate <", value, "t02apMate");
            return this;
        }

        public Criteria andT02apMateLessThanOrEqualTo(String value) {
            addCriterion("t02ap_mate <=", value, "t02apMate");
            return this;
        }

        public Criteria andT02apMateLike(String value) {
            addCriterion("t02ap_mate like", value, "t02apMate");
            return this;
        }

        public Criteria andT02apMateNotLike(String value) {
            addCriterion("t02ap_mate not like", value, "t02apMate");
            return this;
        }

        public Criteria andT02apMateIn(List<String> values) {
            addCriterion("t02ap_mate in", values, "t02apMate");
            return this;
        }

        public Criteria andT02apMateNotIn(List<String> values) {
            addCriterion("t02ap_mate not in", values, "t02apMate");
            return this;
        }

        public Criteria andT02apMateBetween(String value1, String value2) {
            addCriterion("t02ap_mate between", value1, value2, "t02apMate");
            return this;
        }

        public Criteria andT02apMateNotBetween(String value1, String value2) {
            addCriterion("t02ap_mate not between", value1, value2, "t02apMate");
            return this;
        }

        public Criteria andT02nombresIsNull() {
            addCriterion("t02nombres is null");
            return this;
        }

        public Criteria andT02nombresIsNotNull() {
            addCriterion("t02nombres is not null");
            return this;
        }

        public Criteria andT02nombresEqualTo(String value) {
            addCriterion("t02nombres =", value, "t02nombres");
            return this;
        }

        public Criteria andT02nombresNotEqualTo(String value) {
            addCriterion("t02nombres <>", value, "t02nombres");
            return this;
        }

        public Criteria andT02nombresGreaterThan(String value) {
            addCriterion("t02nombres >", value, "t02nombres");
            return this;
        }

        public Criteria andT02nombresGreaterThanOrEqualTo(String value) {
            addCriterion("t02nombres >=", value, "t02nombres");
            return this;
        }

        public Criteria andT02nombresLessThan(String value) {
            addCriterion("t02nombres <", value, "t02nombres");
            return this;
        }

        public Criteria andT02nombresLessThanOrEqualTo(String value) {
            addCriterion("t02nombres <=", value, "t02nombres");
            return this;
        }

        public Criteria andT02nombresLike(String value) {
            addCriterion("t02nombres like", value, "t02nombres");
            return this;
        }

        public Criteria andT02nombresNotLike(String value) {
            addCriterion("t02nombres not like", value, "t02nombres");
            return this;
        }

        public Criteria andT02nombresIn(List<String> values) {
            addCriterion("t02nombres in", values, "t02nombres");
            return this;
        }

        public Criteria andT02nombresNotIn(List<String> values) {
            addCriterion("t02nombres not in", values, "t02nombres");
            return this;
        }

        public Criteria andT02nombresBetween(String value1, String value2) {
            addCriterion("t02nombres between", value1, value2, "t02nombres");
            return this;
        }

        public Criteria andT02nombresNotBetween(String value1, String value2) {
            addCriterion("t02nombres not between", value1, value2, "t02nombres");
            return this;
        }

        public Criteria andT02codUorgIsNull() {
            addCriterion("t02cod_uorg is null");
            return this;
        }

        public Criteria andT02codUorgIsNotNull() {
            addCriterion("t02cod_uorg is not null");
            return this;
        }

        public Criteria andT02codUorgEqualTo(String value) {
            addCriterion("t02cod_uorg =", value, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgNotEqualTo(String value) {
            addCriterion("t02cod_uorg <>", value, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgGreaterThan(String value) {
            addCriterion("t02cod_uorg >", value, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_uorg >=", value, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgLessThan(String value) {
            addCriterion("t02cod_uorg <", value, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgLessThanOrEqualTo(String value) {
            addCriterion("t02cod_uorg <=", value, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgLike(String value) {
            addCriterion("t02cod_uorg like", value, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgNotLike(String value) {
            addCriterion("t02cod_uorg not like", value, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgIn(List<String> values) {
            addCriterion("t02cod_uorg in", values, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgNotIn(List<String> values) {
            addCriterion("t02cod_uorg not in", values, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgBetween(String value1, String value2) {
            addCriterion("t02cod_uorg between", value1, value2, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorgNotBetween(String value1, String value2) {
            addCriterion("t02cod_uorg not between", value1, value2, "t02codUorg");
            return this;
        }

        public Criteria andT02codUorglIsNull() {
            addCriterion("t02cod_uorgl is null");
            return this;
        }

        public Criteria andT02codUorglIsNotNull() {
            addCriterion("t02cod_uorgl is not null");
            return this;
        }

        public Criteria andT02codUorglEqualTo(String value) {
            addCriterion("t02cod_uorgl =", value, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglNotEqualTo(String value) {
            addCriterion("t02cod_uorgl <>", value, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglGreaterThan(String value) {
            addCriterion("t02cod_uorgl >", value, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_uorgl >=", value, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglLessThan(String value) {
            addCriterion("t02cod_uorgl <", value, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglLessThanOrEqualTo(String value) {
            addCriterion("t02cod_uorgl <=", value, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglLike(String value) {
            addCriterion("t02cod_uorgl like", value, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglNotLike(String value) {
            addCriterion("t02cod_uorgl not like", value, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglIn(List<String> values) {
            addCriterion("t02cod_uorgl in", values, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglNotIn(List<String> values) {
            addCriterion("t02cod_uorgl not in", values, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglBetween(String value1, String value2) {
            addCriterion("t02cod_uorgl between", value1, value2, "t02codUorgl");
            return this;
        }

        public Criteria andT02codUorglNotBetween(String value1, String value2) {
            addCriterion("t02cod_uorgl not between", value1, value2, "t02codUorgl");
            return this;
        }

        public Criteria andT02codCateIsNull() {
            addCriterion("t02cod_cate is null");
            return this;
        }

        public Criteria andT02codCateIsNotNull() {
            addCriterion("t02cod_cate is not null");
            return this;
        }

        public Criteria andT02codCateEqualTo(String value) {
            addCriterion("t02cod_cate =", value, "t02codCate");
            return this;
        }

        public Criteria andT02codCateNotEqualTo(String value) {
            addCriterion("t02cod_cate <>", value, "t02codCate");
            return this;
        }

        public Criteria andT02codCateGreaterThan(String value) {
            addCriterion("t02cod_cate >", value, "t02codCate");
            return this;
        }

        public Criteria andT02codCateGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_cate >=", value, "t02codCate");
            return this;
        }

        public Criteria andT02codCateLessThan(String value) {
            addCriterion("t02cod_cate <", value, "t02codCate");
            return this;
        }

        public Criteria andT02codCateLessThanOrEqualTo(String value) {
            addCriterion("t02cod_cate <=", value, "t02codCate");
            return this;
        }

        public Criteria andT02codCateLike(String value) {
            addCriterion("t02cod_cate like", value, "t02codCate");
            return this;
        }

        public Criteria andT02codCateNotLike(String value) {
            addCriterion("t02cod_cate not like", value, "t02codCate");
            return this;
        }

        public Criteria andT02codCateIn(List<String> values) {
            addCriterion("t02cod_cate in", values, "t02codCate");
            return this;
        }

        public Criteria andT02codCateNotIn(List<String> values) {
            addCriterion("t02cod_cate not in", values, "t02codCate");
            return this;
        }

        public Criteria andT02codCateBetween(String value1, String value2) {
            addCriterion("t02cod_cate between", value1, value2, "t02codCate");
            return this;
        }

        public Criteria andT02codCateNotBetween(String value1, String value2) {
            addCriterion("t02cod_cate not between", value1, value2, "t02codCate");
            return this;
        }

        public Criteria andT02codCatelIsNull() {
            addCriterion("t02cod_catel is null");
            return this;
        }

        public Criteria andT02codCatelIsNotNull() {
            addCriterion("t02cod_catel is not null");
            return this;
        }

        public Criteria andT02codCatelEqualTo(String value) {
            addCriterion("t02cod_catel =", value, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelNotEqualTo(String value) {
            addCriterion("t02cod_catel <>", value, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelGreaterThan(String value) {
            addCriterion("t02cod_catel >", value, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_catel >=", value, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelLessThan(String value) {
            addCriterion("t02cod_catel <", value, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelLessThanOrEqualTo(String value) {
            addCriterion("t02cod_catel <=", value, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelLike(String value) {
            addCriterion("t02cod_catel like", value, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelNotLike(String value) {
            addCriterion("t02cod_catel not like", value, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelIn(List<String> values) {
            addCriterion("t02cod_catel in", values, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelNotIn(List<String> values) {
            addCriterion("t02cod_catel not in", values, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelBetween(String value1, String value2) {
            addCriterion("t02cod_catel between", value1, value2, "t02codCatel");
            return this;
        }

        public Criteria andT02codCatelNotBetween(String value1, String value2) {
            addCriterion("t02cod_catel not between", value1, value2, "t02codCatel");
            return this;
        }

        public Criteria andT02codCargIsNull() {
            addCriterion("t02cod_carg is null");
            return this;
        }

        public Criteria andT02codCargIsNotNull() {
            addCriterion("t02cod_carg is not null");
            return this;
        }

        public Criteria andT02codCargEqualTo(String value) {
            addCriterion("t02cod_carg =", value, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargNotEqualTo(String value) {
            addCriterion("t02cod_carg <>", value, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargGreaterThan(String value) {
            addCriterion("t02cod_carg >", value, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_carg >=", value, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargLessThan(String value) {
            addCriterion("t02cod_carg <", value, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargLessThanOrEqualTo(String value) {
            addCriterion("t02cod_carg <=", value, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargLike(String value) {
            addCriterion("t02cod_carg like", value, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargNotLike(String value) {
            addCriterion("t02cod_carg not like", value, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargIn(List<String> values) {
            addCriterion("t02cod_carg in", values, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargNotIn(List<String> values) {
            addCriterion("t02cod_carg not in", values, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargBetween(String value1, String value2) {
            addCriterion("t02cod_carg between", value1, value2, "t02codCarg");
            return this;
        }

        public Criteria andT02codCargNotBetween(String value1, String value2) {
            addCriterion("t02cod_carg not between", value1, value2, "t02codCarg");
            return this;
        }

        public Criteria andT02fIngsunIsNull() {
            addCriterion("t02f_ingsun is null");
            return this;
        }

        public Criteria andT02fIngsunIsNotNull() {
            addCriterion("t02f_ingsun is not null");
            return this;
        }

        public Criteria andT02fIngsunEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ingsun =", value, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunNotEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ingsun <>", value, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunGreaterThan(Date value) {
            addCriterionForJDBCDate("t02f_ingsun >", value, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ingsun >=", value, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunLessThan(Date value) {
            addCriterionForJDBCDate("t02f_ingsun <", value, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ingsun <=", value, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_ingsun in", values, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunNotIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_ingsun not in", values, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_ingsun between", value1, value2, "t02fIngsun");
            return this;
        }

        public Criteria andT02fIngsunNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_ingsun not between", value1, value2, "t02fIngsun");
            return this;
        }

        public Criteria andT02fCeseIsNull() {
            addCriterion("t02f_cese is null");
            return this;
        }

        public Criteria andT02fCeseIsNotNull() {
            addCriterion("t02f_cese is not null");
            return this;
        }

        public Criteria andT02fCeseEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_cese =", value, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseNotEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_cese <>", value, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseGreaterThan(Date value) {
            addCriterionForJDBCDate("t02f_cese >", value, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_cese >=", value, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseLessThan(Date value) {
            addCriterionForJDBCDate("t02f_cese <", value, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_cese <=", value, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_cese in", values, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseNotIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_cese not in", values, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_cese between", value1, value2, "t02fCese");
            return this;
        }

        public Criteria andT02fCeseNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_cese not between", value1, value2, "t02fCese");
            return this;
        }

        public Criteria andT02codReglIsNull() {
            addCriterion("t02cod_regl is null");
            return this;
        }

        public Criteria andT02codReglIsNotNull() {
            addCriterion("t02cod_regl is not null");
            return this;
        }

        public Criteria andT02codReglEqualTo(String value) {
            addCriterion("t02cod_regl =", value, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglNotEqualTo(String value) {
            addCriterion("t02cod_regl <>", value, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglGreaterThan(String value) {
            addCriterion("t02cod_regl >", value, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_regl >=", value, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglLessThan(String value) {
            addCriterion("t02cod_regl <", value, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglLessThanOrEqualTo(String value) {
            addCriterion("t02cod_regl <=", value, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglLike(String value) {
            addCriterion("t02cod_regl like", value, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglNotLike(String value) {
            addCriterion("t02cod_regl not like", value, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglIn(List<String> values) {
            addCriterion("t02cod_regl in", values, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglNotIn(List<String> values) {
            addCriterion("t02cod_regl not in", values, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglBetween(String value1, String value2) {
            addCriterion("t02cod_regl between", value1, value2, "t02codRegl");
            return this;
        }

        public Criteria andT02codReglNotBetween(String value1, String value2) {
            addCriterion("t02cod_regl not between", value1, value2, "t02codRegl");
            return this;
        }

        public Criteria andT02fNacimIsNull() {
            addCriterion("t02f_nacim is null");
            return this;
        }

        public Criteria andT02fNacimIsNotNull() {
            addCriterion("t02f_nacim is not null");
            return this;
        }

        public Criteria andT02fNacimEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_nacim =", value, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimNotEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_nacim <>", value, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimGreaterThan(Date value) {
            addCriterionForJDBCDate("t02f_nacim >", value, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_nacim >=", value, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimLessThan(Date value) {
            addCriterionForJDBCDate("t02f_nacim <", value, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_nacim <=", value, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_nacim in", values, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimNotIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_nacim not in", values, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_nacim between", value1, value2, "t02fNacim");
            return this;
        }

        public Criteria andT02fNacimNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_nacim not between", value1, value2, "t02fNacim");
            return this;
        }

        public Criteria andT02codUbipIsNull() {
            addCriterion("t02cod_ubip is null");
            return this;
        }

        public Criteria andT02codUbipIsNotNull() {
            addCriterion("t02cod_ubip is not null");
            return this;
        }

        public Criteria andT02codUbipEqualTo(String value) {
            addCriterion("t02cod_ubip =", value, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipNotEqualTo(String value) {
            addCriterion("t02cod_ubip <>", value, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipGreaterThan(String value) {
            addCriterion("t02cod_ubip >", value, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_ubip >=", value, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipLessThan(String value) {
            addCriterion("t02cod_ubip <", value, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipLessThanOrEqualTo(String value) {
            addCriterion("t02cod_ubip <=", value, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipLike(String value) {
            addCriterion("t02cod_ubip like", value, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipNotLike(String value) {
            addCriterion("t02cod_ubip not like", value, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipIn(List<String> values) {
            addCriterion("t02cod_ubip in", values, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipNotIn(List<String> values) {
            addCriterion("t02cod_ubip not in", values, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipBetween(String value1, String value2) {
            addCriterion("t02cod_ubip between", value1, value2, "t02codUbip");
            return this;
        }

        public Criteria andT02codUbipNotBetween(String value1, String value2) {
            addCriterion("t02cod_ubip not between", value1, value2, "t02codUbip");
            return this;
        }

        public Criteria andT02urbanIsNull() {
            addCriterion("t02urban is null");
            return this;
        }

        public Criteria andT02urbanIsNotNull() {
            addCriterion("t02urban is not null");
            return this;
        }

        public Criteria andT02urbanEqualTo(String value) {
            addCriterion("t02urban =", value, "t02urban");
            return this;
        }

        public Criteria andT02urbanNotEqualTo(String value) {
            addCriterion("t02urban <>", value, "t02urban");
            return this;
        }

        public Criteria andT02urbanGreaterThan(String value) {
            addCriterion("t02urban >", value, "t02urban");
            return this;
        }

        public Criteria andT02urbanGreaterThanOrEqualTo(String value) {
            addCriterion("t02urban >=", value, "t02urban");
            return this;
        }

        public Criteria andT02urbanLessThan(String value) {
            addCriterion("t02urban <", value, "t02urban");
            return this;
        }

        public Criteria andT02urbanLessThanOrEqualTo(String value) {
            addCriterion("t02urban <=", value, "t02urban");
            return this;
        }

        public Criteria andT02urbanLike(String value) {
            addCriterion("t02urban like", value, "t02urban");
            return this;
        }

        public Criteria andT02urbanNotLike(String value) {
            addCriterion("t02urban not like", value, "t02urban");
            return this;
        }

        public Criteria andT02urbanIn(List<String> values) {
            addCriterion("t02urban in", values, "t02urban");
            return this;
        }

        public Criteria andT02urbanNotIn(List<String> values) {
            addCriterion("t02urban not in", values, "t02urban");
            return this;
        }

        public Criteria andT02urbanBetween(String value1, String value2) {
            addCriterion("t02urban between", value1, value2, "t02urban");
            return this;
        }

        public Criteria andT02urbanNotBetween(String value1, String value2) {
            addCriterion("t02urban not between", value1, value2, "t02urban");
            return this;
        }

        public Criteria andT02direccionIsNull() {
            addCriterion("t02direccion is null");
            return this;
        }

        public Criteria andT02direccionIsNotNull() {
            addCriterion("t02direccion is not null");
            return this;
        }

        public Criteria andT02direccionEqualTo(String value) {
            addCriterion("t02direccion =", value, "t02direccion");
            return this;
        }

        public Criteria andT02direccionNotEqualTo(String value) {
            addCriterion("t02direccion <>", value, "t02direccion");
            return this;
        }

        public Criteria andT02direccionGreaterThan(String value) {
            addCriterion("t02direccion >", value, "t02direccion");
            return this;
        }

        public Criteria andT02direccionGreaterThanOrEqualTo(String value) {
            addCriterion("t02direccion >=", value, "t02direccion");
            return this;
        }

        public Criteria andT02direccionLessThan(String value) {
            addCriterion("t02direccion <", value, "t02direccion");
            return this;
        }

        public Criteria andT02direccionLessThanOrEqualTo(String value) {
            addCriterion("t02direccion <=", value, "t02direccion");
            return this;
        }

        public Criteria andT02direccionLike(String value) {
            addCriterion("t02direccion like", value, "t02direccion");
            return this;
        }

        public Criteria andT02direccionNotLike(String value) {
            addCriterion("t02direccion not like", value, "t02direccion");
            return this;
        }

        public Criteria andT02direccionIn(List<String> values) {
            addCriterion("t02direccion in", values, "t02direccion");
            return this;
        }

        public Criteria andT02direccionNotIn(List<String> values) {
            addCriterion("t02direccion not in", values, "t02direccion");
            return this;
        }

        public Criteria andT02direccionBetween(String value1, String value2) {
            addCriterion("t02direccion between", value1, value2, "t02direccion");
            return this;
        }

        public Criteria andT02direccionNotBetween(String value1, String value2) {
            addCriterion("t02direccion not between", value1, value2, "t02direccion");
            return this;
        }

        public Criteria andT02referIsNull() {
            addCriterion("t02refer is null");
            return this;
        }

        public Criteria andT02referIsNotNull() {
            addCriterion("t02refer is not null");
            return this;
        }

        public Criteria andT02referEqualTo(String value) {
            addCriterion("t02refer =", value, "t02refer");
            return this;
        }

        public Criteria andT02referNotEqualTo(String value) {
            addCriterion("t02refer <>", value, "t02refer");
            return this;
        }

        public Criteria andT02referGreaterThan(String value) {
            addCriterion("t02refer >", value, "t02refer");
            return this;
        }

        public Criteria andT02referGreaterThanOrEqualTo(String value) {
            addCriterion("t02refer >=", value, "t02refer");
            return this;
        }

        public Criteria andT02referLessThan(String value) {
            addCriterion("t02refer <", value, "t02refer");
            return this;
        }

        public Criteria andT02referLessThanOrEqualTo(String value) {
            addCriterion("t02refer <=", value, "t02refer");
            return this;
        }

        public Criteria andT02referLike(String value) {
            addCriterion("t02refer like", value, "t02refer");
            return this;
        }

        public Criteria andT02referNotLike(String value) {
            addCriterion("t02refer not like", value, "t02refer");
            return this;
        }

        public Criteria andT02referIn(List<String> values) {
            addCriterion("t02refer in", values, "t02refer");
            return this;
        }

        public Criteria andT02referNotIn(List<String> values) {
            addCriterion("t02refer not in", values, "t02refer");
            return this;
        }

        public Criteria andT02referBetween(String value1, String value2) {
            addCriterion("t02refer between", value1, value2, "t02refer");
            return this;
        }

        public Criteria andT02referNotBetween(String value1, String value2) {
            addCriterion("t02refer not between", value1, value2, "t02refer");
            return this;
        }

        public Criteria andT02libElecIsNull() {
            addCriterion("t02lib_elec is null");
            return this;
        }

        public Criteria andT02libElecIsNotNull() {
            addCriterion("t02lib_elec is not null");
            return this;
        }

        public Criteria andT02libElecEqualTo(String value) {
            addCriterion("t02lib_elec =", value, "t02libElec");
            return this;
        }

        public Criteria andT02libElecNotEqualTo(String value) {
            addCriterion("t02lib_elec <>", value, "t02libElec");
            return this;
        }

        public Criteria andT02libElecGreaterThan(String value) {
            addCriterion("t02lib_elec >", value, "t02libElec");
            return this;
        }

        public Criteria andT02libElecGreaterThanOrEqualTo(String value) {
            addCriterion("t02lib_elec >=", value, "t02libElec");
            return this;
        }

        public Criteria andT02libElecLessThan(String value) {
            addCriterion("t02lib_elec <", value, "t02libElec");
            return this;
        }

        public Criteria andT02libElecLessThanOrEqualTo(String value) {
            addCriterion("t02lib_elec <=", value, "t02libElec");
            return this;
        }

        public Criteria andT02libElecLike(String value) {
            addCriterion("t02lib_elec like", value, "t02libElec");
            return this;
        }

        public Criteria andT02libElecNotLike(String value) {
            addCriterion("t02lib_elec not like", value, "t02libElec");
            return this;
        }

        public Criteria andT02libElecIn(List<String> values) {
            addCriterion("t02lib_elec in", values, "t02libElec");
            return this;
        }

        public Criteria andT02libElecNotIn(List<String> values) {
            addCriterion("t02lib_elec not in", values, "t02libElec");
            return this;
        }

        public Criteria andT02libElecBetween(String value1, String value2) {
            addCriterion("t02lib_elec between", value1, value2, "t02libElec");
            return this;
        }

        public Criteria andT02libElecNotBetween(String value1, String value2) {
            addCriterion("t02lib_elec not between", value1, value2, "t02libElec");
            return this;
        }

        public Criteria andT02codTurnIsNull() {
            addCriterion("t02cod_turn is null");
            return this;
        }

        public Criteria andT02codTurnIsNotNull() {
            addCriterion("t02cod_turn is not null");
            return this;
        }

        public Criteria andT02codTurnEqualTo(String value) {
            addCriterion("t02cod_turn =", value, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnNotEqualTo(String value) {
            addCriterion("t02cod_turn <>", value, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnGreaterThan(String value) {
            addCriterion("t02cod_turn >", value, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_turn >=", value, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnLessThan(String value) {
            addCriterion("t02cod_turn <", value, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnLessThanOrEqualTo(String value) {
            addCriterion("t02cod_turn <=", value, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnLike(String value) {
            addCriterion("t02cod_turn like", value, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnNotLike(String value) {
            addCriterion("t02cod_turn not like", value, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnIn(List<String> values) {
            addCriterion("t02cod_turn in", values, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnNotIn(List<String> values) {
            addCriterion("t02cod_turn not in", values, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnBetween(String value1, String value2) {
            addCriterion("t02cod_turn between", value1, value2, "t02codTurn");
            return this;
        }

        public Criteria andT02codTurnNotBetween(String value1, String value2) {
            addCriterion("t02cod_turn not between", value1, value2, "t02codTurn");
            return this;
        }

        public Criteria andT02tipPersIsNull() {
            addCriterion("t02tip_pers is null");
            return this;
        }

        public Criteria andT02tipPersIsNotNull() {
            addCriterion("t02tip_pers is not null");
            return this;
        }

        public Criteria andT02tipPersEqualTo(String value) {
            addCriterion("t02tip_pers =", value, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersNotEqualTo(String value) {
            addCriterion("t02tip_pers <>", value, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersGreaterThan(String value) {
            addCriterion("t02tip_pers >", value, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersGreaterThanOrEqualTo(String value) {
            addCriterion("t02tip_pers >=", value, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersLessThan(String value) {
            addCriterion("t02tip_pers <", value, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersLessThanOrEqualTo(String value) {
            addCriterion("t02tip_pers <=", value, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersLike(String value) {
            addCriterion("t02tip_pers like", value, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersNotLike(String value) {
            addCriterion("t02tip_pers not like", value, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersIn(List<String> values) {
            addCriterion("t02tip_pers in", values, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersNotIn(List<String> values) {
            addCriterion("t02tip_pers not in", values, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersBetween(String value1, String value2) {
            addCriterion("t02tip_pers between", value1, value2, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPersNotBetween(String value1, String value2) {
            addCriterion("t02tip_pers not between", value1, value2, "t02tipPers");
            return this;
        }

        public Criteria andT02tipPermIsNull() {
            addCriterion("t02tip_perm is null");
            return this;
        }

        public Criteria andT02tipPermIsNotNull() {
            addCriterion("t02tip_perm is not null");
            return this;
        }

        public Criteria andT02tipPermEqualTo(String value) {
            addCriterion("t02tip_perm =", value, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermNotEqualTo(String value) {
            addCriterion("t02tip_perm <>", value, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermGreaterThan(String value) {
            addCriterion("t02tip_perm >", value, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermGreaterThanOrEqualTo(String value) {
            addCriterion("t02tip_perm >=", value, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermLessThan(String value) {
            addCriterion("t02tip_perm <", value, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermLessThanOrEqualTo(String value) {
            addCriterion("t02tip_perm <=", value, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermLike(String value) {
            addCriterion("t02tip_perm like", value, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermNotLike(String value) {
            addCriterion("t02tip_perm not like", value, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermIn(List<String> values) {
            addCriterion("t02tip_perm in", values, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermNotIn(List<String> values) {
            addCriterion("t02tip_perm not in", values, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermBetween(String value1, String value2) {
            addCriterion("t02tip_perm between", value1, value2, "t02tipPerm");
            return this;
        }

        public Criteria andT02tipPermNotBetween(String value1, String value2) {
            addCriterion("t02tip_perm not between", value1, value2, "t02tipPerm");
            return this;
        }

        public Criteria andT02ctrlAsisIsNull() {
            addCriterion("t02ctrl_asis is null");
            return this;
        }

        public Criteria andT02ctrlAsisIsNotNull() {
            addCriterion("t02ctrl_asis is not null");
            return this;
        }

        public Criteria andT02ctrlAsisEqualTo(String value) {
            addCriterion("t02ctrl_asis =", value, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisNotEqualTo(String value) {
            addCriterion("t02ctrl_asis <>", value, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisGreaterThan(String value) {
            addCriterion("t02ctrl_asis >", value, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisGreaterThanOrEqualTo(String value) {
            addCriterion("t02ctrl_asis >=", value, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisLessThan(String value) {
            addCriterion("t02ctrl_asis <", value, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisLessThanOrEqualTo(String value) {
            addCriterion("t02ctrl_asis <=", value, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisLike(String value) {
            addCriterion("t02ctrl_asis like", value, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisNotLike(String value) {
            addCriterion("t02ctrl_asis not like", value, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisIn(List<String> values) {
            addCriterion("t02ctrl_asis in", values, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisNotIn(List<String> values) {
            addCriterion("t02ctrl_asis not in", values, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisBetween(String value1, String value2) {
            addCriterion("t02ctrl_asis between", value1, value2, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02ctrlAsisNotBetween(String value1, String value2) {
            addCriterion("t02ctrl_asis not between", value1, value2, "t02ctrlAsis");
            return this;
        }

        public Criteria andT02codStatIsNull() {
            addCriterion("t02cod_stat is null");
            return this;
        }

        public Criteria andT02codStatIsNotNull() {
            addCriterion("t02cod_stat is not null");
            return this;
        }

        public Criteria andT02codStatEqualTo(String value) {
            addCriterion("t02cod_stat =", value, "t02codStat");
            return this;
        }

        public Criteria andT02codStatNotEqualTo(String value) {
            addCriterion("t02cod_stat <>", value, "t02codStat");
            return this;
        }

        public Criteria andT02codStatGreaterThan(String value) {
            addCriterion("t02cod_stat >", value, "t02codStat");
            return this;
        }

        public Criteria andT02codStatGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_stat >=", value, "t02codStat");
            return this;
        }

        public Criteria andT02codStatLessThan(String value) {
            addCriterion("t02cod_stat <", value, "t02codStat");
            return this;
        }

        public Criteria andT02codStatLessThanOrEqualTo(String value) {
            addCriterion("t02cod_stat <=", value, "t02codStat");
            return this;
        }

        public Criteria andT02codStatLike(String value) {
            addCriterion("t02cod_stat like", value, "t02codStat");
            return this;
        }

        public Criteria andT02codStatNotLike(String value) {
            addCriterion("t02cod_stat not like", value, "t02codStat");
            return this;
        }

        public Criteria andT02codStatIn(List<String> values) {
            addCriterion("t02cod_stat in", values, "t02codStat");
            return this;
        }

        public Criteria andT02codStatNotIn(List<String> values) {
            addCriterion("t02cod_stat not in", values, "t02codStat");
            return this;
        }

        public Criteria andT02codStatBetween(String value1, String value2) {
            addCriterion("t02cod_stat between", value1, value2, "t02codStat");
            return this;
        }

        public Criteria andT02codStatNotBetween(String value1, String value2) {
            addCriterion("t02cod_stat not between", value1, value2, "t02codStat");
            return this;
        }

        public Criteria andT02suelBasIsNull() {
            addCriterion("t02suel_bas is null");
            return this;
        }

        public Criteria andT02suelBasIsNotNull() {
            addCriterion("t02suel_bas is not null");
            return this;
        }

        public Criteria andT02suelBasEqualTo(BigDecimal value) {
            addCriterion("t02suel_bas =", value, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasNotEqualTo(BigDecimal value) {
            addCriterion("t02suel_bas <>", value, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasGreaterThan(BigDecimal value) {
            addCriterion("t02suel_bas >", value, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("t02suel_bas >=", value, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasLessThan(BigDecimal value) {
            addCriterion("t02suel_bas <", value, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasLessThanOrEqualTo(BigDecimal value) {
            addCriterion("t02suel_bas <=", value, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasIn(List<BigDecimal> values) {
            addCriterion("t02suel_bas in", values, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasNotIn(List<BigDecimal> values) {
            addCriterion("t02suel_bas not in", values, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("t02suel_bas between", value1, value2, "t02suelBas");
            return this;
        }

        public Criteria andT02suelBasNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("t02suel_bas not between", value1, value2, "t02suelBas");
            return this;
        }

        public Criteria andT02codAnteIsNull() {
            addCriterion("t02cod_ante is null");
            return this;
        }

        public Criteria andT02codAnteIsNotNull() {
            addCriterion("t02cod_ante is not null");
            return this;
        }

        public Criteria andT02codAnteEqualTo(String value) {
            addCriterion("t02cod_ante =", value, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteNotEqualTo(String value) {
            addCriterion("t02cod_ante <>", value, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteGreaterThan(String value) {
            addCriterion("t02cod_ante >", value, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_ante >=", value, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteLessThan(String value) {
            addCriterion("t02cod_ante <", value, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteLessThanOrEqualTo(String value) {
            addCriterion("t02cod_ante <=", value, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteLike(String value) {
            addCriterion("t02cod_ante like", value, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteNotLike(String value) {
            addCriterion("t02cod_ante not like", value, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteIn(List<String> values) {
            addCriterion("t02cod_ante in", values, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteNotIn(List<String> values) {
            addCriterion("t02cod_ante not in", values, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteBetween(String value1, String value2) {
            addCriterion("t02cod_ante between", value1, value2, "t02codAnte");
            return this;
        }

        public Criteria andT02codAnteNotBetween(String value1, String value2) {
            addCriterion("t02cod_ante not between", value1, value2, "t02codAnte");
            return this;
        }

        public Criteria andT02indAduanaIsNull() {
            addCriterion("t02ind_aduana is null");
            return this;
        }

        public Criteria andT02indAduanaIsNotNull() {
            addCriterion("t02ind_aduana is not null");
            return this;
        }

        public Criteria andT02indAduanaEqualTo(String value) {
            addCriterion("t02ind_aduana =", value, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaNotEqualTo(String value) {
            addCriterion("t02ind_aduana <>", value, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaGreaterThan(String value) {
            addCriterion("t02ind_aduana >", value, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaGreaterThanOrEqualTo(String value) {
            addCriterion("t02ind_aduana >=", value, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaLessThan(String value) {
            addCriterion("t02ind_aduana <", value, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaLessThanOrEqualTo(String value) {
            addCriterion("t02ind_aduana <=", value, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaLike(String value) {
            addCriterion("t02ind_aduana like", value, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaNotLike(String value) {
            addCriterion("t02ind_aduana not like", value, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaIn(List<String> values) {
            addCriterion("t02ind_aduana in", values, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaNotIn(List<String> values) {
            addCriterion("t02ind_aduana not in", values, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaBetween(String value1, String value2) {
            addCriterion("t02ind_aduana between", value1, value2, "t02indAduana");
            return this;
        }

        public Criteria andT02indAduanaNotBetween(String value1, String value2) {
            addCriterion("t02ind_aduana not between", value1, value2, "t02indAduana");
            return this;
        }

        public Criteria andT02fIngApIsNull() {
            addCriterion("t02f_ing_ap is null");
            return this;
        }

        public Criteria andT02fIngApIsNotNull() {
            addCriterion("t02f_ing_ap is not null");
            return this;
        }

        public Criteria andT02fIngApEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ing_ap =", value, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApNotEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ing_ap <>", value, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApGreaterThan(Date value) {
            addCriterionForJDBCDate("t02f_ing_ap >", value, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ing_ap >=", value, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApLessThan(Date value) {
            addCriterionForJDBCDate("t02f_ing_ap <", value, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ing_ap <=", value, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_ing_ap in", values, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApNotIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_ing_ap not in", values, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_ing_ap between", value1, value2, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngApNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_ing_ap not between", value1, value2, "t02fIngAp");
            return this;
        }

        public Criteria andT02fIngDgIsNull() {
            addCriterion("t02f_ing_dg is null");
            return this;
        }

        public Criteria andT02fIngDgIsNotNull() {
            addCriterion("t02f_ing_dg is not null");
            return this;
        }

        public Criteria andT02fIngDgEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ing_dg =", value, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgNotEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ing_dg <>", value, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgGreaterThan(Date value) {
            addCriterionForJDBCDate("t02f_ing_dg >", value, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ing_dg >=", value, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgLessThan(Date value) {
            addCriterionForJDBCDate("t02f_ing_dg <", value, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_ing_dg <=", value, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_ing_dg in", values, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgNotIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_ing_dg not in", values, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_ing_dg between", value1, value2, "t02fIngDg");
            return this;
        }

        public Criteria andT02fIngDgNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_ing_dg not between", value1, value2, "t02fIngDg");
            return this;
        }

        public Criteria andT02fFallecIsNull() {
            addCriterion("t02f_fallec is null");
            return this;
        }

        public Criteria andT02fFallecIsNotNull() {
            addCriterion("t02f_fallec is not null");
            return this;
        }

        public Criteria andT02fFallecEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_fallec =", value, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecNotEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_fallec <>", value, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecGreaterThan(Date value) {
            addCriterionForJDBCDate("t02f_fallec >", value, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_fallec >=", value, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecLessThan(Date value) {
            addCriterionForJDBCDate("t02f_fallec <", value, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t02f_fallec <=", value, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_fallec in", values, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecNotIn(List<Date> values) {
            addCriterionForJDBCDate("t02f_fallec not in", values, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_fallec between", value1, value2, "t02fFallec");
            return this;
        }

        public Criteria andT02fFallecNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t02f_fallec not between", value1, value2, "t02fFallec");
            return this;
        }

        public Criteria andT02fGrabaIsNull() {
            addCriterion("t02f_graba is null");
            return this;
        }

        public Criteria andT02fGrabaIsNotNull() {
            addCriterion("t02f_graba is not null");
            return this;
        }

        public Criteria andT02fGrabaEqualTo(Date value) {
            addCriterion("t02f_graba =", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaNotEqualTo(Date value) {
            addCriterion("t02f_graba <>", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaGreaterThan(Date value) {
            addCriterion("t02f_graba >", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaGreaterThanOrEqualTo(Date value) {
            addCriterion("t02f_graba >=", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaLessThan(Date value) {
            addCriterion("t02f_graba <", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaLessThanOrEqualTo(Date value) {
            addCriterion("t02f_graba <=", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaIn(List<Date> values) {
            addCriterion("t02f_graba in", values, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaNotIn(List<Date> values) {
            addCriterion("t02f_graba not in", values, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaBetween(Date value1, Date value2) {
            addCriterion("t02f_graba between", value1, value2, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaNotBetween(Date value1, Date value2) {
            addCriterion("t02f_graba not between", value1, value2, "t02fGraba");
            return this;
        }

        public Criteria andT02codUserIsNull() {
            addCriterion("t02cod_user is null");
            return this;
        }

        public Criteria andT02codUserIsNotNull() {
            addCriterion("t02cod_user is not null");
            return this;
        }

        public Criteria andT02codUserEqualTo(String value) {
            addCriterion("t02cod_user =", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserNotEqualTo(String value) {
            addCriterion("t02cod_user <>", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserGreaterThan(String value) {
            addCriterion("t02cod_user >", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_user >=", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserLessThan(String value) {
            addCriterion("t02cod_user <", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserLessThanOrEqualTo(String value) {
            addCriterion("t02cod_user <=", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserLike(String value) {
            addCriterion("t02cod_user like", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserNotLike(String value) {
            addCriterion("t02cod_user not like", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserIn(List<String> values) {
            addCriterion("t02cod_user in", values, "t02codUser");
            return this;
        }

        public Criteria andT02codUserNotIn(List<String> values) {
            addCriterion("t02cod_user not in", values, "t02codUser");
            return this;
        }

        public Criteria andT02codUserBetween(String value1, String value2) {
            addCriterion("t02cod_user between", value1, value2, "t02codUser");
            return this;
        }

        public Criteria andT02codUserNotBetween(String value1, String value2) {
            addCriterion("t02cod_user not between", value1, value2, "t02codUser");
            return this;
        }
    }
}