package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SeguimientoExpedExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public SeguimientoExpedExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected SeguimientoExpedExample(SeguimientoExpedExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andNumIdExpedIsNull() {
            addCriterion("num_id_exped is null");
            return this;
        }

        public Criteria andNumIdExpedIsNotNull() {
            addCriterion("num_id_exped is not null");
            return this;
        }

        public Criteria andNumIdExpedEqualTo(Integer value) {
            addCriterion("num_id_exped =", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotEqualTo(Integer value) {
            addCriterion("num_id_exped <>", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedGreaterThan(Integer value) {
            addCriterion("num_id_exped >", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_id_exped >=", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedLessThan(Integer value) {
            addCriterion("num_id_exped <", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedLessThanOrEqualTo(Integer value) {
            addCriterion("num_id_exped <=", value, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedIn(List<Integer> values) {
            addCriterion("num_id_exped in", values, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotIn(List<Integer> values) {
            addCriterion("num_id_exped not in", values, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedBetween(Integer value1, Integer value2) {
            addCriterion("num_id_exped between", value1, value2, "numIdExped");
            return this;
        }

        public Criteria andNumIdExpedNotBetween(Integer value1, Integer value2) {
            addCriterion("num_id_exped not between", value1, value2, "numIdExped");
            return this;
        }

        public Criteria andNumSeguimIsNull() {
            addCriterion("num_seguim is null");
            return this;
        }

        public Criteria andNumSeguimIsNotNull() {
            addCriterion("num_seguim is not null");
            return this;
        }

        public Criteria andNumSeguimEqualTo(Integer value) {
            addCriterion("num_seguim =", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotEqualTo(Integer value) {
            addCriterion("num_seguim <>", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimGreaterThan(Integer value) {
            addCriterion("num_seguim >", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_seguim >=", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimLessThan(Integer value) {
            addCriterion("num_seguim <", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimLessThanOrEqualTo(Integer value) {
            addCriterion("num_seguim <=", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimIn(List<Integer> values) {
            addCriterion("num_seguim in", values, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotIn(List<Integer> values) {
            addCriterion("num_seguim not in", values, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimBetween(Integer value1, Integer value2) {
            addCriterion("num_seguim between", value1, value2, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotBetween(Integer value1, Integer value2) {
            addCriterion("num_seguim not between", value1, value2, "numSeguim");
            return this;
        }

        public Criteria andCodTipActorIsNull() {
            addCriterion("cod_tip_actor is null");
            return this;
        }

        public Criteria andCodTipActorIsNotNull() {
            addCriterion("cod_tip_actor is not null");
            return this;
        }

        public Criteria andCodTipActorEqualTo(String value) {
            addCriterion("cod_tip_actor =", value, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorNotEqualTo(String value) {
            addCriterion("cod_tip_actor <>", value, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorGreaterThan(String value) {
            addCriterion("cod_tip_actor >", value, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tip_actor >=", value, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorLessThan(String value) {
            addCriterion("cod_tip_actor <", value, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorLessThanOrEqualTo(String value) {
            addCriterion("cod_tip_actor <=", value, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorLike(String value) {
            addCriterion("cod_tip_actor like", value, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorNotLike(String value) {
            addCriterion("cod_tip_actor not like", value, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorIn(List<String> values) {
            addCriterion("cod_tip_actor in", values, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorNotIn(List<String> values) {
            addCriterion("cod_tip_actor not in", values, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorBetween(String value1, String value2) {
            addCriterion("cod_tip_actor between", value1, value2, "codTipActor");
            return this;
        }

        public Criteria andCodTipActorNotBetween(String value1, String value2) {
            addCriterion("cod_tip_actor not between", value1, value2, "codTipActor");
            return this;
        }

        public Criteria andCodPersOrigIsNull() {
            addCriterion("cod_pers_orig is null");
            return this;
        }

        public Criteria andCodPersOrigIsNotNull() {
            addCriterion("cod_pers_orig is not null");
            return this;
        }

        public Criteria andCodPersOrigEqualTo(String value) {
            addCriterion("cod_pers_orig =", value, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigNotEqualTo(String value) {
            addCriterion("cod_pers_orig <>", value, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigGreaterThan(String value) {
            addCriterion("cod_pers_orig >", value, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pers_orig >=", value, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigLessThan(String value) {
            addCriterion("cod_pers_orig <", value, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigLessThanOrEqualTo(String value) {
            addCriterion("cod_pers_orig <=", value, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigLike(String value) {
            addCriterion("cod_pers_orig like", value, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigNotLike(String value) {
            addCriterion("cod_pers_orig not like", value, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigIn(List<String> values) {
            addCriterion("cod_pers_orig in", values, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigNotIn(List<String> values) {
            addCriterion("cod_pers_orig not in", values, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigBetween(String value1, String value2) {
            addCriterion("cod_pers_orig between", value1, value2, "codPersOrig");
            return this;
        }

        public Criteria andCodPersOrigNotBetween(String value1, String value2) {
            addCriterion("cod_pers_orig not between", value1, value2, "codPersOrig");
            return this;
        }

        public Criteria andCodUnidOrigIsNull() {
            addCriterion("cod_unid_orig is null");
            return this;
        }

        public Criteria andCodUnidOrigIsNotNull() {
            addCriterion("cod_unid_orig is not null");
            return this;
        }

        public Criteria andCodUnidOrigEqualTo(String value) {
            addCriterion("cod_unid_orig =", value, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigNotEqualTo(String value) {
            addCriterion("cod_unid_orig <>", value, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigGreaterThan(String value) {
            addCriterion("cod_unid_orig >", value, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigGreaterThanOrEqualTo(String value) {
            addCriterion("cod_unid_orig >=", value, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigLessThan(String value) {
            addCriterion("cod_unid_orig <", value, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigLessThanOrEqualTo(String value) {
            addCriterion("cod_unid_orig <=", value, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigLike(String value) {
            addCriterion("cod_unid_orig like", value, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigNotLike(String value) {
            addCriterion("cod_unid_orig not like", value, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigIn(List<String> values) {
            addCriterion("cod_unid_orig in", values, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigNotIn(List<String> values) {
            addCriterion("cod_unid_orig not in", values, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigBetween(String value1, String value2) {
            addCriterion("cod_unid_orig between", value1, value2, "codUnidOrig");
            return this;
        }

        public Criteria andCodUnidOrigNotBetween(String value1, String value2) {
            addCriterion("cod_unid_orig not between", value1, value2, "codUnidOrig");
            return this;
        }

        public Criteria andCodPersDestIsNull() {
            addCriterion("cod_pers_dest is null");
            return this;
        }

        public Criteria andCodPersDestIsNotNull() {
            addCriterion("cod_pers_dest is not null");
            return this;
        }

        public Criteria andCodPersDestEqualTo(String value) {
            addCriterion("cod_pers_dest =", value, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestNotEqualTo(String value) {
            addCriterion("cod_pers_dest <>", value, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestGreaterThan(String value) {
            addCriterion("cod_pers_dest >", value, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pers_dest >=", value, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestLessThan(String value) {
            addCriterion("cod_pers_dest <", value, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestLessThanOrEqualTo(String value) {
            addCriterion("cod_pers_dest <=", value, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestLike(String value) {
            addCriterion("cod_pers_dest like", value, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestNotLike(String value) {
            addCriterion("cod_pers_dest not like", value, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestIn(List<String> values) {
            addCriterion("cod_pers_dest in", values, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestNotIn(List<String> values) {
            addCriterion("cod_pers_dest not in", values, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestBetween(String value1, String value2) {
            addCriterion("cod_pers_dest between", value1, value2, "codPersDest");
            return this;
        }

        public Criteria andCodPersDestNotBetween(String value1, String value2) {
            addCriterion("cod_pers_dest not between", value1, value2, "codPersDest");
            return this;
        }

        public Criteria andCodUnidDestIsNull() {
            addCriterion("cod_unid_dest is null");
            return this;
        }

        public Criteria andCodUnidDestIsNotNull() {
            addCriterion("cod_unid_dest is not null");
            return this;
        }

        public Criteria andCodUnidDestEqualTo(String value) {
            addCriterion("cod_unid_dest =", value, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestNotEqualTo(String value) {
            addCriterion("cod_unid_dest <>", value, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestGreaterThan(String value) {
            addCriterion("cod_unid_dest >", value, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestGreaterThanOrEqualTo(String value) {
            addCriterion("cod_unid_dest >=", value, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestLessThan(String value) {
            addCriterion("cod_unid_dest <", value, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestLessThanOrEqualTo(String value) {
            addCriterion("cod_unid_dest <=", value, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestLike(String value) {
            addCriterion("cod_unid_dest like", value, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestNotLike(String value) {
            addCriterion("cod_unid_dest not like", value, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestIn(List<String> values) {
            addCriterion("cod_unid_dest in", values, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestNotIn(List<String> values) {
            addCriterion("cod_unid_dest not in", values, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestBetween(String value1, String value2) {
            addCriterion("cod_unid_dest between", value1, value2, "codUnidDest");
            return this;
        }

        public Criteria andCodUnidDestNotBetween(String value1, String value2) {
            addCriterion("cod_unid_dest not between", value1, value2, "codUnidDest");
            return this;
        }

        public Criteria andCodAccionIsNull() {
            addCriterion("cod_accion is null");
            return this;
        }

        public Criteria andCodAccionIsNotNull() {
            addCriterion("cod_accion is not null");
            return this;
        }

        public Criteria andCodAccionEqualTo(String value) {
            addCriterion("cod_accion =", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionNotEqualTo(String value) {
            addCriterion("cod_accion <>", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionGreaterThan(String value) {
            addCriterion("cod_accion >", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionGreaterThanOrEqualTo(String value) {
            addCriterion("cod_accion >=", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionLessThan(String value) {
            addCriterion("cod_accion <", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionLessThanOrEqualTo(String value) {
            addCriterion("cod_accion <=", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionLike(String value) {
            addCriterion("cod_accion like", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionNotLike(String value) {
            addCriterion("cod_accion not like", value, "codAccion");
            return this;
        }

        public Criteria andCodAccionIn(List<String> values) {
            addCriterion("cod_accion in", values, "codAccion");
            return this;
        }

        public Criteria andCodAccionNotIn(List<String> values) {
            addCriterion("cod_accion not in", values, "codAccion");
            return this;
        }

        public Criteria andCodAccionBetween(String value1, String value2) {
            addCriterion("cod_accion between", value1, value2, "codAccion");
            return this;
        }

        public Criteria andCodAccionNotBetween(String value1, String value2) {
            addCriterion("cod_accion not between", value1, value2, "codAccion");
            return this;
        }

        public Criteria andCodEstadoIsNull() {
            addCriterion("cod_estado is null");
            return this;
        }

        public Criteria andCodEstadoIsNotNull() {
            addCriterion("cod_estado is not null");
            return this;
        }

        public Criteria andCodEstadoEqualTo(String value) {
            addCriterion("cod_estado =", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotEqualTo(String value) {
            addCriterion("cod_estado <>", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThan(String value) {
            addCriterion("cod_estado >", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estado >=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThan(String value) {
            addCriterion("cod_estado <", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThanOrEqualTo(String value) {
            addCriterion("cod_estado <=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLike(String value) {
            addCriterion("cod_estado like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotLike(String value) {
            addCriterion("cod_estado not like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoIn(List<String> values) {
            addCriterion("cod_estado in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotIn(List<String> values) {
            addCriterion("cod_estado not in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoBetween(String value1, String value2) {
            addCriterion("cod_estado between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotBetween(String value1, String value2) {
            addCriterion("cod_estado not between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andIndUltSeguimIsNull() {
            addCriterion("ind_ult_seguim is null");
            return this;
        }

        public Criteria andIndUltSeguimIsNotNull() {
            addCriterion("ind_ult_seguim is not null");
            return this;
        }

        public Criteria andIndUltSeguimEqualTo(String value) {
            addCriterion("ind_ult_seguim =", value, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimNotEqualTo(String value) {
            addCriterion("ind_ult_seguim <>", value, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimGreaterThan(String value) {
            addCriterion("ind_ult_seguim >", value, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimGreaterThanOrEqualTo(String value) {
            addCriterion("ind_ult_seguim >=", value, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimLessThan(String value) {
            addCriterion("ind_ult_seguim <", value, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimLessThanOrEqualTo(String value) {
            addCriterion("ind_ult_seguim <=", value, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimLike(String value) {
            addCriterion("ind_ult_seguim like", value, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimNotLike(String value) {
            addCriterion("ind_ult_seguim not like", value, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimIn(List<String> values) {
            addCriterion("ind_ult_seguim in", values, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimNotIn(List<String> values) {
            addCriterion("ind_ult_seguim not in", values, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimBetween(String value1, String value2) {
            addCriterion("ind_ult_seguim between", value1, value2, "indUltSeguim");
            return this;
        }

        public Criteria andIndUltSeguimNotBetween(String value1, String value2) {
            addCriterion("ind_ult_seguim not between", value1, value2, "indUltSeguim");
            return this;
        }

        public Criteria andDesObservIsNull() {
            addCriterion("des_observ is null");
            return this;
        }

        public Criteria andDesObservIsNotNull() {
            addCriterion("des_observ is not null");
            return this;
        }

        public Criteria andDesObservEqualTo(String value) {
            addCriterion("des_observ =", value, "desObserv");
            return this;
        }

        public Criteria andDesObservNotEqualTo(String value) {
            addCriterion("des_observ <>", value, "desObserv");
            return this;
        }

        public Criteria andDesObservGreaterThan(String value) {
            addCriterion("des_observ >", value, "desObserv");
            return this;
        }

        public Criteria andDesObservGreaterThanOrEqualTo(String value) {
            addCriterion("des_observ >=", value, "desObserv");
            return this;
        }

        public Criteria andDesObservLessThan(String value) {
            addCriterion("des_observ <", value, "desObserv");
            return this;
        }

        public Criteria andDesObservLessThanOrEqualTo(String value) {
            addCriterion("des_observ <=", value, "desObserv");
            return this;
        }

        public Criteria andDesObservLike(String value) {
            addCriterion("des_observ like", value, "desObserv");
            return this;
        }

        public Criteria andDesObservNotLike(String value) {
            addCriterion("des_observ not like", value, "desObserv");
            return this;
        }

        public Criteria andDesObservIn(List<String> values) {
            addCriterion("des_observ in", values, "desObserv");
            return this;
        }

        public Criteria andDesObservNotIn(List<String> values) {
            addCriterion("des_observ not in", values, "desObserv");
            return this;
        }

        public Criteria andDesObservBetween(String value1, String value2) {
            addCriterion("des_observ between", value1, value2, "desObserv");
            return this;
        }

        public Criteria andDesObservNotBetween(String value1, String value2) {
            addCriterion("des_observ not between", value1, value2, "desObserv");
            return this;
        }

        public Criteria andNumArcSeguimIsNull() {
            addCriterion("num_arc_seguim is null");
            return this;
        }

        public Criteria andNumArcSeguimIsNotNull() {
            addCriterion("num_arc_seguim is not null");
            return this;
        }

        public Criteria andNumArcSeguimEqualTo(Integer value) {
            addCriterion("num_arc_seguim =", value, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimNotEqualTo(Integer value) {
            addCriterion("num_arc_seguim <>", value, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimGreaterThan(Integer value) {
            addCriterion("num_arc_seguim >", value, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_arc_seguim >=", value, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimLessThan(Integer value) {
            addCriterion("num_arc_seguim <", value, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimLessThanOrEqualTo(Integer value) {
            addCriterion("num_arc_seguim <=", value, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimIn(List<Integer> values) {
            addCriterion("num_arc_seguim in", values, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimNotIn(List<Integer> values) {
            addCriterion("num_arc_seguim not in", values, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimBetween(Integer value1, Integer value2) {
            addCriterion("num_arc_seguim between", value1, value2, "numArcSeguim");
            return this;
        }

        public Criteria andNumArcSeguimNotBetween(Integer value1, Integer value2) {
            addCriterion("num_arc_seguim not between", value1, value2, "numArcSeguim");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }

        public Criteria andCodUsuregisIsNull() {
            addCriterion("cod_usuregis is null");
            return this;
        }

        public Criteria andCodUsuregisIsNotNull() {
            addCriterion("cod_usuregis is not null");
            return this;
        }

        public Criteria andCodUsuregisEqualTo(String value) {
            addCriterion("cod_usuregis =", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotEqualTo(String value) {
            addCriterion("cod_usuregis <>", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThan(String value) {
            addCriterion("cod_usuregis >", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuregis >=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThan(String value) {
            addCriterion("cod_usuregis <", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThanOrEqualTo(String value) {
            addCriterion("cod_usuregis <=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLike(String value) {
            addCriterion("cod_usuregis like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotLike(String value) {
            addCriterion("cod_usuregis not like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisIn(List<String> values) {
            addCriterion("cod_usuregis in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotIn(List<String> values) {
            addCriterion("cod_usuregis not in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisBetween(String value1, String value2) {
            addCriterion("cod_usuregis between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotBetween(String value1, String value2) {
            addCriterion("cod_usuregis not between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andFecRegisIsNull() {
            addCriterion("fec_regis is null");
            return this;
        }

        public Criteria andFecRegisIsNotNull() {
            addCriterion("fec_regis is not null");
            return this;
        }

        public Criteria andFecRegisEqualTo(Date value) {
            addCriterion("fec_regis =", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotEqualTo(Date value) {
            addCriterion("fec_regis <>", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThan(Date value) {
            addCriterion("fec_regis >", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_regis >=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThan(Date value) {
            addCriterion("fec_regis <", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThanOrEqualTo(Date value) {
            addCriterion("fec_regis <=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisIn(List<Date> values) {
            addCriterion("fec_regis in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotIn(List<Date> values) {
            addCriterion("fec_regis not in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisBetween(Date value1, Date value2) {
            addCriterion("fec_regis between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotBetween(Date value1, Date value2) {
            addCriterion("fec_regis not between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }
    }
}