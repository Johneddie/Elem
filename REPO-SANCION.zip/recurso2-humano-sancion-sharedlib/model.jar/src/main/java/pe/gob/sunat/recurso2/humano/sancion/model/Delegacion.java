package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.Date;

public class Delegacion extends DelegacionKey {
    private String codPersonalDeleg;

    private Date finivig;

    private Date ffinvig;

    private String sestadoActivo;

    private String cuserMod;

    private Date fmod;

    public String getCodPersonalDeleg() {
        return codPersonalDeleg;
    }

    public void setCodPersonalDeleg(String codPersonalDeleg) {
        this.codPersonalDeleg = codPersonalDeleg == null ? null : codPersonalDeleg.trim();
    }

    public Date getFinivig() {
        return finivig;
    }

    public void setFinivig(Date finivig) {
        this.finivig = finivig;
    }

    public Date getFfinvig() {
        return ffinvig;
    }

    public void setFfinvig(Date ffinvig) {
        this.ffinvig = ffinvig;
    }

    public String getSestadoActivo() {
        return sestadoActivo;
    }

    public void setSestadoActivo(String sestadoActivo) {
        this.sestadoActivo = sestadoActivo == null ? null : sestadoActivo.trim();
    }

    public String getCuserMod() {
        return cuserMod;
    }

    public void setCuserMod(String cuserMod) {
        this.cuserMod = cuserMod == null ? null : cuserMod.trim();
    }

    public Date getFmod() {
        return fmod;
    }

    public void setFmod(Date fmod) {
        this.fmod = fmod;
    }
}