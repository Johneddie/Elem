package pe.gob.sunat.recurso2.humano.sancion.model;

public class Correo {
    private String codPers;

    private String smtp;

    private String alias;

    public String getCodPers() {
        return codPers;
    }

    public void setCodPers(String codPers) {
        this.codPers = codPers == null ? null : codPers.trim();
    }

    public String getSmtp() {
        return smtp;
    }

    public void setSmtp(String smtp) {
        this.smtp = smtp == null ? null : smtp.trim();
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias == null ? null : alias.trim();
    }
}