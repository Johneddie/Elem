package pe.gob.sunat.recurso2.humano.sancion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class UnidadOrgExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public UnidadOrgExample() {
        oredCriteria = new ArrayList<>();
    }

    protected UnidadOrgExample(UnidadOrgExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andT12codUorgaIsNull() {
            addCriterion("t12cod_uorga is null");
            return this;
        }

        public Criteria andT12codUorgaIsNotNull() {
            addCriterion("t12cod_uorga is not null");
            return this;
        }

        public Criteria andT12codUorgaEqualTo(String value) {
            addCriterion("t12cod_uorga =", value, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaNotEqualTo(String value) {
            addCriterion("t12cod_uorga <>", value, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaGreaterThan(String value) {
            addCriterion("t12cod_uorga >", value, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_uorga >=", value, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaLessThan(String value) {
            addCriterion("t12cod_uorga <", value, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaLessThanOrEqualTo(String value) {
            addCriterion("t12cod_uorga <=", value, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaLike(String value) {
            addCriterion("t12cod_uorga like", value, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaNotLike(String value) {
            addCriterion("t12cod_uorga not like", value, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaIn(List<String> values) {
            addCriterion("t12cod_uorga in", values, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaNotIn(List<String> values) {
            addCriterion("t12cod_uorga not in", values, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaBetween(String value1, String value2) {
            addCriterion("t12cod_uorga between", value1, value2, "t12codUorga");
            return this;
        }

        public Criteria andT12codUorgaNotBetween(String value1, String value2) {
            addCriterion("t12cod_uorga not between", value1, value2, "t12codUorga");
            return this;
        }

        public Criteria andT12desUorgaIsNull() {
            addCriterion("t12des_uorga is null");
            return this;
        }

        public Criteria andT12desUorgaIsNotNull() {
            addCriterion("t12des_uorga is not null");
            return this;
        }

        public Criteria andT12desUorgaEqualTo(String value) {
            addCriterion("t12des_uorga =", value, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaNotEqualTo(String value) {
            addCriterion("t12des_uorga <>", value, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaGreaterThan(String value) {
            addCriterion("t12des_uorga >", value, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaGreaterThanOrEqualTo(String value) {
            addCriterion("t12des_uorga >=", value, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaLessThan(String value) {
            addCriterion("t12des_uorga <", value, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaLessThanOrEqualTo(String value) {
            addCriterion("t12des_uorga <=", value, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaLike(String value) {
            addCriterion("t12des_uorga like", value, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaNotLike(String value) {
            addCriterion("t12des_uorga not like", value, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaIn(List<String> values) {
            addCriterion("t12des_uorga in", values, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaNotIn(List<String> values) {
            addCriterion("t12des_uorga not in", values, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaBetween(String value1, String value2) {
            addCriterion("t12des_uorga between", value1, value2, "t12desUorga");
            return this;
        }

        public Criteria andT12desUorgaNotBetween(String value1, String value2) {
            addCriterion("t12des_uorga not between", value1, value2, "t12desUorga");
            return this;
        }

        public Criteria andT12desCortaIsNull() {
            addCriterion("t12des_corta is null");
            return this;
        }

        public Criteria andT12desCortaIsNotNull() {
            addCriterion("t12des_corta is not null");
            return this;
        }

        public Criteria andT12desCortaEqualTo(String value) {
            addCriterion("t12des_corta =", value, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaNotEqualTo(String value) {
            addCriterion("t12des_corta <>", value, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaGreaterThan(String value) {
            addCriterion("t12des_corta >", value, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaGreaterThanOrEqualTo(String value) {
            addCriterion("t12des_corta >=", value, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaLessThan(String value) {
            addCriterion("t12des_corta <", value, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaLessThanOrEqualTo(String value) {
            addCriterion("t12des_corta <=", value, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaLike(String value) {
            addCriterion("t12des_corta like", value, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaNotLike(String value) {
            addCriterion("t12des_corta not like", value, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaIn(List<String> values) {
            addCriterion("t12des_corta in", values, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaNotIn(List<String> values) {
            addCriterion("t12des_corta not in", values, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaBetween(String value1, String value2) {
            addCriterion("t12des_corta between", value1, value2, "t12desCorta");
            return this;
        }

        public Criteria andT12desCortaNotBetween(String value1, String value2) {
            addCriterion("t12des_corta not between", value1, value2, "t12desCorta");
            return this;
        }

        public Criteria andT12fVigenciIsNull() {
            addCriterion("t12f_vigenci is null");
            return this;
        }

        public Criteria andT12fVigenciIsNotNull() {
            addCriterion("t12f_vigenci is not null");
            return this;
        }

        public Criteria andT12fVigenciEqualTo(Date value) {
            addCriterionForJDBCDate("t12f_vigenci =", value, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciNotEqualTo(Date value) {
            addCriterionForJDBCDate("t12f_vigenci <>", value, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciGreaterThan(Date value) {
            addCriterionForJDBCDate("t12f_vigenci >", value, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t12f_vigenci >=", value, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciLessThan(Date value) {
            addCriterionForJDBCDate("t12f_vigenci <", value, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t12f_vigenci <=", value, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciIn(List<Date> values) {
            addCriterionForJDBCDate("t12f_vigenci in", values, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciNotIn(List<Date> values) {
            addCriterionForJDBCDate("t12f_vigenci not in", values, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t12f_vigenci between", value1, value2, "t12fVigenci");
            return this;
        }

        public Criteria andT12fVigenciNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t12f_vigenci not between", value1, value2, "t12fVigenci");
            return this;
        }

        public Criteria andT12fBajaIsNull() {
            addCriterion("t12f_baja is null");
            return this;
        }

        public Criteria andT12fBajaIsNotNull() {
            addCriterion("t12f_baja is not null");
            return this;
        }

        public Criteria andT12fBajaEqualTo(Date value) {
            addCriterionForJDBCDate("t12f_baja =", value, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaNotEqualTo(Date value) {
            addCriterionForJDBCDate("t12f_baja <>", value, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaGreaterThan(Date value) {
            addCriterionForJDBCDate("t12f_baja >", value, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t12f_baja >=", value, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaLessThan(Date value) {
            addCriterionForJDBCDate("t12f_baja <", value, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t12f_baja <=", value, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaIn(List<Date> values) {
            addCriterionForJDBCDate("t12f_baja in", values, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaNotIn(List<Date> values) {
            addCriterionForJDBCDate("t12f_baja not in", values, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t12f_baja between", value1, value2, "t12fBaja");
            return this;
        }

        public Criteria andT12fBajaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t12f_baja not between", value1, value2, "t12fBaja");
            return this;
        }

        public Criteria andT12codNivelIsNull() {
            addCriterion("t12cod_nivel is null");
            return this;
        }

        public Criteria andT12codNivelIsNotNull() {
            addCriterion("t12cod_nivel is not null");
            return this;
        }

        public Criteria andT12codNivelEqualTo(String value) {
            addCriterion("t12cod_nivel =", value, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelNotEqualTo(String value) {
            addCriterion("t12cod_nivel <>", value, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelGreaterThan(String value) {
            addCriterion("t12cod_nivel >", value, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_nivel >=", value, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelLessThan(String value) {
            addCriterion("t12cod_nivel <", value, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelLessThanOrEqualTo(String value) {
            addCriterion("t12cod_nivel <=", value, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelLike(String value) {
            addCriterion("t12cod_nivel like", value, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelNotLike(String value) {
            addCriterion("t12cod_nivel not like", value, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelIn(List<String> values) {
            addCriterion("t12cod_nivel in", values, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelNotIn(List<String> values) {
            addCriterion("t12cod_nivel not in", values, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelBetween(String value1, String value2) {
            addCriterion("t12cod_nivel between", value1, value2, "t12codNivel");
            return this;
        }

        public Criteria andT12codNivelNotBetween(String value1, String value2) {
            addCriterion("t12cod_nivel not between", value1, value2, "t12codNivel");
            return this;
        }

        public Criteria andT12codCategIsNull() {
            addCriterion("t12cod_categ is null");
            return this;
        }

        public Criteria andT12codCategIsNotNull() {
            addCriterion("t12cod_categ is not null");
            return this;
        }

        public Criteria andT12codCategEqualTo(String value) {
            addCriterion("t12cod_categ =", value, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategNotEqualTo(String value) {
            addCriterion("t12cod_categ <>", value, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategGreaterThan(String value) {
            addCriterion("t12cod_categ >", value, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_categ >=", value, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategLessThan(String value) {
            addCriterion("t12cod_categ <", value, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategLessThanOrEqualTo(String value) {
            addCriterion("t12cod_categ <=", value, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategLike(String value) {
            addCriterion("t12cod_categ like", value, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategNotLike(String value) {
            addCriterion("t12cod_categ not like", value, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategIn(List<String> values) {
            addCriterion("t12cod_categ in", values, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategNotIn(List<String> values) {
            addCriterion("t12cod_categ not in", values, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategBetween(String value1, String value2) {
            addCriterion("t12cod_categ between", value1, value2, "t12codCateg");
            return this;
        }

        public Criteria andT12codCategNotBetween(String value1, String value2) {
            addCriterion("t12cod_categ not between", value1, value2, "t12codCateg");
            return this;
        }

        public Criteria andT12codSubprIsNull() {
            addCriterion("t12cod_subpr is null");
            return this;
        }

        public Criteria andT12codSubprIsNotNull() {
            addCriterion("t12cod_subpr is not null");
            return this;
        }

        public Criteria andT12codSubprEqualTo(String value) {
            addCriterion("t12cod_subpr =", value, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprNotEqualTo(String value) {
            addCriterion("t12cod_subpr <>", value, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprGreaterThan(String value) {
            addCriterion("t12cod_subpr >", value, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_subpr >=", value, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprLessThan(String value) {
            addCriterion("t12cod_subpr <", value, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprLessThanOrEqualTo(String value) {
            addCriterion("t12cod_subpr <=", value, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprLike(String value) {
            addCriterion("t12cod_subpr like", value, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprNotLike(String value) {
            addCriterion("t12cod_subpr not like", value, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprIn(List<String> values) {
            addCriterion("t12cod_subpr in", values, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprNotIn(List<String> values) {
            addCriterion("t12cod_subpr not in", values, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprBetween(String value1, String value2) {
            addCriterion("t12cod_subpr between", value1, value2, "t12codSubpr");
            return this;
        }

        public Criteria andT12codSubprNotBetween(String value1, String value2) {
            addCriterion("t12cod_subpr not between", value1, value2, "t12codSubpr");
            return this;
        }

        public Criteria andT12indAplicIsNull() {
            addCriterion("t12ind_aplic is null");
            return this;
        }

        public Criteria andT12indAplicIsNotNull() {
            addCriterion("t12ind_aplic is not null");
            return this;
        }

        public Criteria andT12indAplicEqualTo(String value) {
            addCriterion("t12ind_aplic =", value, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicNotEqualTo(String value) {
            addCriterion("t12ind_aplic <>", value, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicGreaterThan(String value) {
            addCriterion("t12ind_aplic >", value, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicGreaterThanOrEqualTo(String value) {
            addCriterion("t12ind_aplic >=", value, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicLessThan(String value) {
            addCriterion("t12ind_aplic <", value, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicLessThanOrEqualTo(String value) {
            addCriterion("t12ind_aplic <=", value, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicLike(String value) {
            addCriterion("t12ind_aplic like", value, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicNotLike(String value) {
            addCriterion("t12ind_aplic not like", value, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicIn(List<String> values) {
            addCriterion("t12ind_aplic in", values, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicNotIn(List<String> values) {
            addCriterion("t12ind_aplic not in", values, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicBetween(String value1, String value2) {
            addCriterion("t12ind_aplic between", value1, value2, "t12indAplic");
            return this;
        }

        public Criteria andT12indAplicNotBetween(String value1, String value2) {
            addCriterion("t12ind_aplic not between", value1, value2, "t12indAplic");
            return this;
        }

        public Criteria andT12codAnterIsNull() {
            addCriterion("t12cod_anter is null");
            return this;
        }

        public Criteria andT12codAnterIsNotNull() {
            addCriterion("t12cod_anter is not null");
            return this;
        }

        public Criteria andT12codAnterEqualTo(String value) {
            addCriterion("t12cod_anter =", value, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterNotEqualTo(String value) {
            addCriterion("t12cod_anter <>", value, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterGreaterThan(String value) {
            addCriterion("t12cod_anter >", value, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_anter >=", value, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterLessThan(String value) {
            addCriterion("t12cod_anter <", value, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterLessThanOrEqualTo(String value) {
            addCriterion("t12cod_anter <=", value, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterLike(String value) {
            addCriterion("t12cod_anter like", value, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterNotLike(String value) {
            addCriterion("t12cod_anter not like", value, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterIn(List<String> values) {
            addCriterion("t12cod_anter in", values, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterNotIn(List<String> values) {
            addCriterion("t12cod_anter not in", values, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterBetween(String value1, String value2) {
            addCriterion("t12cod_anter between", value1, value2, "t12codAnter");
            return this;
        }

        public Criteria andT12codAnterNotBetween(String value1, String value2) {
            addCriterion("t12cod_anter not between", value1, value2, "t12codAnter");
            return this;
        }

        public Criteria andT12indEstadIsNull() {
            addCriterion("t12ind_estad is null");
            return this;
        }

        public Criteria andT12indEstadIsNotNull() {
            addCriterion("t12ind_estad is not null");
            return this;
        }

        public Criteria andT12indEstadEqualTo(String value) {
            addCriterion("t12ind_estad =", value, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadNotEqualTo(String value) {
            addCriterion("t12ind_estad <>", value, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadGreaterThan(String value) {
            addCriterion("t12ind_estad >", value, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadGreaterThanOrEqualTo(String value) {
            addCriterion("t12ind_estad >=", value, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadLessThan(String value) {
            addCriterion("t12ind_estad <", value, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadLessThanOrEqualTo(String value) {
            addCriterion("t12ind_estad <=", value, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadLike(String value) {
            addCriterion("t12ind_estad like", value, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadNotLike(String value) {
            addCriterion("t12ind_estad not like", value, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadIn(List<String> values) {
            addCriterion("t12ind_estad in", values, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadNotIn(List<String> values) {
            addCriterion("t12ind_estad not in", values, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadBetween(String value1, String value2) {
            addCriterion("t12ind_estad between", value1, value2, "t12indEstad");
            return this;
        }

        public Criteria andT12indEstadNotBetween(String value1, String value2) {
            addCriterion("t12ind_estad not between", value1, value2, "t12indEstad");
            return this;
        }

        public Criteria andT12codJefatIsNull() {
            addCriterion("t12cod_jefat is null");
            return this;
        }

        public Criteria andT12codJefatIsNotNull() {
            addCriterion("t12cod_jefat is not null");
            return this;
        }

        public Criteria andT12codJefatEqualTo(String value) {
            addCriterion("t12cod_jefat =", value, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatNotEqualTo(String value) {
            addCriterion("t12cod_jefat <>", value, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatGreaterThan(String value) {
            addCriterion("t12cod_jefat >", value, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_jefat >=", value, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatLessThan(String value) {
            addCriterion("t12cod_jefat <", value, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatLessThanOrEqualTo(String value) {
            addCriterion("t12cod_jefat <=", value, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatLike(String value) {
            addCriterion("t12cod_jefat like", value, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatNotLike(String value) {
            addCriterion("t12cod_jefat not like", value, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatIn(List<String> values) {
            addCriterion("t12cod_jefat in", values, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatNotIn(List<String> values) {
            addCriterion("t12cod_jefat not in", values, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatBetween(String value1, String value2) {
            addCriterion("t12cod_jefat between", value1, value2, "t12codJefat");
            return this;
        }

        public Criteria andT12codJefatNotBetween(String value1, String value2) {
            addCriterion("t12cod_jefat not between", value1, value2, "t12codJefat");
            return this;
        }

        public Criteria andT12codEncarIsNull() {
            addCriterion("t12cod_encar is null");
            return this;
        }

        public Criteria andT12codEncarIsNotNull() {
            addCriterion("t12cod_encar is not null");
            return this;
        }

        public Criteria andT12codEncarEqualTo(String value) {
            addCriterion("t12cod_encar =", value, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarNotEqualTo(String value) {
            addCriterion("t12cod_encar <>", value, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarGreaterThan(String value) {
            addCriterion("t12cod_encar >", value, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_encar >=", value, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarLessThan(String value) {
            addCriterion("t12cod_encar <", value, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarLessThanOrEqualTo(String value) {
            addCriterion("t12cod_encar <=", value, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarLike(String value) {
            addCriterion("t12cod_encar like", value, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarNotLike(String value) {
            addCriterion("t12cod_encar not like", value, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarIn(List<String> values) {
            addCriterion("t12cod_encar in", values, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarNotIn(List<String> values) {
            addCriterion("t12cod_encar not in", values, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarBetween(String value1, String value2) {
            addCriterion("t12cod_encar between", value1, value2, "t12codEncar");
            return this;
        }

        public Criteria andT12codEncarNotBetween(String value1, String value2) {
            addCriterion("t12cod_encar not between", value1, value2, "t12codEncar");
            return this;
        }

        public Criteria andT12codReporIsNull() {
            addCriterion("t12cod_repor is null");
            return this;
        }

        public Criteria andT12codReporIsNotNull() {
            addCriterion("t12cod_repor is not null");
            return this;
        }

        public Criteria andT12codReporEqualTo(String value) {
            addCriterion("t12cod_repor =", value, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporNotEqualTo(String value) {
            addCriterion("t12cod_repor <>", value, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporGreaterThan(String value) {
            addCriterion("t12cod_repor >", value, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_repor >=", value, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporLessThan(String value) {
            addCriterion("t12cod_repor <", value, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporLessThanOrEqualTo(String value) {
            addCriterion("t12cod_repor <=", value, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporLike(String value) {
            addCriterion("t12cod_repor like", value, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporNotLike(String value) {
            addCriterion("t12cod_repor not like", value, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporIn(List<String> values) {
            addCriterion("t12cod_repor in", values, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporNotIn(List<String> values) {
            addCriterion("t12cod_repor not in", values, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporBetween(String value1, String value2) {
            addCriterion("t12cod_repor between", value1, value2, "t12codRepor");
            return this;
        }

        public Criteria andT12codReporNotBetween(String value1, String value2) {
            addCriterion("t12cod_repor not between", value1, value2, "t12codRepor");
            return this;
        }

        public Criteria andT12tipoIsNull() {
            addCriterion("t12tipo is null");
            return this;
        }

        public Criteria andT12tipoIsNotNull() {
            addCriterion("t12tipo is not null");
            return this;
        }

        public Criteria andT12tipoEqualTo(String value) {
            addCriterion("t12tipo =", value, "t12tipo");
            return this;
        }

        public Criteria andT12tipoNotEqualTo(String value) {
            addCriterion("t12tipo <>", value, "t12tipo");
            return this;
        }

        public Criteria andT12tipoGreaterThan(String value) {
            addCriterion("t12tipo >", value, "t12tipo");
            return this;
        }

        public Criteria andT12tipoGreaterThanOrEqualTo(String value) {
            addCriterion("t12tipo >=", value, "t12tipo");
            return this;
        }

        public Criteria andT12tipoLessThan(String value) {
            addCriterion("t12tipo <", value, "t12tipo");
            return this;
        }

        public Criteria andT12tipoLessThanOrEqualTo(String value) {
            addCriterion("t12tipo <=", value, "t12tipo");
            return this;
        }

        public Criteria andT12tipoLike(String value) {
            addCriterion("t12tipo like", value, "t12tipo");
            return this;
        }

        public Criteria andT12tipoNotLike(String value) {
            addCriterion("t12tipo not like", value, "t12tipo");
            return this;
        }

        public Criteria andT12tipoIn(List<String> values) {
            addCriterion("t12tipo in", values, "t12tipo");
            return this;
        }

        public Criteria andT12tipoNotIn(List<String> values) {
            addCriterion("t12tipo not in", values, "t12tipo");
            return this;
        }

        public Criteria andT12tipoBetween(String value1, String value2) {
            addCriterion("t12tipo between", value1, value2, "t12tipo");
            return this;
        }

        public Criteria andT12tipoNotBetween(String value1, String value2) {
            addCriterion("t12tipo not between", value1, value2, "t12tipo");
            return this;
        }

        public Criteria andT12fGrabaIsNull() {
            addCriterion("t12f_graba is null");
            return this;
        }

        public Criteria andT12fGrabaIsNotNull() {
            addCriterion("t12f_graba is not null");
            return this;
        }

        public Criteria andT12fGrabaEqualTo(Date value) {
            addCriterion("t12f_graba =", value, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaNotEqualTo(Date value) {
            addCriterion("t12f_graba <>", value, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaGreaterThan(Date value) {
            addCriterion("t12f_graba >", value, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaGreaterThanOrEqualTo(Date value) {
            addCriterion("t12f_graba >=", value, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaLessThan(Date value) {
            addCriterion("t12f_graba <", value, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaLessThanOrEqualTo(Date value) {
            addCriterion("t12f_graba <=", value, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaIn(List<Date> values) {
            addCriterion("t12f_graba in", values, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaNotIn(List<Date> values) {
            addCriterion("t12f_graba not in", values, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaBetween(Date value1, Date value2) {
            addCriterion("t12f_graba between", value1, value2, "t12fGraba");
            return this;
        }

        public Criteria andT12fGrabaNotBetween(Date value1, Date value2) {
            addCriterion("t12f_graba not between", value1, value2, "t12fGraba");
            return this;
        }

        public Criteria andT12codUserIsNull() {
            addCriterion("t12cod_user is null");
            return this;
        }

        public Criteria andT12codUserIsNotNull() {
            addCriterion("t12cod_user is not null");
            return this;
        }

        public Criteria andT12codUserEqualTo(String value) {
            addCriterion("t12cod_user =", value, "t12codUser");
            return this;
        }

        public Criteria andT12codUserNotEqualTo(String value) {
            addCriterion("t12cod_user <>", value, "t12codUser");
            return this;
        }

        public Criteria andT12codUserGreaterThan(String value) {
            addCriterion("t12cod_user >", value, "t12codUser");
            return this;
        }

        public Criteria andT12codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t12cod_user >=", value, "t12codUser");
            return this;
        }

        public Criteria andT12codUserLessThan(String value) {
            addCriterion("t12cod_user <", value, "t12codUser");
            return this;
        }

        public Criteria andT12codUserLessThanOrEqualTo(String value) {
            addCriterion("t12cod_user <=", value, "t12codUser");
            return this;
        }

        public Criteria andT12codUserLike(String value) {
            addCriterion("t12cod_user like", value, "t12codUser");
            return this;
        }

        public Criteria andT12codUserNotLike(String value) {
            addCriterion("t12cod_user not like", value, "t12codUser");
            return this;
        }

        public Criteria andT12codUserIn(List<String> values) {
            addCriterion("t12cod_user in", values, "t12codUser");
            return this;
        }

        public Criteria andT12codUserNotIn(List<String> values) {
            addCriterion("t12cod_user not in", values, "t12codUser");
            return this;
        }

        public Criteria andT12codUserBetween(String value1, String value2) {
            addCriterion("t12cod_user between", value1, value2, "t12codUser");
            return this;
        }

        public Criteria andT12codUserNotBetween(String value1, String value2) {
            addCriterion("t12cod_user not between", value1, value2, "t12codUser");
            return this;
        }

        public Criteria andT12indLimaIsNull() {
            addCriterion("t12ind_lima is null");
            return this;
        }

        public Criteria andT12indLimaIsNotNull() {
            addCriterion("t12ind_lima is not null");
            return this;
        }

        public Criteria andT12indLimaEqualTo(String value) {
            addCriterion("t12ind_lima =", value, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaNotEqualTo(String value) {
            addCriterion("t12ind_lima <>", value, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaGreaterThan(String value) {
            addCriterion("t12ind_lima >", value, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaGreaterThanOrEqualTo(String value) {
            addCriterion("t12ind_lima >=", value, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaLessThan(String value) {
            addCriterion("t12ind_lima <", value, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaLessThanOrEqualTo(String value) {
            addCriterion("t12ind_lima <=", value, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaLike(String value) {
            addCriterion("t12ind_lima like", value, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaNotLike(String value) {
            addCriterion("t12ind_lima not like", value, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaIn(List<String> values) {
            addCriterion("t12ind_lima in", values, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaNotIn(List<String> values) {
            addCriterion("t12ind_lima not in", values, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaBetween(String value1, String value2) {
            addCriterion("t12ind_lima between", value1, value2, "t12indLima");
            return this;
        }

        public Criteria andT12indLimaNotBetween(String value1, String value2) {
            addCriterion("t12ind_lima not between", value1, value2, "t12indLima");
            return this;
        }

        public Criteria andCodDptoIsNull() {
            addCriterion("cod_dpto is null");
            return this;
        }

        public Criteria andCodDptoIsNotNull() {
            addCriterion("cod_dpto is not null");
            return this;
        }

        public Criteria andCodDptoEqualTo(String value) {
            addCriterion("cod_dpto =", value, "codDpto");
            return this;
        }

        public Criteria andCodDptoNotEqualTo(String value) {
            addCriterion("cod_dpto <>", value, "codDpto");
            return this;
        }

        public Criteria andCodDptoGreaterThan(String value) {
            addCriterion("cod_dpto >", value, "codDpto");
            return this;
        }

        public Criteria andCodDptoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_dpto >=", value, "codDpto");
            return this;
        }

        public Criteria andCodDptoLessThan(String value) {
            addCriterion("cod_dpto <", value, "codDpto");
            return this;
        }

        public Criteria andCodDptoLessThanOrEqualTo(String value) {
            addCriterion("cod_dpto <=", value, "codDpto");
            return this;
        }

        public Criteria andCodDptoLike(String value) {
            addCriterion("cod_dpto like", value, "codDpto");
            return this;
        }

        public Criteria andCodDptoNotLike(String value) {
            addCriterion("cod_dpto not like", value, "codDpto");
            return this;
        }

        public Criteria andCodDptoIn(List<String> values) {
            addCriterion("cod_dpto in", values, "codDpto");
            return this;
        }

        public Criteria andCodDptoNotIn(List<String> values) {
            addCriterion("cod_dpto not in", values, "codDpto");
            return this;
        }

        public Criteria andCodDptoBetween(String value1, String value2) {
            addCriterion("cod_dpto between", value1, value2, "codDpto");
            return this;
        }

        public Criteria andCodDptoNotBetween(String value1, String value2) {
            addCriterion("cod_dpto not between", value1, value2, "codDpto");
            return this;
        }

        public Criteria andCodSedeIsNull() {
            addCriterion("cod_sede is null");
            return this;
        }

        public Criteria andCodSedeIsNotNull() {
            addCriterion("cod_sede is not null");
            return this;
        }

        public Criteria andCodSedeEqualTo(Short value) {
            addCriterion("cod_sede =", value, "codSede");
            return this;
        }

        public Criteria andCodSedeNotEqualTo(Short value) {
            addCriterion("cod_sede <>", value, "codSede");
            return this;
        }

        public Criteria andCodSedeGreaterThan(Short value) {
            addCriterion("cod_sede >", value, "codSede");
            return this;
        }

        public Criteria andCodSedeGreaterThanOrEqualTo(Short value) {
            addCriterion("cod_sede >=", value, "codSede");
            return this;
        }

        public Criteria andCodSedeLessThan(Short value) {
            addCriterion("cod_sede <", value, "codSede");
            return this;
        }

        public Criteria andCodSedeLessThanOrEqualTo(Short value) {
            addCriterion("cod_sede <=", value, "codSede");
            return this;
        }

        public Criteria andCodSedeIn(List<Short> values) {
            addCriterion("cod_sede in", values, "codSede");
            return this;
        }

        public Criteria andCodSedeNotIn(List<Short> values) {
            addCriterion("cod_sede not in", values, "codSede");
            return this;
        }

        public Criteria andCodSedeBetween(Short value1, Short value2) {
            addCriterion("cod_sede between", value1, value2, "codSede");
            return this;
        }

        public Criteria andCodSedeNotBetween(Short value1, Short value2) {
            addCriterion("cod_sede not between", value1, value2, "codSede");
            return this;
        }
    }
}