package pe.gob.sunat.recurso2.humano.sancion.model;

import java.math.BigDecimal;
import java.util.Date;

public class Persona {
    private String t02codPers;

    private String t02codRel;

    private String t02apPate;

    private String t02apMate;

    private String t02nombres;

    private String t02codUorg;

    private String t02codUorgl;

    private String t02codCate;

    private String t02codCatel;

    private String t02codCarg;

    private Date t02fIngsun;

    private Date t02fCese;

    private String t02codRegl;

    private Date t02fNacim;

    private String t02codUbip;

    private String t02urban;

    private String t02direccion;

    private String t02refer;

    private String t02libElec;

    private String t02codTurn;

    private String t02tipPers;

    private String t02tipPerm;

    private String t02ctrlAsis;

    private String t02codStat;

    private BigDecimal t02suelBas;

    private String t02codAnte;

    private String t02indAduana;

    private Date t02fIngAp;

    private Date t02fIngDg;

    private Date t02fFallec;

    private Date t02fGraba;

    private String t02codUser;

    public String getT02codPers() {
        return t02codPers;
    }

    public void setT02codPers(String t02codPers) {
        this.t02codPers = t02codPers == null ? null : t02codPers.trim();
    }

    public String getT02codRel() {
        return t02codRel;
    }

    public void setT02codRel(String t02codRel) {
        this.t02codRel = t02codRel == null ? null : t02codRel.trim();
    }

    public String getT02apPate() {
        return t02apPate;
    }

    public void setT02apPate(String t02apPate) {
        this.t02apPate = t02apPate == null ? null : t02apPate.trim();
    }

    public String getT02apMate() {
        return t02apMate;
    }

    public void setT02apMate(String t02apMate) {
        this.t02apMate = t02apMate == null ? null : t02apMate.trim();
    }

    public String getT02nombres() {
        return t02nombres;
    }

    public void setT02nombres(String t02nombres) {
        this.t02nombres = t02nombres == null ? null : t02nombres.trim();
    }

    public String getT02codUorg() {
        return t02codUorg;
    }

    public void setT02codUorg(String t02codUorg) {
        this.t02codUorg = t02codUorg == null ? null : t02codUorg.trim();
    }

    public String getT02codUorgl() {
        return t02codUorgl;
    }

    public void setT02codUorgl(String t02codUorgl) {
        this.t02codUorgl = t02codUorgl == null ? null : t02codUorgl.trim();
    }

    public String getT02codCate() {
        return t02codCate;
    }

    public void setT02codCate(String t02codCate) {
        this.t02codCate = t02codCate == null ? null : t02codCate.trim();
    }

    public String getT02codCatel() {
        return t02codCatel;
    }

    public void setT02codCatel(String t02codCatel) {
        this.t02codCatel = t02codCatel == null ? null : t02codCatel.trim();
    }

    public String getT02codCarg() {
        return t02codCarg;
    }

    public void setT02codCarg(String t02codCarg) {
        this.t02codCarg = t02codCarg == null ? null : t02codCarg.trim();
    }

    public Date getT02fIngsun() {
        return t02fIngsun;
    }

    public void setT02fIngsun(Date t02fIngsun) {
        this.t02fIngsun = t02fIngsun;
    }

    public Date getT02fCese() {
        return t02fCese;
    }

    public void setT02fCese(Date t02fCese) {
        this.t02fCese = t02fCese;
    }

    public String getT02codRegl() {
        return t02codRegl;
    }

    public void setT02codRegl(String t02codRegl) {
        this.t02codRegl = t02codRegl == null ? null : t02codRegl.trim();
    }

    public Date getT02fNacim() {
        return t02fNacim;
    }

    public void setT02fNacim(Date t02fNacim) {
        this.t02fNacim = t02fNacim;
    }

    public String getT02codUbip() {
        return t02codUbip;
    }

    public void setT02codUbip(String t02codUbip) {
        this.t02codUbip = t02codUbip == null ? null : t02codUbip.trim();
    }

    public String getT02urban() {
        return t02urban;
    }

    public void setT02urban(String t02urban) {
        this.t02urban = t02urban == null ? null : t02urban.trim();
    }

    public String getT02direccion() {
        return t02direccion;
    }

    public void setT02direccion(String t02direccion) {
        this.t02direccion = t02direccion == null ? null : t02direccion.trim();
    }

    public String getT02refer() {
        return t02refer;
    }

    public void setT02refer(String t02refer) {
        this.t02refer = t02refer == null ? null : t02refer.trim();
    }

    public String getT02libElec() {
        return t02libElec;
    }

    public void setT02libElec(String t02libElec) {
        this.t02libElec = t02libElec == null ? null : t02libElec.trim();
    }

    public String getT02codTurn() {
        return t02codTurn;
    }

    public void setT02codTurn(String t02codTurn) {
        this.t02codTurn = t02codTurn == null ? null : t02codTurn.trim();
    }

    public String getT02tipPers() {
        return t02tipPers;
    }

    public void setT02tipPers(String t02tipPers) {
        this.t02tipPers = t02tipPers == null ? null : t02tipPers.trim();
    }

    public String getT02tipPerm() {
        return t02tipPerm;
    }

    public void setT02tipPerm(String t02tipPerm) {
        this.t02tipPerm = t02tipPerm == null ? null : t02tipPerm.trim();
    }

    public String getT02ctrlAsis() {
        return t02ctrlAsis;
    }

    public void setT02ctrlAsis(String t02ctrlAsis) {
        this.t02ctrlAsis = t02ctrlAsis == null ? null : t02ctrlAsis.trim();
    }

    public String getT02codStat() {
        return t02codStat;
    }

    public void setT02codStat(String t02codStat) {
        this.t02codStat = t02codStat == null ? null : t02codStat.trim();
    }

    public BigDecimal getT02suelBas() {
        return t02suelBas;
    }

    public void setT02suelBas(BigDecimal t02suelBas) {
        this.t02suelBas = t02suelBas;
    }

    public String getT02codAnte() {
        return t02codAnte;
    }

    public void setT02codAnte(String t02codAnte) {
        this.t02codAnte = t02codAnte == null ? null : t02codAnte.trim();
    }

    public String getT02indAduana() {
        return t02indAduana;
    }

    public void setT02indAduana(String t02indAduana) {
        this.t02indAduana = t02indAduana == null ? null : t02indAduana.trim();
    }

    public Date getT02fIngAp() {
        return t02fIngAp;
    }

    public void setT02fIngAp(Date t02fIngAp) {
        this.t02fIngAp = t02fIngAp;
    }

    public Date getT02fIngDg() {
        return t02fIngDg;
    }

    public void setT02fIngDg(Date t02fIngDg) {
        this.t02fIngDg = t02fIngDg;
    }

    public Date getT02fFallec() {
        return t02fFallec;
    }

    public void setT02fFallec(Date t02fFallec) {
        this.t02fFallec = t02fFallec;
    }

    public Date getT02fGraba() {
        return t02fGraba;
    }

    public void setT02fGraba(Date t02fGraba) {
        this.t02fGraba = t02fGraba;
    }

    public String getT02codUser() {
        return t02codUser;
    }

    public void setT02codUser(String t02codUser) {
        this.t02codUser = t02codUser == null ? null : t02codUser.trim();
    }
}