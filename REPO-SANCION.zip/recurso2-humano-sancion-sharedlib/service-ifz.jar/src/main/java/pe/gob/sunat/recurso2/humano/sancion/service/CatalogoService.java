package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;

public interface CatalogoService {

	public List<Parametro> listarParametros(String codTabla);
	
	public String obtenerDescripParamSecund(String codTabla, String codParametro);
	
	public String obtenerDescripParam(String codTabla, String codParametro);
	
//	public Map<String, String> obtenerDescripDeclaracion();
}
