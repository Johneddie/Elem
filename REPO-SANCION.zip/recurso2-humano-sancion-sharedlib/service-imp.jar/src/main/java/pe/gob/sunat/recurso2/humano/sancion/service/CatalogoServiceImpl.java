package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.model.CodigoExample;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ParamSecundDAO;
//import pe.gob.sunat.recurso2.humano.sancion.util.Constantes;


@Service("catalogoService")
public class CatalogoServiceImpl implements CatalogoService{

	public final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private CodigoDAO codigoDAO;
	
	@Autowired
	ParamSecundDAO paramSecundDAO;
	
	@Override
	public List<Parametro> listarParametros(String codTabla){
		CodigoExample param = new CodigoExample() ;
		CodigoExample.Criteria criterio = param.createCriteria();
		criterio.andT99codTabEqualTo(codTabla);
		criterio.andT99estadoEqualTo("1");
		criterio.andT99tipDescEqualTo("D");
		return codigoDAO.listarParametros(codTabla);
	}
	
	@Override
	public String obtenerDescripParam(String codTabla, String codParametro){
		return codigoDAO.obtenerDescripcion(codTabla, codParametro);
		
	}
	
	@Override
	public String obtenerDescripParamSecund(String codTabla, String codParametro){
		return paramSecundDAO.obtenerDescripcion(codTabla, codParametro);
		
	}
	
	/*
	@Override
	public Map<String, String> obtenerDescripDeclaracion(){
		FechaBean fb = new FechaBean();
		
		Map<String, String> descrip = new HashMap<>();
		descrip.put("clausula1", paramSecundDAO.obtenerDescripcion(Constantes.CODI_SECU_CLAU_DECL, Constantes.CODI_CLAU_DEC1));
		descrip.put("clausula2", paramSecundDAO.obtenerDescripcion(Constantes.CODI_SECU_CLAU_DECL, Constantes.CODI_CLAU_DEC2));
		descrip.put("clausula3", paramSecundDAO.obtenerDescripcion(Constantes.CODI_SECU_CLAU_DECL, Constantes.CODI_CLAU_DEC3));
		descrip.put("encabezado", paramSecundDAO.obtenerDescripcion(Constantes.CODI_SECU_CLAU_DECL, Constantes.CODI_CLAU_ENCA));
		descrip.put("desFecha", Integer.parseInt(fb.getDia()) + " d�as de " + fb.getMesletras() + " de " + fb.getAnho());
		
		return descrip;
	}*/

}
