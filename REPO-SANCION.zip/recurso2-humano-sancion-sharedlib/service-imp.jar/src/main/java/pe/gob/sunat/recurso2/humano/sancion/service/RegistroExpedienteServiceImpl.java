package pe.gob.sunat.recurso2.humano.sancion.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.sancion.model.ExpedienteSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.SeguimientoExped;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoExped;
import pe.gob.sunat.recurso2.humano.sancion.model.DocumentoSanci;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.ExpedienteSanciDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.SeguimientoExpedDAO;
import pe.gob.sunat.recurso2.humano.sancion.util.FechasUtil;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DocumentoExpedDAO;
import pe.gob.sunat.recurso2.humano.sancion.model.dao.DocumentoSanciDAO;

@Service("registroExpedienteService")
public class RegistroExpedienteServiceImpl implements RegistroExpedienteService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ExpedienteSanciDAO expedienteSanciDAO;

	@Autowired
	SeguimientoExpedDAO seguimientoExpedDAO;

	@Autowired
	DocumentoExpedDAO documentoExpedDAO;

	@Autowired
	DocumentoSanciDAO documentoSanciDAO;
	
	@Override
	public List<ExpedienteSanci> listarExpedientesIniciados(Map<String, String> params) {
		if(log.isDebugEnabled()) log.debug("method listarExpedientesIniciados");
		
		List<ExpedienteSanci> lstDocumentos = new ArrayList<>();
		
		try{
			String codPersonal = params.get("codPersonal");
			String codTipExped = !StringUtils.isBlank(params.get("codTipExpedBusq"))?params.get("codTipExpedBusq"):null;
			Date fecRegisIni = FechasUtil.getDateFromStringDDMMYY(params.get("fecRegisIniBusq")) ;
			Date fecRegisFin = FechasUtil.getDateFromStringDDMMYY(params.get("fecRegisFinBusq")) ;
			if(fecRegisFin!=null)
				fecRegisFin = FechasUtil.obtenerFinalDia(fecRegisFin);
			
			//consulta
			Map<String, Object> hmParams = new HashMap<>();
			hmParams.put("codPersonal", codPersonal);
			hmParams.put("codTipExped", codTipExped);
			hmParams.put("fecRegisIni", fecRegisIni);
			hmParams.put("fecRegisFin", fecRegisFin);
			lstDocumentos = expedienteSanciDAO.listarExpedientesIniciados(hmParams);
			
			for(ExpedienteSanci d:lstDocumentos){
				//estado
//				d.setDesEstado(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_ESTA_SOLI, d.getCodEstado()));
//				d.setDesAccion(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_ACCI_SOLI, d.getCodAccion()));
				
				//tipo
//				d.setDesTipEven(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_TIPO_EVEN, d.getcodTipExped()));
//				d.setDesTema(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_TEMA_DOCE, d.getCodTema()));
				
			}
		}catch(ServiceException e){
			log.error("Ha ocurrido un error en listarDeclaracionesIniciadas: " + e.getMessage(), e);
		}
		return lstDocumentos;
	}

}
