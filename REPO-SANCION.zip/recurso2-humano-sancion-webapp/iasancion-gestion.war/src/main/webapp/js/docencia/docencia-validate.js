
var validarDatosRegistro = function(){
	
	//Validaciones genericas:
	setValidacionesGenericas();
	validarSolicitud();	

};



var setValidacionesGenericas = function(){
	$.validator.addMethod("valIndInfoIntern", function(value, element) {
		return $("#indInfoInternSi").is(':checked') || $("#indInfoInternNo").is(':checked')
	}, "Indique si contempla Información Interna.");
	
	$.validator.addMethod("valFecFinEvenMay", function(value, element) {
		var fi = $('#divFecIniEven').data('DateTimePicker').date();
		if(fi == null) 
			return true;
		var ff = $('#divFecFinEven').data('DateTimePicker').date();
		return ff >= fi;
	}, "La fecha fin debe ser mayor o igual a la fecha de inicio.");
	
	var numDiasDifFecIni = parseInt($('#numDiasDifFecIni').val());
	$.validator.addMethod("valFecIniEvenMax", function(value, element) {
		if(numDiasDifFecIni == null || numDiasDifFecIni == 0)
			numDiasDifFecIni = -9999;
		
		var fi = $('#divFecIniEven').data('DateTimePicker').date();
		if(fi == null) 
			return true;
		var fa = new Date();
		fa.setHours(0,0,0,0);
		var days = Math.round((fi-fa)/(1000*60*60*24));
		return days > numDiasDifFecIni;
	}, "La fecha de inicio debe ser mayor a "+numDiasDifFecIni+" días de la fecha actual.");
	
	
	$.validator.addMethod("valIndRemun", function(value, element) {
		return $("#indRemunSi").is(':checked') || $("#indRemunNo").is(':checked')
	}, "Indique si es Remunerado.");
	
	
	//archivos
	$.validator.addMethod("valDocFisicoReq", function(value, element) {
		var divGroup = $(element).closest(".custom-form-group");
		var divLnkArchivo = divGroup.children("div[id^='lnkArchivo']");
		if(divLnkArchivo.html() == "" && value == "")
			return false;
		return true;
	}, "Adjunte un documento de sustento.");
	
	$.validator.addMethod("valDocFisicoLen", function(value, element) {
		var nomDocFisico = value.replace(/\\/g, '/').replace(/.*\//, '');
		if (nomDocFisico.length <= 50) {
			return true;
		}
		return false;
	}, "El nombre del archivo debe tener máximo 50 caracteres.");
		
	$.validator.addMethod("valDocFisicoRegExp", function(value, element) {
		var nomDocFisico = value.replace(/\\/g, '/').replace(/.*\//, '');
		var reg = /^[a-zA-Z0-9áéíóúÁÉÍÓÚ\-\_\.\ \(\)]*$/;
		if (reg.test(nomDocFisico)) {
			return true;
		}
		return false;
	}, "El nombre del archivo solo permite los siguientes caracteres:  letras, números, guión, subguión y punto.");
	
	$.validator.addMethod("valDescripcionRegExp", function(value, element) {
		var reg = /^[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\-\:\;\.\,\ \(\)\"\n]*$/;
		if (reg.test(value)) {
			return true;
		}
		return false;
	}, "Se ha encontrado caracteres no válidos, solo se permite letras, números, paréntesis, punto y coma.");

};


var validarSolicitud = function(){

	var validadorSolicitud = $("#formDatosSolicitud").validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden",
	  	rules: {
	  		codTipSolic: {
	      		required: true
	    	},	
	    	numRucCentro: {
	      		required: true,
	      		pattern: "^([0-9]{11})?$"
	    	},	
	    	codTipEven: {
	      		required: true
	    	},
			indInfoIntern:{
				valIndInfoIntern:true
			},
			nomEvento: {
	      		required: true,
	      		valDescripcionRegExp: true 
	    	},	
	    	codTema: {
	      		required: true
	    	},	
	    	codNivel: {
	      		required: true
	    	},
	    	fecIniEven:{
				required: true,
				valFecIniEvenMax: true
			},
			fecFinEven:{
				required: true,
				valFecFinEvenMay: true
			},
			indRemun:{
				valIndRemun:true
			},
			codCateg:{
				required:true
			},
			mtoRemun: {
				required: true,
  				number: true,
  				min: 1,
  				max: 99999999.99,
  				pattern:"^[0-9]+(\.[0-9]{1,2})?$"
			},
			docFisicoDocencia: {
				valDocFisicoReq: true,
				valDocFisicoLen: true,
				valDocFisicoRegExp: true
			}
	   },
	   messages: {
	  		codTipSolic: {
	      		required: "Ingrese el Tipo de Solicitud."
	    	},
	  		numRucCentro: {
				required: "Ingrese el RUC del Centro de Estudios.",
	      		pattern: "Número de RUC no válido." 
	    	},
	  		codTipEven: {
	      		required: "Ingrese el Tipo de Evento."
	    	},
			nomEvento: {
	      		required: "Ingrese la Denominación del Evento."
	    	},	
			codTema: {
	      		required: "Seleccione el Tema del Evento."
	    	},	
	    	codNivel: {
	      		required: "Seleccione el Nivel del Evento."
	    	},	
			fecIniEven:{
				required: "Ingrese la Fecha de Inicio."
			},
			fecFinEven:{
				required: "Ingrese la Fecha fin."
			},
			codCateg: {
	      		required: "Seleccione la Categoría del Trabajador."
	    	},
			mtoRemun: {
				required: "Ingrese el Monto de Remuneración.",
	 			number: 'Ingrese un monto válido.',
	 			pattern: 'Ingrese un monto válido.',
	 			min: 'El valor mínimo es 1',
	 			max: 'El valor máximo es 99999999.99',		
			}
		},
		highlight: function (e) {
			if($(e).is("input[tipo^='addon']")||$(e).is("select[tipo^='addon']")) {
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');		
			}else{
				$(e).parent().addClass('has-error');
			}
		},
		success: function (e) {
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[tipo^='addon']")||element.is("select[tipo^='addon']")) {
				if(element.attr("type") == 'radio')
					error.insertAfter(element.parent().parent());
				else
					error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},

		submitHandler: function (form) {
			//alert("ok");
			if(lstHorarios.length == 0){
				mostrarMensajeError("Debe agregar el Horario del Evento.");
				return false;
			}else{
				var formulario = $("#formDatosSolicitud");
				var object = convertirFormAObject(formulario.serializeArray())
				object.horarios = lstHorarios;
				object.nomCentro = $("#lblNomCentro").text();
				
				var indRemun = $("input[name=indRemun]:checked").val();
				if(indRemun == '0'){
					delete object.codCateg;
					delete object.mtoRemun;
				}
				registrarSolicitud(object);
			}

		},
		invalidHandler: function (form) {
		}
	});
};

// ===========
// Seguimiento
// ===========

var validarActualizarEstado = function(){
	
	$.validator.addMethod("valDesObservReq", function(value, element) {
		var codAccion = $('#codAccionAccion').val();
		if(codAccion == _acciones.DEVOLVER || codAccion == _acciones.RECHAZAR){
			if(esVacioNulo(value))
				return false;
		}
		return true;
	}, "Debe ingresar una Observación.");
	
	$("#formObservacion").validate({
		errorElement: 'span',
		errorClass: 'help-block',
		rules: {
			desObserv:{
				valDesObservReq: true
			}
	    },
	    messages: {
		},
		highlight: function (e) {
			$(e).parent().addClass('has-error');
		},
		success: function (e) {
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			error.insertAfter(element);	
		},
	
		submitHandler: function (form) {
			registrarAccionSolicitudAjax();
		},
		invalidHandler: function (form) {
			console.log("invalidHandler...");
		}
	});
};


