/*------------------------------VALIDA EL ARCHIVO SUBIDO----------------------------*/
function validarArchivoUpload(tipArchivo) {
	$("#docFisico"+tipArchivo).appendTo($('#frmArchivoValidar'));
	$('#tipArchivoValidar').val(tipArchivo);
	var nombreArchivo = $("#docFisico"+tipArchivo).val();
	if(validarNombreArchivo(nombreArchivo)){
		$('#frmArchivoValidar').submit();
		$("#docFisico"+tipArchivo).appendTo($('#manejadorArchivo'+tipArchivo));
	}else{
		$("#docFisico"+tipArchivo).val(null);
		$("#docFisico"+tipArchivo).parent().find(".bootstrap-filestyle :input").val("");
	}
}

var validarNombreArchivo = function(nombre){
	var nomDocFisico = nombre.replace(/\\/g, '/').replace(/.*\//, '');
	var reg = /^[a-zA-Z0-9\-\_\.\ \(\)]*$/;
	var isValido = true;
	if(nomDocFisico.length == 50){
		mostrarMensajeError("El nombre del archivo debe tener máximo 50 caracteres.");
		isValido = false;
	}else if(!reg.test(nomDocFisico)) {
		mostrarMensajeError("El nombre del archivo solo permite los siguientes caracteres:  letras (sin tíldes), números, guión, subguión y punto.");
		isValido = false;
	}else if(!terminaCadenaCon(nomDocFisico, ".PDF") &&  !terminaCadenaCon(nomDocFisico, ".pdf")){
		mostrarMensajeError("El archivo adjunto debe ser de tipo PDF.");
		isValido = false;
	}
	return isValido;
}

$("#frmArchivoValidar").submit(function(e){
	var codTipArchivo = $('#tipArchivoValidar').val();
	
	var formObj = $(this);
	var iframeId = 'unique' + (new Date().getTime());
	var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	iframe.hide();
	formObj.attr('target', iframeId);
	formObj.attr('action', CONTEXT_APP + '/archivo/cargar');
	formObj.attr("enctype", "multipart/form-data");
	formObj.attr("encoding", "multipart/form-data");
	iframe.appendTo('body');
	
	$.blockUI(); 
	iframe.load(function(e){
		$.unblockUI(); 
		var doc = getDoc(iframe[0]);
		var docRoot = doc.body ? doc.body : doc.documentElement;
		var data = docRoot.innerHTML;
		var jsonDataString;
		var response;
		var indError;
		indError = false;
		var indErrorJson = false;
		if (data.toLowerCase().indexOf("error") >= 0 || data.toLowerCase().indexOf("SUNAT Operaciones en Línea") >= 0 ) {
			indError = true;
		}
				
		if(indError) {
			$("#docFisico"+codTipArchivo).val(null);
			$("#docFisico"+codTipArchivo).parent().find(".bootstrap-filestyle :input").val(null);
			mostrarMensajeError("Ha ocurrido un problema al cargar el archivo. Verifique el tamaño del archivo.");
		} else {		
			if (data.indexOf("<pre style") > -1) {
				jsonDataString = data.replace('<pre style="word-wrap: break-word; white-space: pre-wrap;">', '');
				jsonDataString = jsonDataString.replace('<pre style="word-wrap: break-word; white-space: pre-wrap">', '');
				jsonDataString = jsonDataString.replace('</pre>', '');
			} else {
				jsonDataString = data.replace('<PRE>', '').replace('</PRE>', '').replace('<pre>', '').replace('</pre>', '');
			}
			try{
				response = jQuery.parseJSON(jsonDataString);
				if (response.isTamanoSuperado) {
					indErrorJson = true;
					mostrarMensajeError("El tamaño de archivo máximo permitido es: " + response.tamanoPermitido + " MB.");
				} else if(response.isOtraExtension){
					indErrorJson = true;
					mostrarMensajeError("Los archivos a adjuntar deben ser de tipo PDF.");
				} else if(response.isNombreSuperado){
					indErrorJson = true;
					mostrarMensajeError("El nombre del archivo debe tener una longitud menor a 50 letras.");
				} 
				
				if(!indErrorJson){
					$("#lnkArchivo"+codTipArchivo).html("");
					$("#nomArchivo"+codTipArchivo).val(response.nomArchivo);
					$("#docFisico"+codTipArchivo).parent().find(".bootstrap-filestyle :input").val(response.nomArchivo);
				}else{
					$("#docFisico"+codTipArchivo).val(null);
					$("#docFisico"+codTipArchivo).parent().find(".bootstrap-filestyle :input").val(null);
				}
				
			}catch(err){
				$("#docFisico"+codTipArchivo).val(null);
				$("#docFisico"+codTipArchivo).parent().find(".bootstrap-filestyle :input").val(null);
				mostrarMensajeError("Ha ocurrido un problema al cargar el archivo. Verifique el tamaño del archivo.");
			}
		}
	});
	
});

function onClickDescargarDocumento(numArcSolic){
	if(numArcSolic==null){
		mostrarMensajeError("No se adjuntó ningún archivo.");
	}else{
		$("#numArcSolicDescarga").val(numArcSolic);
		$("#frmDocumentoDescarga").submit();
	}
}

function onClickDescargarDeclaracion(numIdSolic){
	if(numIdSolic==null){
		mostrarMensajeError("No se adjuntó ningún archivo.");
	}else{
		$("#numIdSolicDescarga").val(numIdSolic);
		$("#frmDeclaracionDescarga").submit();
	}
}