// =================================================================
// COMPONENTES
// =================================================================
var inicializarComponentesBusqueda = function(){

    $('#divFecRegisIniBusq').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent: false,
    	maxDate: new Date()
    }).on('dp.change', function (ev) {
        return true;
    });
    
    $('#divFecRegisFinBusq').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent: false,
    	maxDate: new Date()
    });
    
    recargarGrillaSolicitudes(convertirFormAObject($("#frmBuscarSolicitudes").serializeArray()));
	
};

// =================================================================
// Validaciones 
// =================================================================

var setValidacionesGenericasBusqueda = function(){
	$.validator.addMethod("valFecRegisFinMay", function(value, element) {
		var fi = $('#divFecRegisIniBusq').data('DateTimePicker').date();
		if(fi == null) 
			return true;
		var ff = $('#divFecRegisFinBusq').data('DateTimePicker').date();
		return ff >= fi;
	}, "La fecha fin debe ser mayor o igual a la fecha de inicio.");
	
	$.validator.addMethod("valFecRegisFinMax", function(value, element) {
		var fi = $('#divFecRegisIniBusq').data('DateTimePicker').date();
		if(fi == null) 
			return true;
		var ff = $('#divFecRegisFinBusq').data('DateTimePicker').date();
		var days = Math.round((ff-fi)/(1000*60*60*24));
		return days <= 180;
	}, "En rango de fechas no debe ser mayor a 365 días.");
	
	$.validator.addMethod("valFecRegisFinReq", function(value, element) {
		var fi = $('#divFecRegisIniBusq').data('DateTimePicker').date();
		var ff = $('#divFecRegisFinBusq').data('DateTimePicker').date();
		if(fi != null && ff == null) 
			return false;
		return true;
	}, "Debe ingresar la fecha fin.");
	
	$.validator.addMethod("valFecRegisIniReq", function(value, element) {
		var fi = $('#divFecRegisIniBusq').data('DateTimePicker').date();
		var ff = $('#divFecRegisFinBusq').data('DateTimePicker').date();
		if(fi == null && ff != null) 
			return false;
		return true;
	}, "Debe ingresar la fecha inicio.");
};


var validarBusquedaSolicitudes = function(){
	$("#frmBuscarSolicitudes").validate({
		errorElement: 'span',
		errorClass: 'help-block',
		rules: {
			fecRegisIniBusq:{
				valFecRegisIniReq: true
			},
			fecRegisFinBusq:{
				valFecRegisFinReq: true,
				valFecRegisFinMay: true,
				valFecRegisFinMax: true
			}
	    },
	    messages: {
		},
		highlight: function (e) {
			if($(e).is("input[tipo^='addon']")) {
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');		
			}else{
				$(e).parent().addClass('has-error');
			}
		},
		success: function (e) {
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[tipo^='addon']")) {
				error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},
	
		submitHandler: function (form) {
	    	recargarGrillaSolicitudes(convertirFormAObject($("#frmBuscarSolicitudes").serializeArray()));
	    	
		},
		invalidHandler: function (form) {
			console.log("invalidHandler...");
		}
	});
};