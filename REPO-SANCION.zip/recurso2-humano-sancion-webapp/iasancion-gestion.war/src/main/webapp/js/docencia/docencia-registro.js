// =================================================================
// Inicializar componentes nuevo
// =================================================================

var inicializarComponentesSolicitud = function(){
	$.fn.select2.defaults.set( "theme", "bootstrap" );
	$.fn.select2.defaults.set( "language", "es" );
	$.fn.select2.defaults.set( "width", "100%" );
	
	$('input[id^="docFisico"]').filestyle({
		iconName : 'fa fa-upload',
		buttonText : 'Subir Archivo',
        buttonName : 'btn-default'
	});    

	var $select = $('.desplegableSensitivo').select2();
	$select.on('change', function() {
		$(this).trigger('blur');
	});
	
    $('#divFecIniEven').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent: false
    }).on('dp.change', function (ev) {
        return true;
    });
    
    $('#divFecFinEven').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent: false
    });
    
    $('#divDesHorIniDetalle').datetimepicker({
        format: 'HH:mm'
    });
    
    $('#divDesHorFinDetalle').datetimepicker({
        format: 'HH:mm'
    });
	
	
    $("#btnNuevaSolicitud").click(function(){
    	iniciarRegistroDatosSolicitud();
    });
    
    
    $("#numRucCentro").change(function(){
    	var numRucCentro = $(this).val();
    	onClickBuscarContribuyente(numRucCentro);
    });	
    
    
    $("#btnAgregarHorario").click(function(){
    	onClickAgregarHorario();
	});
    
    $("#codTipSolic").change(function(){
    	var codTipSolic = $(this).val();
    	var lblDocumentoAdjunto = "";
    	if(codTipSolic == "01")
    		lblDocumentoAdjunto = "Publicidad/Temario";
    	else if(codTipSolic == "02")
    		lblDocumentoAdjunto = "Sílabo del Curso"; 
    	$("#lblDocumentoAdjunto").text(lblDocumentoAdjunto);
    	
    });
    
	$("input[name=indRemun]").change(function(){
		var indRemun = $("input[name=indRemun]:checked").val();			
		if(indRemun == '0'){
			$("#divCasoRemunerado").hide();
		}else{
			$("#mtoRemunera, #codCateg").val('');
			$("#divCasoRemunerado").show();
		}
	});	
    
};



// =================================================================
// BÚSQUEDA DE PERSONA DNI
// =================================================================

function onClickBuscarContribuyente(numRuc){
	
	$("#lblNomCentro").text("");
	
	if(!esVacioNulo(numRuc) && numRuc.length == 11 && esTextoNumero(numRuc)){
		
		var URL_OBTENER = CONTEXT_APP+"/solicitudAutoriza/centroEstudio/"+numRuc;
	    $.ajax({type: "POST",url: URL_OBTENER, dataType: 'json', contentType: "application/json; charset=utf-8",
	        success: function(s){
	        	if(s.indError == '0' && s.contribuyente != null){
	        		$("#lblNomCentro").text(s.contribuyente.nomContrib);
	        	}else{
	        		$("#numRucCentro").val("");
	        		mostrarMensajeError("No se ha encontrado datos para el RUC ingresado.");
	        	}
	        }
	    });

	}
}

// ===============
// agregar horario
// ===============

var onClickAgregarHorario = function(){
	//validaciones
	var codDiaEven = $('#codDiaEvenDetalle').val();
	var desHorIni = $('#desHorIniDetalle').val();
	var desHorFin = $('#desHorFinDetalle').val();
	
	//validaciones
	if(codDiaEven == ''){
		mostrarMensajeError("Debe seleccionar el día del evento.");
		return false;
	}
	if(desHorIni == ''){
		mostrarMensajeError("Debe ingresar una hora de inicio válida.");
		return false;
	}
	if(desHorFin == ''){
		mostrarMensajeError("Debe ingresar una hora fin válida.");
		return false;
	}

	var hi = $('#divDesHorIniDetalle').data('DateTimePicker').date().toDate();
	var hf = $('#divDesHorFinDetalle').data('DateTimePicker').date().toDate();
	hi.setFullYear(2000, 0, 1);
	hf.setFullYear(2000, 0, 1);
	if(hi >= hf){
		mostrarMensajeError("La hora fin debe ser mayor a la hora de inicio.");
		return false;
	}
	
	//existencia
	for(var i=0;i<lstHorarios.length;i++){
		var e = lstHorarios[i];
		if(e.codDiaEven==codDiaEven && e.desHorIni==desHorIni && e.desHorFin==desHorFin){
			mostrarMensajeError("El rango de horas no debe repetirse.");
    		return false;
		}
	}
    	
	//horario
	var horario = {};
	horario.codDiaEven = codDiaEven;
	horario.desHorIni = desHorIni;
	horario.desHorFin = desHorFin;
	horario.nomDiaEven = $("#codDiaEvenDetalle option:selected").text();
	
	lstHorarios.push(horario);
	renderizarTableHorarios(lstHorarios,'1');
	$('#codDiaEvenDetalle,#desHorIniDetalle,#desHorFinDetalle').val('');
}

var onClickEliminarHorario = function(indiceEliminar){
	var indiceEncontrado;
	$.each(lstHorarios, function( i, puesto ){
		if(indiceEliminar == i){
			indiceEncontrado = i;
			return false;
		}
	});
	if(indiceEncontrado!=null){
		lstHorarios.splice(indiceEncontrado, 1);
		renderizarTableHorarios(lstHorarios,'1');
	}
}

var renderizarTableHorarios = function(lista, indElim){
	
	var theadHtml = '<tr><th>Día</th><th class="text-center">Hora Inicio</th><th class="text-center">Hora Fin</th>'
	if(indElim == '1')
		theadHtml += '<th class="text-center">Eliminar</th>'
	theadHtml += '</tr>';
	
	var tbodyHtml = '';
	if(lista.length == 0){
		tbodyHtml = '<tr><td colspan="4" align="center">Ningún dato disponible en esta tabla</td></tr>';
	}else{
		$.each(lista, function( index, horario ){
			var html = '';
			html += '<tr>'
			html += '<td>' + horario.nomDiaEven + '</td>';
			html += '<td align="center">' + horario.desHorIni + '</td>';
			html += '<td align="center">' + horario.desHorFin + '</td>';

			if(indElim == '1')
				html += '<td align="center"><a href="#" onclick="javascript:onClickEliminarHorario('+index+');" class="text-danger"><i class="fa fa-times" aria-hidden="true"></i></a></td>';

			html += '</tr>'
			tbodyHtml += html;
		});
	}
	$('#theadDataHorarios').html(theadHtml);
	$('#tbodyDataHorarios').html(tbodyHtml);
}


/* accion
 * 01: registrar
 * 02: ver
 * 03: aprobar
 */

var configurarBodyPopupEdicion = function(accion, divDatosBody, divDetalleBody, docFisico){
	
	if(accion == '02' || accion == '03'){ //ver | aprobar
		$(divDatosBody+' :input').prop("disabled",true);
		$(docFisico).filestyle('disabled', true);
		$(divDetalleBody).hide();
	}else{
		$(divDetalleBody).show();
		$(docFisico).filestyle('disabled', false);
	}
	
};

var configurarFooterPopupBotones = function(form, accion){
	$(form + " :input[id^='btn']").hide();
	
	if(accion == '01'){ //registrar
		$(form + " :input[id^='btnCerrar']").show();
		$(form + " :input[id^='btnRegistrar']").show();
		$(form + " :input[id^='btnAgregar']").show();
		
	}else if(accion == '02'){ //ver
		$(form + " :input[id^='btnCerrar']").show();
		
		
	}else if(accion == '03'){ //aprobar
		$(form + " :input[id^='btnCerrar']").show();
		$(form + " :input[id^='btnAprobar']").show();
		$(form + " :input[id^='btnRechazar']").show();
	}
};


// ===============================================================================================
// FORMACIÓN ACADÉMICA
// ===============================================================================================

var iniciarRegistroDatosGenerico = function(tipo){
	$('#docFisico'+tipo).filestyle('disabled', false);
	$("#divDesEstado"+tipo).html(lblCabeceraPopupNuevo);
	$("#nomArchivo"+tipo).val("");
	$("#lnkArchivo"+tipo).html('');
	
}

var iniciarRegistroDatosSolicitud = function(){
	limpiarMensajesError("#formDatosSolicitud");
	$('#formDatosSolicitud').trigger("reset");
	
	lstHorarios = [];
	renderizarTableHorarios(lstHorarios,'1');
	
	$("#divDatosSolicitudBody :input").prop("disabled",false);
	iniciarRegistroDatosGenerico("Docencia");
	$("#numIdSolic").val('');
	$("#lblNomCentro").text('');
	$("#divCasoRemunerado").hide();
	$("#divDatosHorarioBody").show();
	$("#nomEvento").attr("title",null);
	
	//configurarDesarrollo();//borrar!
	
	configurarFooterPopupBotones("#formDatosSolicitud", '01');
	$("#divModalSolicitudPopup").modal('show');
};


var configurarDesarrollo = function(){
	$("#codTipSolic").val("01").change();
	$("#numRucCentro").val("10460265792");
	$("#lblNomCentro").text("RUC DE DESARROLLO");
	$("#codTipEven").val("01");
	$("input[name=indInfoIntern][value='0']").prop("checked",true);
	$("#fecIniEven").val("16/09/2019");
	$("#fecFinEven").val("16/09/2019");
	$("#nomEvento").val("EVENTO PRUEBA");
	$("#codTema").val("01");
	$("#codNivel").val("01");
	$("input[name=indRemun][value='0']").prop("checked",true).change();
	$("#codCateg").val("01");
	
	//horario
	var horario = {};
	horario.codDiaEven = "01";
	horario.desHorIni = "11:00";
	horario.desHorFin = "12:00";
	horario.nomDiaEven = "LUNES";
	
	lstHorarios.push(horario);
	renderizarTableHorarios(lstHorarios,'1');
}


var lblCabeceraPopupNuevo = "Número: <label style='margin-bottom: 0px;'>SIN NÚMERO</label>&nbsp;&nbsp;"+
"Acción: <label style='margin-bottom: 0px;'>NUEVO</label>&nbsp;&nbsp;"+
"Estado: <label style='margin-bottom: 0px;'>NUEVO</label>"+
"<hr style='margin-top: 5px;margin-bottom: 15px;'>";


var configurarCabeceraPopup = function(r){
	return "Número: <label style='margin-bottom: 0px;'>SOL"+r.numAnio+padCorrel(r.numCorrel)+" </label>&nbsp;&nbsp;"+
			 "Acción: <label style='margin-bottom: 0px;' class='"+obtenerClaseAccion(r.codAccion)+"'>"+r.desAccion+"</label>&nbsp;&nbsp;"+
		     "Estado: <label style='margin-bottom: 0px;' >"+r.desEstado+"</label>"+
		     "<hr style='margin-top: 5px;margin-bottom: 15px;'>";
}


var onClickEditarOpcionDatosSolicitud = function(d, accion){
	limpiarMensajesError("#formDatosSolicitud");
	$('#formDatosSolicitud').trigger("reset");
	
	var URL_DOCUMENTO = CONTEXT_APP+"/solicitudAutoriza/solicitud/"+d.numIdSolic;
	$.getJSON(URL_DOCUMENTO, function(r) {
		$("#divDatosSolicitudBody :input").prop("disabled",false);
		
		$("#divDesEstadoDocencia, #divDesEstadoObservacion").html(configurarCabeceraPopup(d));
		
		//datos
		$("#numIdSolic").val(r.numIdSolic);
		$("#codTipSolic").val(r.codTipSolic);
		$("#numRucCentro").val(r.numRucCentro);
		$("#lblNomCentro").text(r.nomCentro);
		$("#codTipEven").val(r.codTipEven);
		$("input[name=indInfoIntern][value='"+r.indInfoIntern+"']").prop("checked",true);
		$("#fecIniEven").val(r.fecIniEven);
		$("#fecFinEven").val(r.fecFinEven);
		$("#nomEvento").val(r.nomEvento).attr("title",r.nomEvento);
		$("#codTema").val(r.codTema);
		$("#codNivel").val(r.codNivel);
		$("input[name=indRemun][value='"+r.indRemun+"']").prop("checked",true).change();
		$("#codCateg").val(r.codCateg);
		if(r.mtoRemun != null)
			$("#mtoRemun").val(r.mtoRemun.toFixed(2));
		
		
		//documento
		$("#docFisicoDocencia").val("");
		if(r.numArcSolic!=null){
			var linkDocumento = '<a href="javascript:onClickDescargarDocumento(\'' + r.numArcSolic + '\');" alt="Descargar"><i class="fa fa-file" aria-hidden="true"></i> '+r.nomArcSolic+'</a>';
			$("#lnkArchivoDocencia").html(linkDocumento);
		}else{
			$("#lnkArchivoDocencia").html('');
		}
		
		//detalle
		lstHorarios = r.horarios;
		renderizarTableHorarios(lstHorarios, '0');
		
		configurarBodyPopupEdicion(accion,"#divDatosSolicitudBody","#divDatosHorarioBody","#docFisicoDocencia");
		configurarFooterPopupBotones("#formDatosSolicitud", accion);
		
		$("#divModalSolicitudPopup").modal('show');
		
	}).error(function(){mostrarMensajeError("Ha ocurrido un error en el sistema.");});
};



function registrarSolicitud(object){
	
	confirmarOperacionAceptar(obtenerDescripDeclaracion(object), function() {
		
		var data = $.toJSON(object);
		var url = CONTEXT_APP+"/solicitudAutoriza/registrar";
		$("#btnRegistrarSolicitud").prop('disabled', true);
		
	    $.ajax({
	           type: "POST",
	           url: url,
	           dataType: 'json',	
	           data: data, 
	           contentType: "application/json; charset=utf-8",
	           success: function(resultado){
	        	   $("#btnRegistrarSolicitud").prop('disabled', false);
	        		   if(resultado.indError == "0"){
	        			   var msgQuinta = "";
	        			   var codRelLab = $("#codRelLab").val();
	        			   if(object.codCateg == "02" && codRelLab !='09' && codRelLab !='10')
	        				   msgQuinta = "<p>Recuerde que debe registrar su <a href='javascript:accederDeclaracionQuinta();'>Declaración Jurada</a> de otras rentas de Quinta Categoría.</p>";
		        		   mostrarMensajeExitoDeclaracion("<p>La Solicitud ha sido registrada correctamente.</p>" + msgQuinta);
		        		   $("#divModalSolicitudPopup").modal('hide');
		        		   
		        		   var data = {};
		        		   recargarGrillaSolicitudes(convertirFormAObject(data));
		        	   }else{	        		   
		        		   mostrarMensajeError("Ha ocurrido un error en el sistema: " + resultado.nomError);   
		        	   }   
	           }
	   });
	});
}


function accederDeclaracionQuinta() {
	window.open("/cl-at-iamenu/menuS03Alias?accion=invocarExterna&invb=rO0ABXNyADBwZS5nb2Iuc3VuYXQudGVjbm9sb2dpYS5tZW51LmJlYW4uSW52b2NhY2lvbkJlYW4nfXqa2PMcWgIABFoAC2F1dGVudGljYWRhTAAFbG9naW50ABJMamF2YS9sYW5nL1N0cmluZztMAAhwcm9ncmFtYXEAfgABTAADdXJscQB+AAF4cAB0AAB0AAkyLjUuMi40LjFxAH4AAw==","_blank");
}


function obtenerDescripDeclaracion(object){
	var e = $("#encabezado").val();
	e = e.replace("<nomPersonal>",$("#nomPersonal").val());
	e = e.replace("<codPersonal>",$("#codPersonal").val());
	e = e.replace("<nomUorga>",$("#nomUorga").val());
	
	var c1 = $("#clausula1").val();
	c1 = c1.replace("<nomEvento>",object.nomEvento);
	c1 = c1.replace("<nomCentro>",object.nomCentro.toUpperCase());
	
	var d = "<h4><center><u>Declaración Jurada</u></center></h4><br>";
	d += "<p class='text-justify'>"+e+"</p>";
	d += "<ol type='a' class='text-justify'>";
	d += "<li>" + c1;
	d += "<li>" + $("#clausula2").val();
	d += "<li>" + $("#clausula3").val();
	d += "</ol>";
	d += "<p class='text-justify'>Acepto que en caso se detecte que he omitido, ocultado o consignado información falsa, la Superintendencia Nacional de Aduanas y de Administración Tributaria procederá con las acciones administrativas y/o penales que correspondan.</p><br>";
	d += "<p>" + $("#desFecha").val() + "</p><br><br>";
	d += "<small>(*)Se considerará lo indicado en el artículo 107 del reglamento de la ley de carrera administrativa aprobado por Decreto supremo N°005-90-PCM.</small>";
	
	return d;
}

