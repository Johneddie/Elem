package pe.gob.sunat.recurso2.humano.sancion.web.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.humano.sancion.bean.Parametro;
import pe.gob.sunat.recurso2.humano.sancion.util.Constantes;
import pe.gob.sunat.recurso2.humano.sancion.util.Utiles;
import pe.gob.sunat.recurso2.humano.sancion.service.CatalogoService;
import pe.gob.sunat.recurso2.humano.sancion.service.RegistroExpedienteService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Controller
@RequestMapping(value="/expedienteSancion")
public class ExpedienteController {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private RegistroExpedienteService registroExpedienteService;
	
	@Autowired
	private CatalogoService catalogoService;
	
	/*
	@Autowired
	private RegistroSolicitService registroSolicitService;
	
	@Autowired
	private CatalogoService catalogoService;
	
	@Autowired
	private ContribuyenteService contribuyenteService;
	
	@Autowired
	private SeguimSolicitService seguimSolicitService;
	
	@Autowired
	private PersonalService personalService;
	*/
	
	@RequestMapping("/inicio")
	public ModelAndView iniciarSolicitudAutoriza(HttpServletRequest request, HttpServletResponse response){
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method iniciarSolicitudAutoriza: " + usuarioBean.getNroRegistro());
		
		Map<String,Object> parametros = new HashMap<>();
		//catalogos
//		parametros.put("tiposSolicitud", catalogoService.listarParametros(Constantes.CODI_TABL_TIPO_SOLI));
		parametros.put("tiposExpediente", catalogoService.listarParametros(Constantes.CODI_TABL_TIPO_EXPE));
//		parametros.put("temassancion", catalogoService.listarParametros(Constantes.CODI_TABL_TEMA_DOCE));
//		parametros.put("nivelessancion", catalogoService.listarParametros(Constantes.CODI_TABL_NIVE_DOCE));
//		parametros.put("categoriasPersonal", catalogoService.listarParametros(Constantes.CODI_TABL_CATE_PERS));
//		parametros.put("diasEvento", catalogoService.listarParametros(Constantes.CODI_TABL_DIAS_EVEN));
//		parametros.put("declaracion", catalogoService.obtenerDescripDeclaracion());
//		parametros.put("persona", personalService.obtenerDatosPersonal(usuarioBean.getNroRegistro()));
//		parametros.put("numDiasDifFecIni", catalogoService.obtenerDescripParam(Constantes.CODI_TABL_PARA_GENE, Constantes.CODI_GENE_DIAS_DIFE));

		return new ModelAndView("expedienteSancion/ExpedienteSancion", parametros);
	}
	
	/*
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/iniciadas/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<SolicitAutoriza> listarSolicitudesIniciadas(HttpServletRequest request, HttpServletResponse response) throws Exception {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method listarSolicitudesIniciadas: " + usuarioBean.getNroRegistro());
		
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		mapParams.put("codPersonal", usuarioBean.getNroRegistro());
		return registroSolicitService.listarSolicitudesIniciadas(mapParams);
	}
	*/
	
	/*
	@RequestMapping(value = "/centroEstudio/{numRuc}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> obtenerCentroEstudio(HttpServletRequest request, @PathVariable("numRuc") String numRuc)  {
		
		if(log.isDebugEnabled()) log.debug("method obtenerCentroEstudio");
		Map<String,Object> mapRpta = new HashMap<>();
		try{
			mapRpta.put("contribuyente", contribuyenteService.obtenerContribuyente(numRuc));
			mapRpta.put("indError",Constantes.INDI_GENE_INAC);
		}catch(Exception e){
			Utiles.configurarMensajeError(mapRpta, e.getMessage(), Utiles.obtenerTrazaError(e));
		}
		
		return mapRpta;
	}
	
	@RequestMapping(value = "/registrar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> registrarSolicitud(@RequestBody SolicitAutoriza solicitud, HttpServletRequest request)  {
		if(log.isDebugEnabled()) log.debug("method registrarSolicitud");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String,Object> mapRpta = new HashMap<>();
		
		try{
			solicitud.setCodPersonal(usuarioBean.getNroRegistro());
			solicitud.setCodAlias(usuarioBean.getLogin().toUpperCase());
			mapRpta = registroSolicitService.registrarSolicitud(solicitud, usuarioBean.getNroRegistro(), usuarioBean.getTicket());
		}catch(Exception e){
			Utiles.configurarMensajeError(mapRpta, e.getMessage(), Utiles.obtenerTrazaError(e));
		}
		
		return mapRpta;
	}
	
	// =========
	// DOCUMENTO
	// =========
	
	@RequestMapping(value = "/solicitud/{numIdSolic}", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Object obtenerSolicitud(@PathVariable("numIdSolic") Integer numIdSolic, HttpServletRequest request)  {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		log.debug("method obtenerSolicitud: " + usuarioBean.getNroRegistro());
		SolicitAutoriza solicitud = null;
		try{
			solicitud = registroSolicitService.obtenerSolicitud(numIdSolic);
		}catch(Exception e){
			log.error("Ha ocurrido un error en obtenerSolicitud: " + e.getMessage(), e);
		}
		return solicitud;
	}
	
	// ===========
	// SEGUIMIENTO
	// ===========
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/seguimiento/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<SeguimSolicit> listarSeguimientos(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		if(log.isDebugEnabled()) log.debug("method listarSeguimientos: " + usuarioBean.getNroRegistro());
		
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		return seguimSolicitService.listarSeguimientos(mapParams);
	}

	*/
}
